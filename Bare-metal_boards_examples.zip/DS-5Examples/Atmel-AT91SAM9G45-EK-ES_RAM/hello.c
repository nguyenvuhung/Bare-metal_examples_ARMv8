/*
 * C Application Example
 * 
 * Copyright (C) ARM Limited, 2007-2011. All rights reserved.
 */

/*
 * hello.c: A simple "helloworld" C program
 */
 
#include <stdio.h>

int main(int argc, char** argv)
{
    printf("Hello world\n");

    return 0;
}
