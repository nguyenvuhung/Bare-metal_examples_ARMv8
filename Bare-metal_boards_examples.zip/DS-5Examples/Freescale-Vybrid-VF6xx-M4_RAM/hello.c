/*
 * hello.c: A simple "helloworld" C program
 */

#include <stdio.h>

int main(int argc, char** argv)
{
    printf("Hello world from Cortex-M4\n");
    return 0;
}
