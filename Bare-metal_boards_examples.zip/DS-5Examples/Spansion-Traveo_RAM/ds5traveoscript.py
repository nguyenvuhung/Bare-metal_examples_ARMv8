import sys

# Fixed definition (do not change)
CHIP_ID__S6J311EJ = "S6J311EJ"
CHIP_ID__S6J311AH = "S6J311AH"

# Choose the CHIP ID
CHIP_ID = CHIP_ID__S6J311EJ

# Reset controller related definitions
REG_AHB__SYSC0_PROTKEYR     = 0xB0600000
REG_AHB__SYSC_RSTCNTR       = 0xB0600380
REG_AHB__SYSC_RSTCAUSEUR    = 0xB0600390
KEY__SYSC0_UNLOCK           = 0x5CACCE55
VALUE__TRIGGER_SWHRST_DBGR  = 0xDAA50000

# Security Checker related definitions
REG_APB__SCCFG_UNLCK        = 0x000C01A4
REG_APB__SCSCU_CNTL         = 0x000C01B4
REG_APB__SYSC0_JTAGCNFG     = 0xB0600704
KEY__SCCFG_UNLOCK           = 0x5ECACCE5
KEY__SCCFG_LOCK             = 0xA135331A
VALUE__JTAGCON_ON           = 0x00010000
VALUE_DBGDONE_ON            = 0x00000001
VALUE_WDGRST_MASK           = 0x00000100

# System RAM related definitions
REG_AHB__SRCFG_KEY             =     0xb010800c
REG_AHB__SRCFG_CFG0            =     0xb0108000
KEY__SRCFG_UNLOCK              =     0x5ecc551f
KEY__SRCFG_LOCK                =     0x551fb10c
VALUE__SRCFG_CFG0              =     0x00000100
SYSTEM_RAM_START_ADDRESS       =     0x02000000
SYSTEM_RAM_SIZE_BYTES          =     {
                                    CHIP_ID__S6J311EJ    :     256*1024,
                                    CHIP_ID__S6J311AH    :     16*1024,
                                }

# TCMRAM related definitions
TCMRAM_START_ADDRESS           =     0x00000000
TCMRAM_SIZE_BYTES              =     {
                                    CHIP_ID__S6J311EJ    :    64*1024,
                                    CHIP_ID__S6J311AH    :    64*1024,
                                }
from arm_ds.debugger_v1 import Debugger
from arm_ds.debugger_v1 import DebugException

debugger = Debugger()
ec = debugger.getExecutionContext(0)

# Returns the value of the Chip-ID
def GetMcuSeries():
    return CHIP_ID

def WriteViaApb(address, value):
    ec.getMemoryService().writeMemory32("APB:" + hex(address), value)

def WriteViaAhb(address, value):
    ec.getMemoryService().writeMemory32("AHB:" + hex(address), value)


def ClearResetBits():
    WriteViaAhb(REG_AHB__SYSC0_PROTKEYR, KEY__SYSC0_UNLOCK) # Unlock SCCFG_UNLCK
    WriteViaAhb(REG_AHB__SYSC_RSTCAUSEUR, 0)  # Clear all bits

# Disable the watchdog
def DisableWatchDog():
    # Mask watch dog reset
    print "Mask watch dog reset."
    WriteViaApb(REG_APB__SCCFG_UNLCK, KEY__SCCFG_UNLOCK)    # Unlock SCCFG_UNLCK
    WriteViaApb(REG_APB__SCSCU_CNTL,  VALUE_WDGRST_MASK)    # Set SCSCU_CNTL.WDG_RST_MASK bit
    WriteViaApb(REG_APB__SCCFG_UNLCK, KEY__SCCFG_LOCK)      # Lock SCCFG_UNLCK

def PatchSysramWaitcycles():
    print("Setting SYSRAM read/write wait cycles to 0")
    # Write SYSRAM read wait cycles to 0 (for debugging from SYSRAM) to prevent 
    # changing of wait cycles during code execution from SYSRAM
    WriteViaAhb(REG_AHB__SRCFG_KEY, KEY__SRCFG_UNLOCK)  # unlock the SYSRAM configuration registers (SRCFG_KEY)
    WriteViaAhb(REG_AHB__SRCFG_CFG0, VALUE__SRCFG_CFG0) # set SRCFG_CFG0_RDWAIT = 0, SRCFG_CFG0_WRWAIT = 0
    WriteViaAhb(REG_AHB__SRCFG_KEY, KEY__SRCFG_LOCK)    # lock the SYSRAM configuration registers (SRCFG_KEY)

# ECC bits of RAM need to be initialized before downloading code/data to it
def InitializeRamEcc(start_address, size_in_bytes):
    print "Filling RAM start=" + hex(start_address) + " size=" + hex(size_in_bytes) 
    ec.getMemoryService().fillMemory(hex(start_address), hex(start_address + size_in_bytes), 0, 4)
    print "Completed"

# Program download to RAM
def SetupSYSRAM():
    PatchSysramWaitcycles()
    print("Initializing SYSRAM ECC...")
    InitializeRamEcc(SYSTEM_RAM_START_ADDRESS, SYSTEM_RAM_SIZE_BYTES[GetMcuSeries()])

def SetupTCMRAM():    
    print("Initializing TCMRAM ECC...")
    InitializeRamEcc(TCMRAM_START_ADDRESS, TCMRAM_SIZE_BYTES[GetMcuSeries()])

# Stop the target
ec.getExecutionService().stop()
#DisableWatchDog()
SetupSYSRAM()
#SetupTCMRAM()
#ClearResetBits()
