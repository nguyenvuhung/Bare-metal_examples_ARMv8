/*---------------------------------------------------------------*/
/* Further Optimization Techniques Example                       */
/*                                                               */
/* Copyright (C) ARM Limited, 2011. All rights reserved.         */
/*---------------------------------------------------------------*/


#include <stdio.h>

int common_data2;


// inlineable_function2() is inlineable when compiled with --multifile, and its out-of-line version can be removed with linker --feedback.
void inlineable_function2(void)
{
    printf("Hello from inlineable_function1().\n");
}


// code_share_function2() can share the same literal with code_share_function1() in another source file when compiled with --multifile, and can be inlined, and their out-of-line versions can be removed with linker --feedback.
void code_share_function2(void)
{
    common_data2 = 0x76543210;
    printf("Hello from code_share_function2() %0x.\n", common_data2);
}


// Unoptimized function to add two integer arrays
void add_int_array1(int * pd, int * ps1, int * ps2, int n)
{
    int i;
    for(i = 0; i < n; i++)
        pd[i] = ps1[i] + ps2[i];
}


// Optimized function to add two integer arrays, where the arrays do not overlap, and n is a multiple of four,
// which is friendly towards NEON auto-vectorization
void add_int_array2(int * restrict pd, int * restrict ps1, int * restrict ps2, unsigned int n)
{
    unsigned int i;
    for(i = 0; i < (n >> 2) << 2; i++)
        pd[i] = ps1[i] + ps2[i];
}
