/*
** Copyright (C) ARM Limited, 2006-2011. All rights reserved.
*/

/* This file contains System Control Space (SCS) Registers */


/* SCS Registers */
#include "scs.h"

/* SCS Registers in separate section so it can be placed correctly using scatter file */
#pragma arm section zidata="scs_registers"

SCS_t SCS;

#pragma arm section


void NVIC_enableISR(unsigned isr)
{
    /* No need to do a read-modify-write; writing a 0 to the enable register does nothing */
    SCS.NVIC.Enable[ (isr/32) ] = 1<<(isr % 32);
}
