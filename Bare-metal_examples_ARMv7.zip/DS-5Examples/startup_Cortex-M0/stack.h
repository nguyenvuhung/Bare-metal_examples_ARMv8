/*
** Copyright (C) ARM Limited, 2006-2011. All rights reserved.
*/

/*
** This file contains the stack and heap addresses.
*/

#define HEAP_BASE  0x20006000
#define STACK_BASE (HEAP_BASE + 0x1000)
#define HEAP_SIZE  ((STACK_BASE-HEAP_BASE)/2)
#define STACK_SIZE ((STACK_BASE-HEAP_BASE)/2)
