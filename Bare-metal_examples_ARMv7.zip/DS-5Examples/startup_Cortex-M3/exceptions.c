/*
** Copyright (C) ARM Limited, 2006-2011. All rights reserved.
*/

/* This file contains the default exception handlers and vector table.
All exceptions are handled in Handler mode.  Processor state is automatically
pushed onto the stack when an exception occurs, and popped from the stack at
the end of the handler */


/* Exception Handlers */
/* Marking as __irq avoids them being accidentally called from elsewhere */

__irq void NMIException(void)
{   while(1); }

__irq void HardFaultException(void)
{   while(1); }

__irq void MemManageException(void)
{   while(1); }

__irq void BusFaultException(void)
{   while(1); }

__irq void UsageFaultException(void)
{   while(1); }

__irq void DebugMonitor(void)
{   while(1); }

__irq void SVCHandler(void)
{   while(1); }

__irq void PendSVC(void)
{   while(1); }

/* For SysTick, use handler in timer.c */
extern __irq void SysTickHandler(void);
/*
__irq void SysTickHandler(void)
{  while(1); }
*/

__irq void InterruptHandler(void)
{   while(1); }


/* typedef for the function pointers in the vector table */
typedef void(* const ExecFuncPtr)(void) __irq;

/* Linker-generated Stack Base address */
extern unsigned int Image$$ARM_LIB_STACKHEAP$$ZI$$Limit; /* for (default) One Region model */
extern unsigned int Image$$ARM_LIB_STACK$$ZI$$Limit;     /* for Two Region model */

/* Entry point for C run-time initialization */
extern int __main(void);


/* Create a named ELF section for the vector table that can be placed in a scatter file */
#pragma arm section rodata="vectors"

/* Vector table
The first two entries are:
    Initial SP = |Image$$ARM_LIB_STACKHEAP$$ZI$$Limit| (for default one region model)
              or |Image$$ARM_LIB_STACK$$ZI$$Limit|     (for two region model)
    Initial PC= &__main (with LSB set to indicate Thumb)
*/

ExecFuncPtr vector_table[] = {
     /* Configure Initial Stack Pointer using linker-generated symbol */
#ifdef TWO_REGION
    #pragma import(__use_two_region_memory)
    (ExecFuncPtr)&Image$$ARM_LIB_STACK$$ZI$$Limit,
#else /* default One Region model */
    (ExecFuncPtr)&Image$$ARM_LIB_STACKHEAP$$ZI$$Limit,
#endif
    (ExecFuncPtr)__main, /* Initial PC, set to entry point  */
    NMIException,
    HardFaultException,
    MemManageException,
    BusFaultException,
    UsageFaultException,
    0, 0, 0, 0,             /* Reserved */
    SVCHandler,
    DebugMonitor,
    0,                      /* Reserved */
    PendSVC,
    SysTickHandler,

    /* Add up to 240 interrupt handlers, starting here... */
    InterruptHandler,
    InterruptHandler,      /* Some dummy interrupt handlers */
    InterruptHandler
    /*
    :
    */
};

#pragma arm section
