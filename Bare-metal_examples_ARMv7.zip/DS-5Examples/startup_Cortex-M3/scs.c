/*
** Copyright (C) ARM Limited, 2006-2011. All rights reserved.
*/

/* This file contains System Control Space (SCS) Registers and MPU initialization */


/* SCS Registers and MPU Masks */
#include "scs.h"

/* SCS Registers in separate section so it can be placed correctly using scatter file */
#pragma arm section zidata="scs_registers"

SCS_t SCS;

#pragma arm section

/* Linker symbols from scatter-file */
extern unsigned int Image$$VECTORS$$Base;
extern unsigned int Image$$DATA$$Base;
extern unsigned int Image$$ARM_LIB_STACKHEAP$$Base;
extern unsigned int Image$$PROCESS_STACK$$ZI$$Base;


/* Setup MPU regions, enable the MPU, enable hardware stack alignment */
void SCS_init(void)
{
    /* Configure region 1 to cover VECTORS and CODE (Executable, Read-only) */
    /* Start address, Region field valid, Region number */
    SCS.MPU.RegionBaseAddr = ((unsigned int) &Image$$VECTORS$$Base) | REGION_VALID | 1;
    /* Access control bits, Size, Enable */
    SCS.MPU.RegionAttrSize = RO | CACHEABLE | BUFFERABLE | REGION_16K | REGION_ENABLED;

    /* Configure a region to cover DATA in RAM (Executable, Read-Write) */
    SCS.MPU.RegionBaseAddr = ((unsigned int) &Image$$DATA$$Base) | REGION_VALID | 2;
    SCS.MPU.RegionAttrSize = FULL_ACCESS | CACHEABLE | BUFFERABLE | REGION_8K | REGION_ENABLED;

    /* Configure a region to cover Heap and Main Stack (Not Executable, Read-Write) */
    SCS.MPU.RegionBaseAddr = ((unsigned int) &Image$$ARM_LIB_STACKHEAP$$Base) | REGION_VALID | 3;
    SCS.MPU.RegionAttrSize = NOT_EXEC | FULL_ACCESS | CACHEABLE | BUFFERABLE | REGION_4K | REGION_ENABLED;

    /* Configure a region to cover Process Stack (Not Executable, Read-Write) */
    SCS.MPU.RegionBaseAddr = ((unsigned int) &Image$$PROCESS_STACK$$ZI$$Base) | REGION_VALID | 4;
    SCS.MPU.RegionAttrSize = NOT_EXEC | FULL_ACCESS | CACHEABLE | BUFFERABLE | REGION_4K | REGION_ENABLED;

    /* Enable the MPU */
    SCS.MPU.Ctrl |= 1;

    /* If we are using Cortex-M3 rev1 or later, enable hardware stack alignment */
#if defined __TARGET_CPU_CORTEX_M3 && !defined __TARGET_CPU_CORTEX_M3_REV0
    SCS.ConfigCtrl |= 0x200;
#endif

    /* Force Memory Writes before continuing */
    __dsb(0xf);
    /* Flush and refill pipeline with updated permissions */
    __isb(0xf);
}


void NVIC_enableISR(unsigned isr)
{
    /* No need to do a read-modify-write; writing a 0 to the enable register does nothing */
    SCS.NVIC.Enable[ (isr/32) ] = 1<<(isr % 32);
}
