/*
** Copyright (C) ARM Limited, 2006-2011. All rights reserved.
*/

/*
** This file implements SysTick initialization and SysTick exception handler.
*/

#include "timer.h"
#include "scs.h"
#include <stdio.h>

#define RELOAD 7200000

static unsigned int ticks = 0;


/* SysTick initialization */

void SysTick_init(void)
{
#if (RELOAD > 0xFFFFFF)
   #error "Reload Value too large!"
#else
    *SysTickLoad  = RELOAD; /* reload value on timeout */
    *SysTickValue = 0;      /* clear current value */

    /* Start timer, with interrupts enabled */
    *SysTickCtrl = SysTickEnable | SysTickInterrupt | SysTickClkSource;
#endif
}


/* SysTick exception handler */
/* All exceptions are handled in Handler mode.  Processor state is automatically
pushed onto the stack when an exception occurs, and popped from the stack at
the end of the handler */

__irq void SysTickHandler(void)
{
    ticks++;
    printf("SysTick interrupt %d\n", ticks);
    fflush(stdout);
}
