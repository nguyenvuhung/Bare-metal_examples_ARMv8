/*
** Copyright (C) ARM Limited, 2006-2014. All rights reserved.
*/

/* This file contains the main() program that sets the vector table location, displays a welcome message,
initializes the MPU, enables the caches, starts the SysTick timer, initializes the Process Stack Pointer, 
changes Thread mode to Unprivileged and to use the Process Stack, then runs the main application (sorts) */


#include "scs.h"
#include "timer.h"
#include <stdio.h>
#include <math.h>

#define VectorTableOffsetRegister 0xE000ED08
#define ICIALLU 0xE000EF50
extern unsigned int Image$$VECTORS$$Base;
extern unsigned int Image$$PROCESS_STACK$$ZI$$Limit;

extern int compare_sorts(void);
float calculate( float a, float b);


/* Enable the FPU if required */
#ifdef __TARGET_FPU_VFP
extern void $Super$$__rt_lib_init(void);

void $Sub$$__rt_lib_init(void)
{
    /* Enable the FPU in both privileged and user modes by setting bits 20-23 to enable CP10 and CP11 coprocessors */
    SCS.CPACR = SCS.CPACR | (0xF << 20);
    $Super$$__rt_lib_init();
}
#endif


__declspec(noreturn) void main(void)
{
    /* Processor starts-up in Privileged Thread Mode using Main Stack */

    /* Named register variables */
    register unsigned int SP_PROCESS __asm("psp");
    register unsigned int CONTROL __asm("control");

    /* Tell the processor the location of the vector table, obtained from the scatter file */
    *(volatile unsigned int *)(VectorTableOffsetRegister) = (unsigned int) &Image$$VECTORS$$Base;

    /* Display a welcome message via semihosting */
    printf("Cortex-M7 bare-metal startup example\n");

    /* Initialize MPU */
    SCS_init();

    /* Invalidate the caches */
    *(volatile unsigned int *)(ICIALLU) = 0;

    /* Enable both I & D caches */
    SCS.ConfigCtrl = SCS.ConfigCtrl | 0x30000;

    /* Perform a float calculation */
#ifdef __TARGET_FPU_VFP
    printf("Calculating using the Cortex-M7's FPU\n");
#else
    printf("Calculating using the software floating point library (no FPU)\n");
#endif
    printf("Float result should be 80.406250\n");
    printf("Float result is        %f\n", calculate(1.0f, 2.5f));

    /* Initialize SysTick Timer */
    SysTick_init();

    /* Initialize Process Stack Pointer */
    SP_PROCESS = (unsigned int) &Image$$PROCESS_STACK$$ZI$$Limit;

    /* Change Thread mode to Unprivileged and to use the Process Stack */
    CONTROL = CONTROL | 3;

    /* Flush and refill pipeline with unprivileged permissions */
    __isb(0xf);

    /* Run the main application (sorts) */
    compare_sorts();

    while( 1 )
    {
        /* Loop forever */
    }
}


/* Float calculation to demonstrate the Cortex-M7's FPU, including float Fused Multiply Add (fma) */
float calculate( float a, float b)
{
    a = a + 3.25f;
    b = b * 4.75f;
    return fmaf(a + b, a, b);
    // result should be (4.25+11.875)*4.25 + 11.875 = 80.40625
}
