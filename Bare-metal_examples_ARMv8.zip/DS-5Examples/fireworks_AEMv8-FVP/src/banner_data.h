/* Bare-metal fireworks example */

/* Aeroplane banner (120x600) pixel array */

/* Copyright (C) ARM Limited, 2010-2013. All rights reserved. */

#define BANNER_WIDTH 600
#define BANNER_HEIGHT 120
typedef unsigned short pixel_t;
extern const pixel_t banner_data[BANNER_WIDTH * BANNER_HEIGHT];
