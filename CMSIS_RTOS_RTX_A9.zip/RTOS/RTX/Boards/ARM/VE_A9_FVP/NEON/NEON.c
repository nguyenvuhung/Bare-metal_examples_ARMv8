/*----------------------------------------------------------------------------
 *      CMSIS-RTOS  -  RTX
 *----------------------------------------------------------------------------
 *      Name:    NEON.C
 *      Purpose: RTX example program
 *----------------------------------------------------------------------------
 *
 * Copyright (c) 1999-2009 KEIL, 2009-2015 ARM Germany GmbH
 * All rights reserved.
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *  - Neither the name of ARM  nor the names of its contributors may be used 
 *    to endorse or promote products derived from this software without 
 *    specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL COPYRIGHT HOLDERS AND CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *---------------------------------------------------------------------------*/

#include "cmsis_os.h"
#define ARRSZ 8

volatile uint16_t counter;            /* counter for main thread             */
volatile uint16_t counter1;           /* counter for thread 1                */
volatile uint16_t counter2;           /* counter for thread 2                */
volatile uint16_t counter3;           /* counter for thread 3                */

/* Thread IDs */
osThreadId thread1_id;
osThreadId thread2_id;
osThreadId thread3_id;

/* Forward reference */
void job1 (void const *argument);
void job2 (void const *argument);
void job3 (void const *argument);

/* Thread definitions */
osThreadDef(job1, osPriorityAboveNormal, 1, 0);
osThreadDef(job2, osPriorityNormal, 1, 0);
osThreadDef(job3, osPriorityNormal, 1, 0);


float a[ARRSZ] = { 1.0f, 2.0f, 3.0f, 4.0f, 5.0f, 6.0f, 7.0f, 8.0f };
float b[ARRSZ] = { 1.0f, 2.0f, 3.0f, 4.0f, 5.0f, 6.0f, 7.0f, 8.0f };
float c[ARRSZ] = { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f };
float d[ARRSZ] = { 1.0f, 2.0f, 3.0f, 4.0f, 5.0f, 6.0f, 7.0f, 8.0f };
float e[ARRSZ] = { 8.0f, 7.0f, 6.0f, 5.0f, 4.0f, 3.0f, 2.0f, 1.0f };
float f[ARRSZ] = { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f };
float g[ARRSZ] = { 8.0f, 7.0f, 6.0f, 5.0f, 4.0f, 3.0f, 2.0f, 1.0f };
float h[ARRSZ] = { 8.0f, 7.0f, 6.0f, 5.0f, 4.0f, 3.0f, 2.0f, 1.0f };
float i[ARRSZ] = { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f };

/*----------------------------------------------------------------------------
 *   Thread 1: 'job1'
 *---------------------------------------------------------------------------*/
void job1 (void const *argument) {    /* higher priority to preempt job2     */
  while (1) {                         /* endless loop                        */
    int j;
    counter1++;                       /* increment counter 1                 */

    for (j = 0; j < ARRSZ; ++j) {
        c[j] = a[j] * b[j];
        f[j] = d[j] * e[j];
        i[j] = g[j] * h[j];
    }

    osDelay(10);                      /* wait for timeout: 10ms              */
  }
}

/*----------------------------------------------------------------------------
 *   Thread 2: 'job2'
 *---------------------------------------------------------------------------*/
void job2 (void const *argument) {
  while (1) {                         /* endless loop                        */
    int j;
    counter2++;                       /* increment counter 2                 */

    for (j = 0; j < ARRSZ; ++j) {
        c[j] = a[j] * b[j];
        f[j] = d[j] * e[j];
        i[j] = g[j] * h[j];
    }

    if (counter2 == 0) {              /* signal overflow of counter 2        */
      osSignalSet(thread3_id, 0x0001);/* to thread 3                         */
      osThreadYield();
    }
  }
}

/*----------------------------------------------------------------------------
 *   Thread 3: 'job3'
 *---------------------------------------------------------------------------*/
void job3 (void const *argument) {
  while (1) {                         /* endless loop                        */
    int j;
    osSignalWait(0x0001, osWaitForever);  /* wait for signal event           */
    counter3++;                       /* process overflow from counter 2     */

    for (j = 0; j < ARRSZ; ++j) {
        c[j] = a[j] * b[j];
        f[j] = d[j] * e[j];
        i[j] = g[j] * h[j];
    }
  }
}

/*----------------------------------------------------------------------------
 *   Main Thread
 *---------------------------------------------------------------------------*/
int main (void) {                     /* program execution starts here       */

  /* Set higher priority of main thread to preempt job2                      */
  osThreadSetPriority(osThreadGetId(), osPriorityAboveNormal);

  thread1_id = osThreadCreate(osThread(job1),NULL);  /* create thread1       */
  thread2_id = osThreadCreate(osThread(job2),NULL);  /* create thread2       */
  thread3_id = osThreadCreate(osThread(job3),NULL);  /* create thread3       */

  while (1) {                         /* endless loop                        */
    counter++;                        /* increment counter                   */
    osDelay(5);                       /* wait for timeout: 5ms               */
  }
}

/*----------------------------------------------------------------------------
 * end of file
 *---------------------------------------------------------------------------*/

