/**************************************************************************//**
 * @file     GLCD_FVP.c
 * @brief    PrimeCell Color LCD Controller (PL111)
 * @version
 * @date     07 February 2013
 *
 * @note
 *
 ******************************************************************************/
/* Copyright (c) 2011 - 2013 ARM LIMITED

   All rights reserved.
   Redistribution and use in source and binary forms, with or without
   modification, are permitted provided that the following conditions are met:
   - Redistributions of source code must retain the above copyright
     notice, this list of conditions and the following disclaimer.
   - Redistributions in binary form must reproduce the above copyright
     notice, this list of conditions and the following disclaimer in the
     documentation and/or other materials provided with the distribution.
   - Neither the name of ARM nor the names of its contributors may be used
     to endorse or promote products derived from this software without
     specific prior written permission.
   *
   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
   AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
   IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
   ARE DISCLAIMED. IN NO EVENT SHALL COPYRIGHT HOLDERS AND CONTRIBUTORS BE
   LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
   CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
   SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
   INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
   CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
   ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
   POSSIBILITY OF SUCH DAMAGE.
   ---------------------------------------------------------------------------*/

#include "GLCD.h"
#include "Font_6x8_h.h"
#include "Font_16x24_h.h"

/************************** Orientation  configuration ************************/

#define LANDSCAPE   1                   /* 1 for landscape, 0 for portrait    */
#define ROTATE180   0                   /* 1 to rotate the screen for 180 deg */

/*********************** Hardware specific configuration **********************/
/*---------------------- Graphic LCD size definitions ------------------------*/

#if (LANDSCAPE == 1)
#define WIDTH       320                 /* Screen Width  (in pixels)          */
#define HEIGHT      240                 /* Screen Height (in pixels)          */
#else
#define WIDTH       240                 /* Screen Width  (in pixels)          */
#define HEIGHT      320                 /* Screen Height (in pixels)          */
#endif
#define BPP         16                  /* Bits per pixel                     */
#define BYPP        ((BPP+7)/8)         /* Bytes per pixel                    */

/*--------------- Graphic LCD interface hardware definitions -----------------*/

#define BG_COLOR  0                     /* Background color                   */
#define TXT_COLOR 1                     /* Text color                         */

 
/*---------------------------- Global variables ------------------------------*/

/******************************************************************************/
static unsigned int Color[2] = {0xffff, 0x0000};

/************************ Local auxiliary functions ***************************/

/* Configure LCD for VE platforms */
void init_lcd_ve( void )
{
    VE_SYS_CFG_DATA = 5400000;
    VE_SYS_CFG_CTRL = 0x80000000 | (1<<30) | (1<<20) | (0<<16) | (0<<12) | (1<<0);

    VE_SYS_CFG_DATA = 0;
    VE_SYS_CFG_CTRL = 0x80000000 | (1<<30) | (7<<20) | (0<<16) | (0<<12) | (0<<0);
}

/* Configure PL111 CLCD */
void init_pl111( unsigned int  width,
                 unsigned int  height,
                 unsigned int  frame_base )
{
    /* Timing number for an 8.4" LCD screen for use on a VGA screen */
    unsigned int TIM0_VAL = ( (((width/16)-1)<<2) | (63<<8) | (31<<16) | (63<<8) );
    unsigned int TIM1_VAL = ( (height - 1) | (24<<10) | (11<<16) | (9<<24) );
    unsigned int TIM2_VAL = ( (0x7<<11) | ((width - 1)<<16) | (1<<26) );

    /* Program the CLCD controller registers and start the CLCD */
    GLCD->LCDTiming0 = TIM0_VAL;
    GLCD->LCDTiming1 = TIM1_VAL;
    GLCD->LCDTiming2 = TIM2_VAL;
    GLCD->LCDTiming3 = 0;
    GLCD->LCDUPBASE  = frame_base;
    GLCD->LCDLPBASE  = 0;
    GLCD->LCDIMSC    = 0;

    /* Set the control register: 16BPP 5:6:5, Power OFF */
    GLCD->LCDControl = (1<<0) | (6<<1) | (1<<5);

    /* Power ON */
    GLCD->LCDControl |= (1<<11);
}

/************************ Exported functions **********************************/

/*******************************************************************************
* Initialize the Graphic LCD controller                                        *
*   Parameter:                                                                 *
*   Return:                                                                    *
*******************************************************************************/

void GLCD_Init (void)
{
	/* Configure system */
    init_lcd_ve();
    init_pl111( WIDTH, HEIGHT, FRAMEBUFFER);
}


/*******************************************************************************
* Set draw window region to whole screen                                       *
*   Parameter:                                                                 *
*   Return:                                                                    *
*******************************************************************************/

void GLCD_WindowMax (void) {
}


/*******************************************************************************
* Draw a pixel in foreground color                                             *
*   Parameter:      x:        horizontal position                              *
*                   y:        vertical position                                *
*   Return:                                                                    *
*******************************************************************************/

void GLCD_PutPixel (unsigned int x, unsigned int y) {
    ((volatile unsigned short *)FRAMEBUFFER + x + y*WIDTH)[0] = Color[TXT_COLOR];
}


/*******************************************************************************
* Set foreground color                                                         *
*   Parameter:      color:    foreground color                                 *
*   Return:                                                                    *
*******************************************************************************/

void GLCD_SetTextColor (unsigned short color) {

  Color[TXT_COLOR] = color;
}


/*******************************************************************************
* Set background color                                                         *
*   Parameter:      color:    background color                                 *
*   Return:                                                                    *
*******************************************************************************/

void GLCD_SetBackColor (unsigned short color) {

  Color[BG_COLOR] = color;
}


/*******************************************************************************
* Clear display                                                                *
*   Parameter:      color:    display clearing color                           *
*   Return:                                                                    *
*******************************************************************************/

void GLCD_Clear (unsigned short color) {
	unsigned int i;

	for (i = 0; i <= (WIDTH*HEIGHT); i++)
	{
		((volatile unsigned short *)FRAMEBUFFER)[i] = color;
	}
}

/*******************************************************************************
* Draw character on given position                                             *
*   Parameter:      x:        horizontal position                              *
*                   y:        vertical position                                *
*                   cw:       character width in pixel                         *
*                   ch:       character height in pixels                       *
*                   c:        pointer to character bitmap                      *
*   Return:                                                                    *
*******************************************************************************/

void GLCD_DrawChar (unsigned int x, unsigned int y, unsigned int cw, unsigned int ch, unsigned char *c) {
  unsigned int i, j, pixs, bit;

  for (j = 0; j < ch; j++) {
    pixs = *(unsigned short *)c;
    c += 2;

    for (i = 0; i < cw; i++) {
      bit = Color[(pixs >> i) & 1];
      ((volatile unsigned short *)FRAMEBUFFER + j*(WIDTH) + x + y*WIDTH)[i] = bit;
    }
  }

}


/*******************************************************************************
* Display character on given line                                              *
*   Parameter:      ln:       line number                                      *
*                   col:      column number                                    *
*                   fi:       font index (0 = 6x8, 1 = 16x24)                  *
*                   c:        ascii character                                  *
*   Return:                                                                    *
*******************************************************************************/

void GLCD_DisplayChar (unsigned int ln, unsigned int col, unsigned char fi, unsigned char c) {

  c -= 32;
  switch (fi) {
    case 0:  /* Font 6 x 8 */
      GLCD_DrawChar(col *  6, ln *  8,  6,  8, (unsigned char *)&Font_6x8_h  [c * 8]);
      break;
    case 1:  /* Font 16 x 24 */
      GLCD_DrawChar(col * 16, ln * 24, 16, 24, (unsigned char *)&Font_16x24_h[c * 24]);
      break;
  }
}


/*******************************************************************************
* Disply string on given line                                                  *
*   Parameter:      ln:       line number                                      *
*                   col:      column number                                    *
*                   fi:       font index (0 = 6x8, 1 = 16x24)                  *
*                   s:        pointer to string                                *
*   Return:                                                                    *
*******************************************************************************/

void GLCD_DisplayString (unsigned int ln, unsigned int col, unsigned char fi, unsigned char *s) {

  while (*s) {
    GLCD_DisplayChar(ln, col++, fi, *s++);
  }
}


/*******************************************************************************
* Clear given line                                                             *
*   Parameter:      ln:       line number                                      *
*                   fi:       font index (0 = 6x8, 1 = 16x24)                  *
*   Return:                                                                    *
*******************************************************************************/

void GLCD_ClearLn (unsigned int ln, unsigned char fi) {
  unsigned char i;
  unsigned char buf[60];

  switch (fi) {
    case 0:  /* Font 6 x 8 */
      for (i = 0; i < (WIDTH+5)/6; i++)
        buf[i] = ' ';
      buf[i+1] = 0;
      break;
    case 1:  /* Font 16 x 24 */
      for (i = 0; i < (WIDTH+15)/16; i++)
        buf[i] = ' ';
      buf[i+1] = 0;
      break;
  }
  GLCD_DisplayString (ln, 0, fi, buf);
}

/*******************************************************************************
* Draw bargraph                                                                *
*   Parameter:      x:        horizontal position                              *
*                   y:        vertical position                                *
*                   w:        maximum width of bargraph (in pixels)            *
*                   h:        bargraph height                                  *
*                   val:      value of active bargraph (in 1/1024)             *
*   Return:                                                                    *
*******************************************************************************/

void GLCD_Bargraph (unsigned int x, unsigned int y, unsigned int w, unsigned int h, unsigned int val) {

  int i,j;
  val = (val * w) >> 10;                /* Scale value                        */

  for (i = 0; i < h; i++) {
      for (j = 0; j <= w-1; j++) {
        if(j >= val) {
            ((volatile unsigned short *)FRAMEBUFFER + i*(WIDTH) + x + y*WIDTH)[j] = Color[BG_COLOR];
        } else {
        	((volatile unsigned short *)FRAMEBUFFER + i*(WIDTH) + x + y*WIDTH)[j] = Color[TXT_COLOR];
        }
      }
    }
}


/*******************************************************************************
* Display graphical bitmap image at position x horizontally and y vertically   *
* (This function is optimized for 16 bits per pixel format, it has to be       *
*  adapted for any other bits per pixel format)                                *
*   Parameter:      x:        horizontal position                              *
*                   y:        vertical position                                *
*                   w:        width of bitmap                                  *
*                   h:        height of bitmap                                 *
*                   bitmap:   address at which the bitmap data resides         *
*   Return:                                                                    *
*******************************************************************************/

void GLCD_Bitmap (unsigned int x, unsigned int y, unsigned int w, unsigned int h, unsigned char *bitmap) {
   int i, j;
   unsigned short *bitmap_ptr = (unsigned short *)bitmap;
   unsigned short pixel;

   for (j = 0; j < h; j++) {
    for (i = 0; i < w; i++) {
      pixel = bitmap_ptr[i+j*w];
      if (pixel != 0xffff)
    	  pixel++;
      ((volatile unsigned short *)FRAMEBUFFER + j*(WIDTH) + x + y*WIDTH)[i] = pixel;
    }
  }
}



/*******************************************************************************
* Scroll content of the whole display for dy pixels vertically                 *
*   Parameter:      dy:       number of pixels for vertical scroll             *
*   Return:                                                                    *
*******************************************************************************/

void GLCD_ScrollVertical (unsigned int dy) {
/*Not implemented*/
}

/*******************************************************************************
* Write a command to the LCD controller                                        *
*   Parameter:      cmd:      command to write to the LCD                      *
*   Return:                                                                    *
*******************************************************************************/
void GLCD_WrCmd (unsigned char cmd) {
/*Not implemented*/
}


/*******************************************************************************
* Write a value into LCD controller register                                   *
*   Parameter:      reg:      lcd register address                             *
*                   val:      value to write into reg                          *
*   Return:                                                                    *
*******************************************************************************/
void GLCD_WrReg (unsigned char reg, unsigned short val) {
	/*Not implemented*/
}
/******************************************************************************/
