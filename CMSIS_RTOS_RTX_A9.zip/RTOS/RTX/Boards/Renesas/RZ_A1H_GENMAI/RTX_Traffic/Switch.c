/*
** Copyright (C) ARM Limited, 2011-2013. All rights reserved.
*/

/* Simple GPIO driver for a hardware switch */

#include "Switch.h"

/*switch*/
unsigned int Get_Switch(void)
{
    //your code here
    return 0;
}


void Set_Switch(unsigned int val)
{
    //your code here
}
