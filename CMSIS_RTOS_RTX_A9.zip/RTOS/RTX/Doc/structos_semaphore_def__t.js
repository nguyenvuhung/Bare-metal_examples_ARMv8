var structos_semaphore_def__t =
[
    [ "semaphore", "structos_semaphore_def__t.html#a83324f0a93a76a6c99f5a21bbe9d9209", null ]
];