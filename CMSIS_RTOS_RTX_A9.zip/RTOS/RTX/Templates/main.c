
#include "cmsis_os.h"          // CMSIS-RTOS API Functions

int main (void) {              // 'main' Thread Function
  for (;;);
}
