Juno Demo Setup
---------------

This directory contains 2 scripts to enable a Juno platform running Linux to run
the CSAL demos correctly.

no_cpu_idle.sh    - Linux script that prevents idle cores going into power down
juno_wake_dap.cst - CSAT script to power up the DAP and CoreSight debug

See "Juno Platform - Additional Configuration when using the CSAL and Demos" in readme_demos.md
