DTSL Example configdb
---------------------

This directory contains the DS-5 configdb entries used/referenced by the DTSL
examples.

The DS-5 'configdb' contains information on known target boards as well as
information on device register sets, flash programming algorithms, peripheral
registers, OS extensions, utility scripts and other useful information to
help support the debugger. The main DS-5 installation contains its own configdb
directory (<DS-5 install folder>\sw\debugger\configdb), but this can be extended
by a user specifying the location of their own board specific descriptions. This
directory is an example of such a configdb extension.

For more information on the data contained within this directory, please refer 
to the DTSL documentation contained in the DS-5 Debugger User Guide,
within the chapter entitled 'Debug and Trace Services Layer (DTSL)'.
