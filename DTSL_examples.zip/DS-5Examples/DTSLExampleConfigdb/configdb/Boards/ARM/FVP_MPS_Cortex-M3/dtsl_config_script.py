from com.arm.debug.dtsl.configurations import DTSLv1
from com.arm.debug.dtsl.components import ConnectableDevice

NUM_CORES_CORTEX_M3 = 1
CORTEX_M3_START_ID = 1

class DtslScript(DTSLv1):
    @staticmethod
    def getOptionList():
        return [
            DTSLv1.tabSet("options", "Options", childOptions=[
            ])
        ]
    
    def __init__(self, root):
        DTSLv1.__init__(self, root)
        # locate devices on the platform and create corresponding objects
        self.discoverDevices()
        self.mgdPlatformDevs = set()
        self.exposeCores()
        self.setManagedDevices(self.mgdPlatformDevs)
    
    # +----------------------------+
    # | Target dependent functions |
    # +----------------------------+
    
    def discoverDevices(self):
        '''find and create devices'''
        cortexM3coreDev = 0
        self.cortexM3cores = []
        for i in range(0, NUM_CORES_CORTEX_M3):
            # create core
            dev = ConnectableDevice(self, i+CORTEX_M3_START_ID, "Cortex-M3_%d" % i)
            self.cortexM3cores.append(dev)

    def exposeCores(self):
        for core in self.cortexM3cores:
            self.addDeviceInterface(core)

    # +--------------------------------+
    # | Callback functions for options |
    # +--------------------------------+
    
    def optionValuesChanged(self):
        '''Callback to update the configuration state after options are changed'''
        optionValues = self.getOptionValues()

    def getManagedDevices(self, traceKey):
        '''Get the required set of managed devices for this configuration'''
        return self.mgdPlatformDevs
