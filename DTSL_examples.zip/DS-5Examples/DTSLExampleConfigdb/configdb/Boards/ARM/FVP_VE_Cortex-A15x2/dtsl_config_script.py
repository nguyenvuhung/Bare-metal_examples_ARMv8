from com.arm.debug.dtsl.configurations import DTSLv1
from com.arm.debug.dtsl.components import Device
from com.arm.debug.dtsl.components import CadiSyncSMPDevice

NUM_CORES_CORTEX_A15 = 2
CORTEX_A15_START_ID = 1


class DtslScript(DTSLv1):
    @staticmethod
    def getOptionList():
        return [
            DTSLv1.tabSet("options", "Options", childOptions=[
            ])
        ]
    
    def __init__(self, root):
        DTSLv1.__init__(self, root)
        
        # locate devices on the platform and create corresponding objects
        self.discoverDevices()
        
        self.mgdPlatformDevs = set()
        
        self.exposeCores()
        
        self.setupCadiSyncSMP()
        self.setManagedDevices(self.mgdPlatformDevs)
    
    # +----------------------------+
    # | Target dependent functions |
    # +----------------------------+
    
    def discoverDevices(self):
        '''find and create devices'''
        
        cortexA15coreDev = 0
        self.cortexA15cores = []
        
        streamID = 0
        
        for i in range(0, NUM_CORES_CORTEX_A15):
            # create core
            dev = Device(self, i+CORTEX_A15_START_ID, "Cortex-A15_%d" % i)
            self.cortexA15cores.append(dev)
            
    def exposeCores(self):
        for core in self.cortexA15cores:
            self.addDeviceInterface(core)
    
    def setupCadiSyncSMP(self):
        '''Create SMP device using RDDI synchronization'''
        
        # create SMP device and expose from configuration
        # Cortex-A15x2 SMP
        smp = CadiSyncSMPDevice(self, "Cortex-A15 SMP", self.cortexA15cores)
        self.addDeviceInterface(smp)
    
    # +--------------------------------+
    # | Callback functions for options |
    # +--------------------------------+
    
    def optionValuesChanged(self):
        '''Callback to update the configuration state after options are changed'''
        optionValues = self.getOptionValues()
    def getManagedDevices(self, traceKey):
        '''Get the required set of managed devices for this configuration'''
        return self.mgdPlatformDevs | self.mgdTraceDevs.get(traceKey, set())
    

