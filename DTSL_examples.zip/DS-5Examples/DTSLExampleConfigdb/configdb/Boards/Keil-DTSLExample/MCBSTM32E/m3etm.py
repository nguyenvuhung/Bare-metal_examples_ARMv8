from com.arm.debug.dtsl.configurations import DTSLv1
from com.arm.debug.dtsl.components import FormatterMode
from com.arm.debug.dtsl.components import GenericDevice
from com.arm.debug.dtsl.components import ETMv3_4TraceSource

class M3_ETM(ETMv3_4TraceSource):
    '''A Cortex-M3 specific ETM which requires the unlock register setting'''
    def __init__(self, root, deviceID, streamID, deviceName):
        GenericDevice.__init__(self, root, deviceID, streamID, deviceName)

    def postConnect(self):
        ETMLAR = 0x03ec # Lock Access Register
        ETMLSR = 0x03ed # Lock Status Register
        self.writeRegister(ETMLAR, 0xc5acce55)
        if (self.readRegister(ETMLSR) & 0x2) != 0:
            raise Exception('Can\'t lock ETM Registers')
        ETMv3_4TraceSource.postConnect(self)

    def preDisconnect(self):
        if self.isConnected():
            ETMLAR = 0x03ec # Lock Access Register
            self.writeRegister(ETMLAR, 0)
            ETMv3_4TraceSource.preDisconnect(self)

    # Disable trace triggers and start stop points as currently unsupported
    def hasTriggers(self):
        return False

    def hasTraceStartPoints(self):
        return False
    
    def hasTraceStopPoints(self):
        return False
    
    def hasTraceRanges(self):
        return False

    def setStreamID(self, streamID):
        pass

