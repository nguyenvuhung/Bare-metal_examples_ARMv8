from com.arm.debug.dtsl import DTSLException
from com.arm.debug.dtsl.configurations import DTSLv1
from com.arm.debug.dtsl.components import FormatterMode
from com.arm.debug.dtsl.components import CortexM_AHBAP
from com.arm.debug.dtsl.components import CSDAP
from com.arm.debug.dtsl.components import MemoryRouter
from com.arm.debug.dtsl.components import DapMemoryAccessor
from com.arm.debug.dtsl.components import AHBCortexMMemAPAccessor
from com.arm.debug.dtsl.components import Device
from com.arm.debug.dtsl.components import ConnectableDevice
from com.arm.debug.dtsl.configurations.options import IIntegerOption
from com.arm.debug.dtsl.components import DSTREAMTraceCapture
from com.arm.debug.dtsl.components import V7M_CSTPIU
from com.arm.debug.dtsl.components import V7M_ITMTraceSource
from m3etm import M3_ETM as V7M_ETMTraceSource
from com.arm.rddi import RDDI_ACC_SIZE

from struct import pack, unpack
from jarray import zeros

class ResetHookedDevice(ConnectableDevice):
    def __init__(self, root, devNo, name):
        Device.__init__(self, root, devNo, name)
        self.parent = root

    def systemReset(self, resetType):
        Device.systemReset(self, resetType)
        # Notify root configuration
        self.parent.postReset()


class DSTREAMDebugAndTrace(DTSLv1):
    '''A top level configuration class which supports debug and trace'''

    @staticmethod
    def getOptionList():
        '''The method which specifies the configuration options which
           the user can edit via the launcher panel |Edit...| button
        '''
        return [
            DTSLv1.tabSet(
                name='options',
                displayName='Options',
                childOptions=[
                    DSTREAMDebugAndTrace.getTraceBufferOptionsPage(),
                    DSTREAMDebugAndTrace.getETMOptionsPage(),
                    DSTREAMDebugAndTrace.getITMOptionsPage()
                ]
            )
        ]

    @staticmethod
    def getTraceBufferOptionsPage():
        # If you change the position or name of the traceCapture
        # device option you MUST modify the project_types.xml to
        # tell the debugger about the new location/name
        return DTSLv1.tabPage(
            name='traceBuffer', 
            displayName='Trace Buffer',
            childOptions=[
                DTSLv1.enumOption(
                    name='traceCaptureDevice',
                    displayName='Trace capture method',
                    defaultValue='DSTREAM',
                    values=[
                        ('none', 'No trace capture device'),
                        ('DSTREAM', 'DSTREAM 4GB Trace Buffer')
                    ]
                ),
                DTSLv1.booleanOption(
                    name='clearTraceOnConnect',
                    displayName='Clear Trace Buffer on connect',
                    defaultValue=True
                ),
                DTSLv1.booleanOption(
                    name='startTraceOnConnect',
                    displayName='Start Trace Buffer on connect',
                    defaultValue=True
                ),
                DTSLv1.enumOption(
                    name='traceWrapMode',
                    displayName='Trace full action',
                    defaultValue='wrap',
                    values=[
                        ('wrap', 'Trace wraps on full and continues to store data'),
                        ('stop', 'Trace halts on full')
                    ]
                )
            ]
        )

    @staticmethod
    def getETMOptionsPage():
        return DTSLv1.tabPage(
            name='ETM',
            displayName='Instruction Trace',
            childOptions=[
                DTSLv1.booleanOption(
                    name='cortexM3coreTraceEnabled',
                    displayName='Enable Cortex-M3 instruction trace',
                    defaultValue=False,
                    isDynamic=True
                )
            ]
        )

    @staticmethod
    def getTargetITMOptions():
        return DTSLv1.infoElement(
            name='target',
            displayName='Target ITM Settings',
            description='These are the target programmed ITM settings the debugger needs to know about',
            childOptions=[
                DTSLv1.integerOption(
                    name='targetITMATBID',
                    displayName='ITM ATBID',
                    description='The ITM ATB ID as setup by the target (1..112)',
                    minimum=1,
                    maximum=112,
                    defaultValue=2
                )
            ]
        )

    @staticmethod
    def getDebuggerITMOptions():
        return DTSLv1.infoElement(
            name='debugger',
            displayName='Debugger ITM Settings',
            description='These are the settings the debugger will write to the ITM',
            childOptions=[
                DTSLv1.booleanOption(
                    name='TSENA',
                    displayName = 'Enable differential timestamps',
                    defaultValue=True,
                    isDynamic=True
                ),
                DTSLv1.enumOption(
                    name='TSPrescale',
                    displayName='Timestamp prescale',
                    defaultValue='none',
                    isDynamic=True,
                    values = [
                        ('none', 'no prescaling'),
                        ('d4',   'divide by 4'),
                        ('d16',  'divide by 16'),
                        ('d64',  'divide by 64')
                    ]
                ),
                DTSLv1.booleanOption(
                    name='DWTENA',
                    displayName = 'Enable DWT stimulus',
                    defaultValue=True,
                    isDynamic=True
                ),
                DTSLv1.integerOption(
                    name='STIMENA',
                    displayName = 'Stimulus port enables',
                    minimum=0x00000000,
                    maximum=0xFFFFFFFF,
                    defaultValue=0xFFFFFFFF,
                    display=IIntegerOption.DisplayFormat.HEX,
                    isDynamic=True
                ),
                DTSLv1.infoElement(
                    name='PRIVMASK',
                    displayName = 'PRIVMASK - Allow USER mode access',
                    childOptions=[
                        DTSLv1.booleanOption(
                            name='[7:0]',
                            displayName='Ports [7:0]',
                            defaultValue=True,
                            isDynamic=True
                        ),
                        DTSLv1.booleanOption(
                            name='[15:8]',
                            displayName='Ports [15:8]',
                            defaultValue=True,
                            isDynamic=True
                        ),
                        DTSLv1.booleanOption(
                            name='[23:16]',
                            displayName='Ports [23:16]',
                            defaultValue=True,
                            isDynamic=True
                        ),
                        DTSLv1.booleanOption(
                            name='[31:24]',
                            displayName='Ports [31:24]',
                            defaultValue=True,
                            isDynamic=True
                        )
                    ]
                )
            ]
        )

    @staticmethod
    def getITMOptionsPage():
        return DTSLv1.tabPage(
            name='ITM',
            displayName='ITM',
            childOptions=[
                DTSLv1.booleanOption(
                    name='itmTraceEnabled',
                    displayName = 'Enable ITM Trace',
                    defaultValue=False,
                    isDynamic=True,
                    childOptions = [
                        DTSLv1.radioEnumOption(
                            name='itmowner',
                            displayName = 'ITM Owner',
                            description='Specify whether the target or the debugger will own/setup the ITM',
                            defaultValue='Target',
                            values=[
                                ('Target', 'The target will setup the ITM', DSTREAMDebugAndTrace.getTargetITMOptions()),
                                ('Debugger', 'DS-5 Debugger will setup the ITM', DSTREAMDebugAndTrace.getDebuggerITMOptions())
                            ]
                        )
                    ]
                )
            ]
        )

    def __init__(self, root):
        '''The class constructor'''
        # base class construction
        DTSLv1.__init__(self, root)
        # create the devices in the platform
        self.cores = []
        self.traceSources = []
        self.reservedATBIDs = {}
        self.createDevices()
        self.setupDSTREAMTrace()
        for core in self.cores:
            self.addDeviceInterface(core)

    def createDevices(self):
        # create MEMAP
        devID = self.findDevice("CSMEMAP")
        self.AHB = CortexM_AHBAP(self, devID, "CSMEMAP")
        # create core
        devID = self.findDevice("Cortex-M3")
        self.cortexM3 = ResetHookedDevice(self, devID, "Cortex-M3")
        self.cortexM3.registerAddressFilters(
                [AHBCortexMMemAPAccessor("AHB", self.AHB, "AHB bus accessed via AP_0")])
        self.cores.append(self.cortexM3)

        # create the ETM disabled by default - will enable with option
        devID = self.findDevice("CSETM")
        self.ETM = V7M_ETMTraceSource(self, devID, 1, "ETM")
        self.ETM.setEnabled(False)
        self.traceSources.append(self.ETM)
        # ITM disabled by default - will enable with option
        devID = self.findDevice("CSITM")
        self.ITM = V7M_ITMTraceSource(self, devID, 2, "ITM")
        #self.ITM = M3_ITM(self, devID, 2, "ITM")
        self.ITM.setEnabled(False)
        self.traceSources.append(self.ITM)
        # TPIU
        devID = self.findDevice("CSTPIU")
        self.TPIU = V7M_CSTPIU(self, devID, "TPIU", self.AHB)
        # DSTREAM
        self.DSTREAM = DSTREAMTraceCapture(self, "DSTREAM")
        self.DSTREAM.setTraceMode(DSTREAMTraceCapture.TraceMode.Continuous)

    def setupDSTREAMTrace(self):
        '''Setup DSTREAM trace capture'''
        # configure the TPIU for continuous mode
        self.TPIU.setPortSize(4)
        # configure the DSTREAM for continuous trace
        self.DSTREAM.setTraceMode(DSTREAMTraceCapture.TraceMode.Continuous)
        self.DSTREAM.setPortWidth(4)
        # register other trace components
        self.DSTREAM.setTraceComponentOrder([ self.TPIU ])
        # tell DSTREAM about its trace sources
        self.DSTREAM.addTraceSource(self.ETM, self.cortexM3.getID())
        self.DSTREAM.addTraceSource(self.ITM)
        # register the DSTREAM with the configuration
        self.addTraceCaptureInterface(self.DSTREAM)
        # automatically handle connection/disconnection to trace components
        self.setManagedDevices( [self.AHB, self.ETM, self.ITM, self.TPIU, self.DSTREAM] )

    def setETMEnabled(self, enabled):
        '''Configuration option setter method to enable/disable the ETM trace source'''
        self.ETM.setEnabled(enabled)

    def setDSTREAMTraceEnabled(self, enabled):
        '''Configuration option setter method to enable/disable DSTREAM trace capture'''
        self.TPIU.setEnabled(enabled)

    def setTraceWrapMode(self, mode):
        '''Configuration option setter method for the buffer wrap mode'''
        if mode == "wrap":
            self.DSTREAM.setWrapOnFull(True)
        else:
            self.DSTREAM.setWrapOnFull(False)

    def setClearTraceOnConnect(self, enabled):
        '''Configuration option setter method to enable/disable clear trace buffer on connect'''
        self.DSTREAM.setClearOnConnect(enabled)

    def setStartTraceOnConnect(self, enabled):
        '''Configuration option setter method to enable/disable auto start trace buffer on connect only'''
        self.DSTREAM.setAutoStartTraceOnConnect(enabled)

    def writeMem(self, addr, value):
        self.cores[0].memWrite(0, addr, RDDI_ACC_SIZE.RDDI_ACC_WORD, 0x10000, False, 4, pack('<I', value))

    def readMem(self, addr):
        buffer = zeros(4, 'b')
        self.cores[0].memRead(0, addr, RDDI_ACC_SIZE.RDDI_ACC_WORD, 0x10000, 4, buffer)
        return unpack('<I', buffer)[0]

    def setupPinMUXForTrace(self):
        '''Sets up the IO Pin MUX to select 4 bit TPIU trace'''
        addrDBGMCU_CR = 0xE0042004
        value = self.readMem(addrDBGMCU_CR)
        value |=  0xE0 # TRACE_MODE=11 (4 bit port), TRACE_IOEN=1
        self.writeMem(addrDBGMCU_CR, value)

    def enableSystemTrace(self):
        '''Sets up the system to enable trace
           For a Cortex-M3 system we must make sure that the
           TRCENA bit (24) in the DEMCR registers is set.
           NOTE: This bit is normally set by the DSTREAM Cortex-M3
                 template - but we set it ourselves here in case
                 no one connects to the Cortex-M3 device.
        '''
        addrDEMCR = 0xE000EDFC
        bitTRCENA = 0x01000000
        value = self.readMem(addrDEMCR)
        value |= bitTRCENA
        self.writeMem(addrDEMCR, value)

    def setITMEnabled(self, enabled):
        '''Enable/disable the ITM trace source'''
        self.ITM.setEnabled(enabled)

    def setITMEnableTimestamps(self, enabled):
        '''Enable/disable the ITM timestamp'''
        self.ITM.setEnableTimestamps(enabled)

    def setITMTSPrescale(self, TSPrescale):
        '''Set the ITM timestamp prescale value'''
        psValue = {"none":0, "d4":1, "d16":2, "d64":3}
        self.ITM.setTSPrescale(psValue[TSPrescale])

    def setITMEnableDWT(self, enabled):
        '''Enable/disable ITM DWT output support'''
        self.ITM.setEnableDWT(enabled)

    def setITMPortEnables(self, portBitSet):
        '''Set the ITM port enable bitset'''
        self.ITM.setPortEnables(portBitSet)

    def setITMPortPrivileges(self, priv_7_0, priv_15_8, priv_23_16, priv_31_24):
        '''Set the ITM port privilage bits'''
        self.ITM.setPortPrivileges(priv_7_0, priv_15_8, priv_23_16, priv_31_24)

    def setITMOwnedByDebugger(self, state):
        self.ITM.setIsSetupByTarget(not state)

    # override
    def postConnect(self):
        if self.getOptionValue("options.traceBuffer.traceCaptureDevice") == "DSTREAM":
            self.setupPinMUXForTrace()
            self.enableSystemTrace()
        DTSLv1.postConnect(self)

    def postReset(self):
        '''Makes sure the debug configuration is re-instated
           following a reset event
        '''
        self.setupPinMUXForTrace()
        self.enableSystemTrace()

    def updateATBIDAssignments(self):
        '''Modifies all trace source ATB IDs to take in to account
           any reserved IDs (e.g. ones that are hard coded in the target).
           When we are done, all trace sources will have a unique ID and
           those that are preset will have the correct values.
        '''
        atbID = 1 # First valid ATB ID is 1
        for source in self.traceSources:
            if source.getName() in self.reservedATBIDs:
                # This source has a reserved ATB ID so set it
                # from the reserved list
                source.setStreamID(self.reservedATBIDs[source.getName()])
            else:
                # Make sure the current ID is not on the reserved list
                while atbID in self.reservedATBIDs.values():
                    atbID = atbID + 1
                source.setStreamID(atbID)
                atbID = atbID + 1

    def traceDeviceIsDSTREAM(self, obase):
        ''' Indicates if the trace capture device is configured to be DSTREAM
            Param: obase the option path string to the trace buffer options
        '''
        return self.getOptionValue(obase+".traceBuffer.traceCaptureDevice") == "DSTREAM"

    def debuggerOwnsITM(self, obase):
        ''' Indicates if the debugger owns the ITM (vs the target owning it)
            Param: obase the option path string to the ITM owner option
        '''
        return self.getOptionValue(obase) == "Debugger"

    def setITMOptions(self, obase):
        '''Configures the ITM options for the use case when the debugger
           has control/ownership of the ITM
           Param: obase the option path string to the debugger's ITM options
        '''
        self.setITMEnableTimestamps(self.getOptionValue(obase+".TSENA"))
        self.setITMTSPrescale(self.getOptionValue(obase+".TSPrescale"))
        self.setITMEnableDWT(self.getOptionValue(obase+".DWTENA"))
        self.setITMPortEnables(self.getOptionValue(obase+".STIMENA"))
        self.setITMPortPrivileges(
            self.getOptionValue(obase+".PRIVMASK.[7:0]"),
            self.getOptionValue(obase+".PRIVMASK.[15:8]"),
            self.getOptionValue(obase+".PRIVMASK.[23:16]"),
            self.getOptionValue(obase+".PRIVMASK.[31:24]"))

    def setDSTREAMOptions(self, obase):
        '''Configures the DSTREAM options
           Param: obase the option path string to the DSTREAM options
        '''
        self.setTraceWrapMode(self.getOptionValue(obase+".traceWrapMode"))
        self.setClearTraceOnConnect(self.getOptionValue(obase+".clearTraceOnConnect"))
        self.setStartTraceOnConnect(self.getOptionValue(obase+".startTraceOnConnect"))

    def setInitialOptions(self, obase):
        '''Takes the configuration options and configures the
           DTSL objects prior to target connection
           Param: obase the option path string to top level options
        '''
        if self.traceDeviceIsDSTREAM(obase):
            self.setDSTREAMTraceEnabled(True)
            self.setDSTREAMOptions(obase+".traceBuffer")
            obaseETM = obase+".ETM"
            obaseITM = obase+".ITM"
            self.setETMEnabled(self.getOptionValue(obaseETM+".cortexM3coreTraceEnabled"))
            self.reservedATBIDs = {}
            self.setITMEnabled(self.getOptionValue(obaseITM+".itmTraceEnabled"))
            obaseITMOwner = obaseITM+".itmTraceEnabled.itmowner"
            if self.debuggerOwnsITM(obaseITMOwner):
                self.setITMOwnedByDebugger(True);
                self.setITMOptions(obaseITMOwner+".debugger")
            else:
                self.setITMOwnedByDebugger(False);
                self.reservedATBIDs["ITM"] = self.getOptionValue(obaseITMOwner+".target.targetITMATBID")
            self.updateATBIDAssignments()
        else:
            self.setDSTREAMTraceEnabled(False)
            self.setETMEnabled(False)
            self.setITMEnabled(False)

    def updateDynamicOptions(self, obase):
        '''Takes any changes to the dynamic options and
           applies them. Note that some trace options may
           not take effect until trace is (re)started
           Param: obase the option path string to top level options
        '''
        if self.traceDeviceIsDSTREAM(obase):
            obaseETM = obase+".ETM"
            self.setETMEnabled(self.getOptionValue(obaseETM+".cortexM3coreTraceEnabled"))
            obaseITM = obase+".ITM"
            if self.getOptionValue(obaseITM+".itmTraceEnabled"):
                self.setITMEnabled(True)
                obaseITMOwner = obaseITM+".itmTraceEnabled.itmowner"
                if self.debuggerOwnsITM(obaseITMOwner):
                    self.setITMOptions(obaseITMOwner+".debugger")
            else:
                self.setITMEnabled(False)

    def optionValuesChanged(self):
        '''Callback to update the configuration state after options are changed.
           This will be called:
              * after construction but before device connection
              * during a debug session should the user change the DTSL options
        '''
        obase = "options"
        if self.isConnected():
            self.updateDynamicOptions(obase)
        else:
            self.setInitialOptions(obase)


class DebugOnly(DTSLv1):
    '''A top level configuration class which only supports debug (no trace)'''
    def __init__(self, root):
        DTSLv1.__init__(self, root)
        # create the devices in the platform
        self.cores = []
        self.createDevices()
        for core in self.cores:
            self.addDeviceInterface(core)


    # Target dependent functions
    def createDevices(self):
        # create core
        devID = self.findDevice("Cortex-M3")
        self.cortexM3 = ConnectableDevice(self, devID, "Cortex-M3")

        # Use MemAP if available (on DSTREAM), otherwise fall back to DAP (on ULINK)
        try:
            devID = self.findDevice("CSMEMAP")
            self.AHB = CortexM_AHBAP(self, devID, "CSMEMAP")
            self.cortexM3.registerAddressFilters(
                [AHBCortexMMemAPAccessor("AHB", self.AHB, "AHB bus accessed via AP_0")])
            self.cores.append(self.cortexM3)
            self.setManagedDevices([self.AHB])
        except DTSLException:
            devID = self.findDevice("ARMCS-DP")
            self.DAP = CSDAP(self, devID, "DAP")
            self.cores.append(MemoryRouter(
                [ DapMemoryAccessor("AHB", self.DAP, 0, "AHB bus accessed via AP_0 on DAP_0") ],
                self.cortexM3))
            self.setManagedDevices([self.DAP])
