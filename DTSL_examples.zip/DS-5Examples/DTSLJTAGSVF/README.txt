DTSL Jython JTAG SVF Example
----------------------------

This is an example of how one can use DSTREAM to process Serial Vector Format 
(SVF) files and SVF statements.

This uses DTSL to create a DSTREAM JTAG connection which is then used to
interact with the JTAG SVF server on DSTREAM.

NOTE: that this example is a complete stand-alone application. It can not be run
at the same time as a DS-5 Debugger connection has been made to the same target.

Running the example
-------------------

The example is run by starting the Windows jtagsvf.bat file or the Linux
jtagsvf bash script). 

Before you run it make sure you have edited the ../DTSL/dtslsetup.bat batch
file or the ../DTSL/dtslsetup bash script to setup the correct environment.
Also, you must edit the jtagsvf.bat file (or jtagsvf script) and change 
the program parameters to suite the target system you are connecting to.

"c:\jython2.5.3"\jython src\svf.py -h
Usage: svf [options] (use --help to see full option list)

DSTREAM SVF File processor

Options:
  --version             show program's version number and exit
  -h, --help            show this help message and exit
  -n CONNECTIONADDRESS, --connectionAddress=CONNECTIONADDRESS
                        the device to connect to e.g. TCP:MyDSTREAM or USB

e.g: an example run:
"c:\jython2.5.3"\jython src\svf.py --connectionAddress "USB"
Connecting to DSTREAM JTAG
SVF FIle list:
dbgreq.svf;dbgreqhi.svf;dbgreqlo.svf;
SVF FIle list:
dbgreq.svf;test.svf;dbgreqhi.svf;dbgreqlo.svf;
SVF FIle list:
dbgreq.svf;dbgreqhi.svf;dbgreqlo.svf;
Disconnecting from DSTREAM JTAG
