"""
Module to process command line options
"""
from optparse import OptionParser


class ProgramOptions(object):
    """
    Parses command line options and provides configuration data to the
    main program
    """
    def __init__(self, programName, version):
        """
        Constructor
        """
        self.programName = programName
        self.version = version
        self.connectionAddress = None

    def checkOptions(self):
        rCode = True
        return rCode

    def processOptions(self):
        """ Processes command line option """
        # Construct option specifications
        parser = OptionParser(
            usage=("usage: %s [options] (use --help to see full "
                   "option list)") % self.programName,
            version="%s %s" % (self.programName, self.version),
            description="DSTREAM SVF File processor")
        parser.add_option(
            "-n", "--connectionAddress", action="store", type="string",
            dest="connectionAddress", default="USB",
            help="the device to connect to e.g. TCP:MyDSTREAM or USB")
        # Process all supplied options
        options = parser.parse_args()[0]
        # Extract any supplied options into our local values
        if options.connectionAddress is not None:
            self.connectionAddress = options.connectionAddress
        return self.checkOptions()

    def getConnectionAddress(self):
        return self.connectionAddress
