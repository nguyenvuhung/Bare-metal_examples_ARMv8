#! /usr/bin/env python


from com.arm.debug.dtsl import DTSLException
from com.arm.rddi import RDDIException
from com.arm.rddi import IJTAG
import sys
from org.python.core import PyException
from jtag import JTAG
from dtslhelper import showDTSLException
from dtslhelper import showJythonException
from dtslhelper import createDSTREAMDTSL
from options import ProgramOptions
import os
from java.lang import StringBuilder


VERSION = "1.0"


class ProgramException(Exception):

    def __init__(self, description, cause=None):
        self.description = description
        self.cause = cause

    def getCause(self):
        return self.cause

    def __str__(self):
        msg = "ProgramException: %s" % (self.description)
        if self.cause is not None:
            msg = msg + "\nCaused by:\n%s" % (self.cause.__str__())
        return msg

    def getMessage(self):
        return "ProgramException: %s" % (self.description)


def showRDDIException(e):
    """ Prints out a RDDIException
    The exception chain is traversed and non-duplicated
    information from all levels is displayed
    Parameters:
        e - the RDDIException object
    """
    print >> sys.stderr, "Caught RDDI exception:"
    cause = e
    lastMessage = ""
    while cause is not None:
        nextMessage = cause.getMessage()
        if nextMessage != lastMessage:
            if nextMessage is not None:
                print >> sys.stderr, nextMessage
            lastMessage = nextMessage
        cause = cause.getCause()


def showProgramException(e):
    """ Prints out a ProgramException
    The exception chain is traversed and non-duplicated
    information from all levels is displayed
    Parameters:
        e - the ProgramException object
    """
    print >> sys.stderr, "Caught program exception:"
    cause = e
    lastMessage = ""
    while cause is not None:
        nextMessage = cause.getMessage()
        if nextMessage != lastMessage:
            if nextMessage is not None:
                print >> sys.stderr, nextMessage
            lastMessage = nextMessage
        cause = cause.getCause()


def detectDS5():
    """Detects if we have been launched from within DS-5
    Returns:
        True if launched from DS-5
        False if not i.e. run outside of a DS-5 debug session
    """
    fromDS5 = False
    try:
        from arm_ds.debugger_v1 import Debugger
        fromDS5 = True
    except ImportError:
        fromDS5 = False
        setupLogging()
    return fromDS5


def pioSVFTests(jtag):
    rddiJTAG = jtag.rddiJTAG()
    assert isinstance(rddiJTAG, IJTAG)
    rddiJTAG.setJTAGClock(10000000)
    timeout = 100
    # Reset the DSTREAM SVF processing module
    rddiJTAG.SVFReset()
    # Test out the new SVF pin definitions (from DSTREAM F/W 4.20 build 2)
    # The recognised set is now:
    # "DBGREQ", "COAX", "OUTPUT1", "OUTPUT2", "OUTPUT3", "OUTPUT4", "OUTPUT5",
    # "OUTPUT6", "nTRST", "nSRST", "TMS"
    rddiJTAG.SVFProcessStatement(
        "PIOMAP", "(OUT nTRST OUT nSRST OUT TMS)", timeout)
    rddiJTAG.SVFProcessStatement("PIO", "(HHH)", timeout)
    rddiJTAG.SVFProcessStatement("PIO", "(LHX)", timeout)
    rddiJTAG.SVFProcessStatement("PIO", "(HLX)", timeout)
    rddiJTAG.SVFProcessStatement("PIO", "(LXX)", timeout)
    rddiJTAG.SVFProcessStatement("PIO", "(HHX)", timeout)
    rddiJTAG.SVFProcessStatement("PIO", "(HXL)", timeout)
    rddiJTAG.SVFProcessStatement("PIO", "(LXX)", timeout)
    rddiJTAG.SVFProcessStatement("PIO", "(HLX)", timeout)
    rddiJTAG.SVFProcessStatement("PIO", "(LXX)", timeout)
    rddiJTAG.SVFProcessStatement("PIO", "(HHX)", timeout)
    # The SVF code now also accepts the numbered pin format. The PIOMAP
    # given below is the equivalent to the one above
    rddiJTAG.SVFProcessStatement(
        "PIOMAP", "(1 nTRST 2 nSRST 3 TMS)", timeout)
    rddiJTAG.SVFProcessStatement("PIO", "(HHH)", timeout)
    rddiJTAG.SVFProcessStatement("PIO", "(LHX)", timeout)
    rddiJTAG.SVFProcessStatement("PIO", "(HLX)", timeout)
    rddiJTAG.SVFProcessStatement("PIO", "(LXX)", timeout)
    rddiJTAG.SVFProcessStatement("PIO", "(HHX)", timeout)
    rddiJTAG.SVFProcessStatement("PIO", "(HXL)", timeout)
    rddiJTAG.SVFProcessStatement("PIO", "(LXX)", timeout)
    rddiJTAG.SVFProcessStatement("PIO", "(HLX)", timeout)
    rddiJTAG.SVFProcessStatement("PIO", "(LXX)", timeout)
    rddiJTAG.SVFProcessStatement("PIO", "(HHX)", timeout)
    # The SVF code also now accepts repeated definitions which can be used
    # to cause high speed transitions on the same pin without having to send
    # down multiple PIO commands
    rddiJTAG.SVFProcessStatement(
        "PIOMAP", "(OUT nTRST OUT nTRST OUT nTRST)", timeout)
    rddiJTAG.SVFProcessStatement("PIO", "(HHH)", timeout)
    rddiJTAG.SVFProcessStatement("PIO", "(HLH)", timeout)
    # ... and in numbered format (note the missing position 4! This is now
    # allowed and generates a DSTREAM log warning message only - no error)
    rddiJTAG.SVFProcessStatement(
        "PIOMAP", "(1 nTRST 2 nTRST 3 nTRST 5 nTRST 6 nTRST)", timeout)
    rddiJTAG.SVFProcessStatement("PIO", "(HHHXHH)", timeout)
    rddiJTAG.SVFProcessStatement("PIO", "(HLHXLH)", timeout)


def verifyTests(jtag):
    rddiJTAG = jtag.rddiJTAG()
    assert isinstance(rddiJTAG, IJTAG)
    timeout = 100
    #
    # First test the verify function using a PIO definition
    #
    # Reset the DSTREAM SVF processing module
    rddiJTAG.SVFReset()
    # Send out lots of 1s to IR to place all in BYPASS
    rddiJTAG.SVFProcessStatement(
        "SIR", "64 TDI (FFFFFFFFFFFFFFFF)", timeout)
    rddiJTAG.SVFProcessStatement(
        "PIOMAP", "(OUT VERIFY)", timeout)
    try:
        # Turn verify ON
        rddiJTAG.SVFProcessStatement("PIO", "(H)", timeout)
        # This should cause an exception
        rddiJTAG.SVFProcessStatement(
            "SDR", "32 TDI (12345678) TDO (87654321) MASK (FFFFFFFF)", timeout)
        print "VERIFY flag failed to turn on verify"
    except RDDIException:
        pass
    try:
        # Turn verify OFF
        rddiJTAG.SVFProcessStatement("PIO", "(L)", timeout)
        # This should not cause an exception
        rddiJTAG.SVFProcessStatement(
            "SDR", "32 TDI (12345678) TDO (87654321) MASK (FFFFFFFF)", timeout)
    except RDDIException:
        print "VERIFY flag failed to turn off verify"
    rddiJTAG.SVFProcessStatement("PIO", "(X)", timeout)
    rddiJTAG.SVFProcessStatement("PIO", "(H)", timeout)
    #
    # Test the verify function using the FLAGS statement
    #
    # Reset the DSTREAM SVF processing module
    rddiJTAG.SVFReset()
    # Send out lots of 1s to IR to place all in BYPASS
    rddiJTAG.SVFProcessStatement(
        "SIR", "64 TDI (FFFFFFFFFFFFFFFF)", timeout)
    try:
        # Turn ignore verify failure ON
        rddiJTAG.SVFProcessStatement("FLAGS", "0x00000003", timeout)
        # This should not cause an exception
        rddiJTAG.SVFProcessStatement(
            "SDR", "32 TDI (12345678) TDO (87654321) MASK (FFFFFFFF)", timeout)
    except RDDIException:
        print "VERIFY flag failed to turn off verify"
    try:
        # Turn ignore verify failure OFF
        rddiJTAG.SVFProcessStatement("FLAGS", "0x00000001", timeout)
        # This not cause an exception
        rddiJTAG.SVFProcessStatement(
            "SDR", "32 TDI (12345678) TDO (87654321) MASK (FFFFFFFF)", timeout)
        print "VERIFY flag failed to turn off verify"
    except RDDIException:
        pass


def showSVFFiles(jtag):
    fileList = StringBuilder(1024)
    rddiJTAG = jtag.rddiJTAG()
    rddiJTAG.SVFGetFileList(fileList)
    print "SVF FIle list:"
    print "%s" % fileList.toString()


def fileSVFTests(jtag):
    '''Shows how to get an SVF file processed by DSTREAM
    The model DSTREAM uses is to download the file to DSTREAM (into a special
    SVF file storage area) and then ask DSTREAM to run the file.
    '''
    rddiJTAG = jtag.rddiJTAG()
    # Show which files (if any) are already on DSTREAM
    showSVFFiles(jtag)
    # Now download the test.svf file (in same path is this source file)
    # to DSTREAM
    myPath = os.path.abspath(sys.argv[0])
    scfFilename = 'test.svf'
    svfFile = os.path.join(os.path.dirname(myPath), scfFilename)
    rddiJTAG.SVFDownloadFile(svfFile, scfFilename)
    # The list of files should now contain the new file
    showSVFFiles(jtag)
    try:
        # Ask DSTREAM to run the file (just 1 time with a timeout of 1000ms)
        # Turn JTAG logging on
        # rddiJTAG.SVFProcessStatement("LOG", "ON", 100)
        # Request verify failures to be ignored
        rddiJTAG.SVFProcessStatement("FLAGS", "0x00000003", 100)
        rddiJTAG.SVFRunFile(scfFilename, 1, 1000)
        # Turn JTAG logging off
        # rddiJTAG.SVFProcessStatement("LOG", "OFF", 100)
        # Turn verify failures back on
        rddiJTAG.SVFProcessStatement("FLAGS", "0x00000001", 100)
        try:
            # this time the test file should generate an exception because the
            # final scan will fail its verify test
            rddiJTAG.SVFRunFile(scfFilename, 1, 1000)
        except RDDIException:
            pass
    finally:
        # No matter what happens we then delete the downloaded file from
        # DSTREAMS file store area
        rddiJTAG.SVFDeleteFile(scfFilename)
    # Show which files (if any) are still on DSTREAM
    showSVFFiles(jtag)


def setupLogging():
    from com.arm.debug.logging import LogFactory
    LogFactory.changeLogLevel("ERROR")  # use DEBUG for lots of logging


if __name__ == "__main__":
    # pydevd.settrace(stdoutToServer=True, stderrToServer=True)
    try:
        fromDS5 = detectDS5()
        if fromDS5:
            raise ProgramException(
                "This script can only be run from outside DS-5 Debugger")
        setupLogging()
        options = ProgramOptions("svf", VERSION)
        if not options.processOptions():
            raise ProgramException(
                "Failed to process options")
        myPath = os.path.abspath(sys.argv[0])
        rvcFile = os.path.join(os.path.dirname(myPath), 'dummy.rvc')
        dtslConnection = createDSTREAMDTSL(
            options.getConnectionAddress(), rvcFile)
        jtag = JTAG(dtslConnection.getConfiguration().getJTAG(),
                    options.getConnectionAddress())
        print "Connecting to DSTREAM JTAG"
        jtag.connect()
        try:
            pioSVFTests(jtag)
            verifyTests(jtag)
            fileSVFTests(jtag)
        finally:
            print "Disconnecting from DSTREAM JTAG"
            jtag.disconnect()
    except RDDIException, eRDDI:
        showRDDIException(eRDDI)
    except DTSLException, eDTSL:
        showDTSLException(eDTSL)
    except ProgramException, eProgram:
        showProgramException(eProgram)
    except PyException, e:
        showJythonException(e)
    except RuntimeError, e:
        print >> sys.stderr, e
