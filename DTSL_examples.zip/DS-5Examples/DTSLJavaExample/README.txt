DTSL Java Example
-----------------

This is an example of how one can use DTSL in 'stand-alone' mode (i.e. outside 
of the Eclipse environment). DTSL is mainly written in Java and so can be used
by either a Java program, as in this example, or by a Jython (Python for Java)
program.

DTSL provides a bridge layer between an application and a target system. DTSL 
provides a sets of objects which represent either 

   * target components (cores or CoreSight components)
   * trace capture/control devices
   * trace sources or trace decoder objects

These objects are created by a platform specific DTSL Jython configuration 
script which is typically contained within the DS-5 configuration database.
Once this script has been run, the objects created are available for use by an
application - typically the DS-5 Debugger, or, as in this case, a Java 
application.

The example Java application will show you how you can:

   * Create a DTSL configuration instance for the requested platform
   * Connect to a core device (typically a Cortex core or other such ARM core)
   * Run through a set of example operations which show you how to:
      - Get control of the core following a reset
      - Single step instructions on the core
      - Start/Stop core execution
      - Read/Write registers on the core
      - Read/Write memory via the core

Whilst the example only connects to and controls the ARM core, it can just as
easily connect to any of the CoreSight components, such as a PTM or ETB and 
configure and control those devices as well.

NOTE: that this example is a complete stand-alone application. It can not be run
at the same time as a DS-5 Debugger connection has been made to the same target.
It is possible for a DS-5 Debugger Jython script to access the DTSL configuration, 
though doing so may well interfere with the debugger unless care is taken!

Running the example
-------------------

This example can be run from within DS-5 using the Java Application debug configuration 
"DTSLJavaExample_configdb.launch" or "DTSLJavaExample_direct.launch"

Alternatively, the example can be run on the command-line by starting the 
Windows dtslexample.bat file or the Linux dtslexample bash script. 
Before you run it make sure you have edited the ../DTSL/dtslsetup.bat batch
file or the ../DTSL/dtslsetup bash script to setup the correct environment.
Also, you must edit the dtslexample.bat file (or dtslexample script) and change 
the program parameters to suite the target system you are connecting to.

The batch file is set up to connect to a Keil MCBSTM32E board using the DS-5 config
database as installed to the default location under Windows with a configdb
extension in the Eclipse workspace. To make the batch file functional for your
environment you will have to edit it.

You will need to:
   * Change the connection address for the DSTREAM box to match your box
   * Change the location of the DS-5 configuration database roots to point
     to your installed DS-5 configdb and the path to the configdb
     entry within the project in your Eclipse workspace
   * Change the manufacturer to match the folder name of your platform
     contained in the Boards sub directory of the DS-5 config database
   * Change the board name to match the board folder within the manufacturer
     folder specified above
   * Change the debug operation to match against one of the activity names
     contained in a bare metal debug section of the project_types.xml file
     e.g. <activity id="ICE_DEBUG" type="Debug">
             <name language="en">Debug Cortex-A9_0 via DSTREAM/RVI</name>

When run, the script will connect to the target and run through a set of 
register, memory and execution operations. 

To run the memory operations, the script needs to know the address of some
RAM area on the target. Towards the top of the DTSLExample.java program you will
find the following lines:
    private static final int testAddressBase = 0x20000000;
    private static final int testAddressSize = 96 * 1024;
which you should change to be appropriate for your target.
 
The script can actually be run in two different ways:

   1. Use the DS-5 configuration database options - in which case all the 
      information the script needs is harvested from the configuration
      database entries - and so closely matches what DS-5 Debugger would do.
   2. Specify the information directly as command line options             

To demonstrate this, the following two invocations are equivalent:

java -classpath "C:\Users\tony\workspace\DTSL\libs\dtsl-bundle.jar;C:\Users\tony\workspace\DTSL\libs\native;dtslexample.jar" dtslexample.DTSLExample  
    --configdb "C:\Program Files\DS-5 v5.22.0\sw\debugger\configdb;C:\Users\tony\workspace\PythonDTSLExampleconfigdb}"
    --manufacturer Keil-DTSLExample
    --board MCBSTM32E
    --debugOperation "Debug Cortex-M3"
    --connectionType "DSTREAM"
    --connectionAddress "USB"

java -classpath "C:\Users\tony\workspace\DTSL\libs\dtsl-bundle.jar;C:\Users\tony\workspace\DTSL\libs\native;dtslexample.jar" dtslexample.DTSLExample
    --rddiConfigFile "C:\Users\tony\workspace\JavaDTSLExample\configdb\Boards\Keil-DTSLExample\MCBSTM32E\keil-mcbstm32e-DSTREAM.rvc}"
    --dtslScript "C:\Users\tony\workspace\JavaDTSLExample\configdb\Boards\Keil-DTSLExample\MCBSTM32E\keil-mcbstm32e.py}"
    --dtslClass DSTREAMDebugAndTrace
    --connectionAddress "USB"
    --device Cortex-M3
