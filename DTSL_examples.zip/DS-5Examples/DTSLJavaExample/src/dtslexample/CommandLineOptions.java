package dtslexample;

import java.util.Properties;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.GnuParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.OptionBuilder;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;

public class CommandLineOptions {

    public final static String HELP = "help"; //$NON-NLS-1$
    public final static String RDDICONFIGFILE = "rddiConfigFile"; //$NON-NLS-1$
    public final static String DTSLSCRIPT = "dtslScript"; //$NON-NLS-1$
    public final static String DTSLCLASS = "dtslClass";  //$NON-NLS-1$
    public final static String DTSLOPTIONS = "dtslOptions"; //$NON-NLS-1$
    public final static String CONFIGDB = "configdb"; //$NON-NLS-1$
    public final static String MANUFACTURER = "manufacturer"; //$NON-NLS-1$
    public final static String BOARD = "board";  //$NON-NLS-1$
    public final static String DEBUGOPERATION = "debugOperation"; //$NON-NLS-1$
    public final static String CONNECTIONADDRESS = "connectionAddress"; //$NON-NLS-1$
    public final static String CONNECTIONTYPE = "connectionType"; //$NON-NLS-1$
    public final static String DEVICE = "device"; //$NON-NLS-1$
    public final static String RAMSTART = "ramStart"; //$NON-NLS-1$
    public final static String RAMSIZE = "ramSize"; //$NON-NLS-1$

    private Options options;

    private String usage = "java -jar dtslexample.jar <options>";
    private String optHelp = 
        "You would normally use the option set\n"+ 
        "  {--configdb,--manufacturer,--board,--debugOperation,--connectionType,--connectionAddress}\n"+
        "OR\n"+
        "  {--rddiConfigFile,--dtslScript,--dtslClass,--device,--connectionAddress}\n"+
        "but not both. The 1st set uses the information stored in the DS-5 "+ 
        "configuration database. The 2nd set directly specifies the information "+ 
        "required by the program.\n"+ 
        "e.g.#1\n" +
        " dtslexample --rddiConfigDile panda.rvc\n" +
        "             --dtslScript panda.py\n"+
        "             --dtslClass OMAP44xx\n" +
        "             --device Cortex-A9_0\n"+
        "             --connectionAddress USB\n"+
        "e.g.#2\n" +
        " dtslexample --configdb \"c:\\Program Files\\DS-5 v5.22.0\\sw\\debugger\\configdb\"\n"+
        "             --manufacturer pandaboard.org\n" +
        "             --board OMAP_4430\n"+
        "             --debugOperation = \"Debug Cortex-A9_0\"\n"+
        "             --connectionType DSTREAM\n"+
        "             --connectionAddress USB";
    
    @SuppressWarnings("static-access")
    public CommandLineOptions() {
        Option opt_help = OptionBuilder.withArgName( HELP )
                .withDescription(this.optHelp)
                .withLongOpt(HELP)
                .create('h');        
        Option opt_rvcfile = OptionBuilder.withArgName( RDDICONFIGFILE )
                .hasArg()
                .withDescription("specifies the .rvc file")
                .withLongOpt(RDDICONFIGFILE)
                .create('r');        
        Option opt_dtslscript = OptionBuilder.withArgName( DTSLSCRIPT )
                .hasArg()
                .withDescription("specifies the DTSL Jython script")
                .withLongOpt(DTSLSCRIPT)
                .create('s');        
        Option opt_dtslconfig = OptionBuilder.withArgName( DTSLCLASS )
                .hasArg()
                .withDescription("specifies the class name within the script to instantiate")
                .withLongOpt(DTSLCLASS)
                .create('c');        
        Option opt_dtsloptions = OptionBuilder.withArgName( DTSLOPTIONS )
                .hasArg()
                .withDescription("specifies the optional DTSL options file")
                .withLongOpt(DTSLOPTIONS)
                .create('o');        
        Option opt_configdb = OptionBuilder.withArgName( CONFIGDB )
                .hasArg()
                .withDescription("specifies a ';' separated list of DS-5 configuration database locations")
                .withLongOpt(CONFIGDB)
                .create('d');        
        Option opt_manufacturer = OptionBuilder.withLongOpt( MANUFACTURER )
                .hasArg()
                .withDescription( "specifies the platform manufacturer name" )
                .withLongOpt(MANUFACTURER)
                .create('m');
        Option opt_board = OptionBuilder.withLongOpt( BOARD )
                .hasArg()
                .withDescription( "specifies the platform board name" )
                .withLongOpt(BOARD)
                .create('b');
        Option opt_debugoperation = OptionBuilder.withLongOpt( DEBUGOPERATION )
                .hasArg()
                .withDescription( "specifies the platform debug operation" )
                .withLongOpt(DEBUGOPERATION)
                .create('p');
        Option opt_connectionAddress = OptionBuilder.withLongOpt( CONNECTIONADDRESS )
                .hasArg()
                .withDescription( "is either USB: or TCP:<hostname|ip address>" )
                .withLongOpt(CONNECTIONADDRESS)
                .create('e');
        Option opt_connectionType = OptionBuilder.withLongOpt( CONNECTIONTYPE )
                .hasArg()
                .withDescription( "e.g. DSTREAM or ULINKpro or ..." )
                .withLongOpt(CONNECTIONTYPE)
                .create('t');
        Option opt_device = OptionBuilder.withLongOpt( DEVICE )
                .hasArg()
                .withDescription( "specifies the device name to connect to" )
                .withLongOpt(DEVICE)
                .create('n');
        Option opt_ramStart = OptionBuilder.withLongOpt( RAMSTART )
                .hasArg()
                .withDescription( "specifies the start address of a RAM area" )
                .withLongOpt(RAMSTART)
                .create('a');
        Option opt_ramSize = OptionBuilder.withLongOpt( RAMSIZE )
                .hasArg()
                .withDescription( "specifies size in bytes of the RAM area" )
                .withLongOpt(RAMSIZE)
                .create('z');
        this.options = new Options();
        this.options.addOption( opt_help );        
        this.options.addOption( opt_rvcfile );        
        this.options.addOption( opt_dtslscript );        
        this.options.addOption( opt_dtslconfig );        
        this.options.addOption( opt_dtsloptions );        
        this.options.addOption( opt_configdb );        
        this.options.addOption( opt_manufacturer );        
        this.options.addOption( opt_board );        
        this.options.addOption( opt_debugoperation );        
        this.options.addOption( opt_connectionAddress );        
        this.options.addOption( opt_connectionType );        
        this.options.addOption( opt_device );        
        this.options.addOption( opt_ramStart );        
        this.options.addOption( opt_ramSize );        
    }

    public Properties parseOptions(String[] args) {
        Properties optionSet = new Properties();
        // create the parser
        CommandLineParser parser = new GnuParser();
        try {
            // parse the command line arguments
            CommandLine line = parser.parse( options, args );
            if( line.hasOption( HELP ) ) {
                HelpFormatter formatter = new HelpFormatter();
                formatter.printHelp( this.usage, this.options ); //$NON-NLS-1$
                System.exit(1);
            }
            if( line.hasOption( RDDICONFIGFILE ) ) {
                optionSet.setProperty(RDDICONFIGFILE, line.getOptionValue(RDDICONFIGFILE));
            } 
            if( line.hasOption( DTSLSCRIPT ) ) {
                optionSet.setProperty(DTSLSCRIPT, line.getOptionValue(DTSLSCRIPT));
            } 
            if( line.hasOption( DTSLCLASS ) ) {
                optionSet.setProperty(DTSLCLASS, line.getOptionValue(DTSLCLASS));
            }
            if( line.hasOption( DTSLOPTIONS ) ) {
                optionSet.setProperty(DTSLOPTIONS, line.getOptionValue(DTSLOPTIONS));
            } 
            if( line.hasOption( CONFIGDB ) ) {
                optionSet.setProperty(CONFIGDB, line.getOptionValue(CONFIGDB));
            }
            if( line.hasOption( MANUFACTURER ) ) {
                optionSet.setProperty(MANUFACTURER, line.getOptionValue(MANUFACTURER));
            }
            if( line.hasOption( BOARD ) ) {
                optionSet.setProperty(BOARD, line.getOptionValue(BOARD));
            }
            if( line.hasOption( DEBUGOPERATION ) ) {
                optionSet.setProperty(DEBUGOPERATION, line.getOptionValue(DEBUGOPERATION));
            }
            if( line.hasOption( CONNECTIONTYPE ) ) {
                optionSet.setProperty(CONNECTIONTYPE, line.getOptionValue(CONNECTIONTYPE));
            }
            if( line.hasOption( CONNECTIONADDRESS ) ) {
                optionSet.setProperty(CONNECTIONADDRESS, line.getOptionValue(CONNECTIONADDRESS));
            }
            if( line.hasOption( DEVICE ) ) {
                optionSet.setProperty(DEVICE, line.getOptionValue(DEVICE));
            }
            if( line.hasOption( RAMSTART ) ) {
                optionSet.setProperty(RAMSTART, line.getOptionValue(RAMSTART));
            } else {
                optionSet.setProperty(RAMSTART, "0x20000000");
            }
            if( line.hasOption( RAMSIZE ) ) {
                optionSet.setProperty(RAMSIZE, line.getOptionValue(RAMSIZE));
            } else {
                optionSet.setProperty(RAMSIZE, "65536");
            }
        }
        catch( ParseException exp ) {
            System.err.println( "Options parsing failed.  Reason: " + exp.getMessage() );
            System.exit(1);
        }
        return optionSet;
    }
    
    public void usage() {
        HelpFormatter formatter = new HelpFormatter();
        formatter.printHelp( this.usage, this.options ); //$NON-NLS-1$
    }
    
}
