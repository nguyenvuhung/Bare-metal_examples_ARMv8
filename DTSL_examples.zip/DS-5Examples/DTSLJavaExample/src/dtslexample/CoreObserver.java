package dtslexample;

import java.util.Calendar;

import com.arm.debug.dtsl.rddi.IDebugObserver;
import com.arm.rddi.RDDI_EVENT_TYPE;
import com.arm.rddi.RDDI_Event;

public class CoreObserver implements IDebugObserver {

    private RDDI_EVENT_TYPE state;

    public CoreObserver() {
        this.state = RDDI_EVENT_TYPE.RDDI_PROC_STATE_UNKNOWN;
    }
    
    @Override
    public void processEvent(RDDI_Event event) {
        RDDI_EVENT_TYPE eventType = event.getEventType();
        if (eventType == RDDI_EVENT_TYPE.RDDI_PROC_STATE_RUNNING) {
            if (getState() != eventType) {
                setState(eventType);
                System.out.println(String.format(
                    "Got state change RDDI_EVENT_TYPE.RDDI_PROC_STATE_RUNNING for device %d",
                    event.getDeviceNo()));
            }
        } else if (eventType == RDDI_EVENT_TYPE.RDDI_PROC_STATE_STOPPED) {
            if (getState() != eventType) {
                setState(eventType);
                System.out.println(String.format(
                    "Got state change RDDI_EVENT_TYPE.RDDI_PROC_STATE_STOPPED for device %d",
                    event.getDeviceNo()));
            }
        } else if (eventType == RDDI_EVENT_TYPE.RDDI_POWERED_DOWN) {
            if (getState() != eventType) {
                setState(eventType);
                System.out.println(String.format(
                    "Got state change RDDI_EVENT_TYPE.RDDI_POWERED_DOWN for device %d",
                    event.getDeviceNo()));
            }
        } else if (eventType == RDDI_EVENT_TYPE.RDDI_HELD_IN_RESET) {
            if (getState() != eventType) {
                setState(eventType);
                System.out.println(String.format(
                    "Got state change RDDI_EVENT_TYPE.RDDI_HELD_IN_RESET for device %d",
                    event.getDeviceNo()));
            }
        }
    }

    public void clear() {
        setState(RDDI_EVENT_TYPE.RDDI_PROC_STATE_UNKNOWN);
    }
    
    public void setState(RDDI_EVENT_TYPE eventType) {
        synchronized(this) {
            this.state = eventType;
            notify();
        }
    }

    public RDDI_EVENT_TYPE getState() {
        RDDI_EVENT_TYPE state;
        synchronized(this) {
            state = this.state;
        }
        return state;
    }
    
    private void waitForState(RDDI_EVENT_TYPE state, int timeout) {
        if (this.state != state) {
            Calendar calendar = Calendar.getInstance();
            long msDeadline = calendar.getTimeInMillis() + timeout*1000;
            long msTimeLeft = timeout*1000;
            synchronized(this) {
                while (this.state != state) {
                    msTimeLeft = msDeadline - calendar.getTimeInMillis();
                    if (msTimeLeft < 0) {
                        throw new RuntimeException("Timeout waiting to reach " + state.name());
                    }
                    try {
                        wait(msTimeLeft);
                    } catch (InterruptedException e) {
                    }
                }
            }
        }
    }
    
    public void waitForStop(int timeout) {
        waitForState(RDDI_EVENT_TYPE.RDDI_PROC_STATE_STOPPED, timeout);
    }
    
    
    public void waitForStart(int timeout) {
        waitForState(RDDI_EVENT_TYPE.RDDI_PROC_STATE_RUNNING, timeout);
    }
    
}
