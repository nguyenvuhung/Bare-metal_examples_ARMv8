/**
 * Stand alone DTSL Java example program
 * Copyright (C) 2013 ARM Limited. All rights reserved.
 */
package dtslexample;

import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.SortedMap;
import java.util.TreeMap;

import org.python.core.PyException;

import com.arm.debug.logging.LogFactory;
import com.arm.debug.dtsl.ConnectionManager;
import com.arm.debug.dtsl.ConnectionParameters;
import com.arm.debug.dtsl.DTSLException;
import com.arm.debug.dtsl.interfaces.IConfiguration;
import com.arm.debug.dtsl.interfaces.IConnection;
import com.arm.debug.dtsl.interfaces.IDevice;
import com.arm.debug.dtsl.rddi.DeviceRegisterInfo;
import com.arm.rddi.RDDI_ACC_SIZE;
import com.arm.rddi.RDDI_EVENT_TYPE;
import com.arm.rddi.jrddiConstants;
import com.arm.text.FormattedException;

import configdb.ConfigDBResolver;


/**
 * Class which wraps the example program and provides the
 * main() program entry point.
 */
public class DTSLExample {
    // This is the list of registers we display. If the core type
    // changes this may need to change as not all cores have the
    // same register names. Registers with aliases can be specified
    // as name1:name2:name3.... and we will try to locate a register
    // with one of those names.
    private static final String[] coreRegisterList = {
        "R0", "R1", "R2", "R3",
        "R4", "R5", "R6", "R7",
        "R8", "R9", "R10", "R11",
        "R12", "SP:R13", "LR:R14", "PC:R15"
    };
    // This is the name of the PC register - on some cores it
    // is R15
    private static final String pcRegName = "PC:R15";
    // Program return values
    private static final int BAD_OPTIONS = -1;
    private static final int DTSL_CONNECTION_FAILED = -2;
    private static final int DEVICE_NOT_FOUND = -3;
    private static final int FAILED_TO_CONNECT_TO_DEVICE = -4;    
    private static final int FAILED_TO_CONTROL_DEVICE = -5;
    // Constants
    private static final int CORE_STOP_TIMEOUT = 1;
    /**
     * A set of program options expressed as a property list
     */
    private Properties options;
    /**
     * Used to map a register name to its register ID
     */
    private SortedMap<String, Integer> registerIDMap;
    /**
     * Holds the core register names in the same order as in coreRegisterIDs[]
     */
    private String[] coreRegisterNames;
    /**
     * Holds the core register IDs in the same order as in coreRegisterNames[]
     */
    private int[] coreRegisterIDs;
    /**
     * Holds the ID for the PC register (pcRegName)
     */
    private int pcRegID;
    /**
     * The object we use to monitor the state of the core
     */
    private CoreObserver coreObserver;
    
    /**
     * Main program entry point
     * @param args program arguments
     */
    public static void main(String[] args) {
        try {
            LogFactory.changeLogLevel("ERROR");  // use DEBUG for lots of logging
        } catch (FormattedException e) {
        }
        // Create main program and run it
        DTSLExample program = new DTSLExample();
        program.mainProgram(args);
    }

    /**
     * Constructor
     */
    public DTSLExample() {
        this.registerIDMap = new TreeMap<String, Integer>();
        this.coreRegisterIDs = new int[DTSLExample.coreRegisterList.length];
        this.coreRegisterNames = new String[DTSLExample.coreRegisterList.length];
        this.coreObserver = new CoreObserver();
    }
    
    /**
     * Displays a DTSLException. Will display messages from all levels
     * in the exception hierarchy.
     * @param e the DTSLException
     */
    private void showDTSLException(DTSLException e) {
        System.err.println("Caught DTSL Exception:");
        Throwable cause = e;
        String lastMessage = "";
        while (cause != null) {
            String nextMessage = cause.getMessage();
            if (!nextMessage.equals(lastMessage)) {
                if (nextMessage != null) {
                    System.err.println(nextMessage);
                }
                lastMessage = nextMessage;
            }
            cause = cause.getCause();
        }
    }
    
    /**
     * Displays a Jython exception - typically one which has occurred
     * during the running of a Jython script
     * @param e
     */
    private void showJythonException(PyException e) {
        System.err.println("Caught Jython Exception:");
        System.err.println(e.toString());
    }

    /**
     * Converts the program options into our instance {@link #options}
     * property set. Note that if a DS-5 configdb entry is specified, this
     * will override any CommandLineOptions.RDDICONFIGFILE, CommandLineOptions.DTSLSCRIPT, 
     * CommandLineOptions.DTSLCLASS, CommandLineOptions.DEVICE specified on the
     * command line.
     * @param args array of program args
     */
    private void processOptions(String[] args) {
        // Process command line arguments
        CommandLineOptions options = new CommandLineOptions();
        this.options = options.parseOptions(args);
        // If using configdb ...
        if (this.options.getProperty(CommandLineOptions.CONFIGDB) != null) {
            // Check we have other required options
            if (this.options.getProperty(CommandLineOptions.MANUFACTURER) == null ||
                this.options.getProperty(CommandLineOptions.BOARD) == null        ||
                   this.options.getProperty(CommandLineOptions.DEBUGOPERATION) == null) {
                options.usage();
                System.err.println(String.format(
                    "When using the %s option you must also specify the %s, %s and %s options",
                    CommandLineOptions.CONFIGDB, CommandLineOptions.MANUFACTURER,
                    CommandLineOptions.BOARD, CommandLineOptions.DEBUGOPERATION));
                System.exit(DTSLExample.BAD_OPTIONS);
            }
            // ... populate options from configdb data
            System.out.print("Getting connection parameters from configdb ... ");
            long startTime = System.nanoTime();
            ConfigDBResolver cdbr = new ConfigDBResolver();
            Properties cdbParams = cdbr.getConfigDBParameters(
                    this.options.getProperty(CommandLineOptions.CONFIGDB),
                    this.options.getProperty(CommandLineOptions.MANUFACTURER),
                    this.options.getProperty(CommandLineOptions.BOARD),
                    this.options.getProperty(CommandLineOptions.DEBUGOPERATION),
                    this.options.getProperty(CommandLineOptions.CONNECTIONTYPE));
            this.options.setProperty(CommandLineOptions.RDDICONFIGFILE, cdbParams.getProperty("rddiConfigFile"));
            this.options.setProperty(CommandLineOptions.DTSLSCRIPT, cdbParams.getProperty("dtslScript"));
            this.options.setProperty(CommandLineOptions.DTSLCLASS, cdbParams.getProperty("dtslClass"));
            this.options.setProperty(CommandLineOptions.DEVICE,cdbParams.getProperty("device"));
            long timeDelta = System.nanoTime() - startTime;
            if (timeDelta > 0) {
                double time = (double)timeDelta*1.0E-9;
                System.out.println(String.format("done, configdb lookup took %.2fs", time));
            } else {
                System.out.println("done");
            }
        } else {
            if (this.options.getProperty(CommandLineOptions.RDDICONFIGFILE) == null ||
                  this.options.getProperty(CommandLineOptions.DEVICE) == null) {
                options.usage();
                System.err.println(String.format(
                    "When not using the %s option you must specify the %s and %s options",
                    CommandLineOptions.CONFIGDB, CommandLineOptions.RDDICONFIGFILE,
                    CommandLineOptions.DEVICE));
                System.exit(DTSLExample.BAD_OPTIONS);
            }
        }
        try {
            Long.decode(this.options.getProperty(CommandLineOptions.RAMSTART));
        } catch ( NumberFormatException e) {
            System.err.println(String.format("%s option has bad vlue %s", 
                    CommandLineOptions.RAMSTART, 
                    this.options.getProperty(CommandLineOptions.RAMSTART)));
            System.exit(DTSLExample.BAD_OPTIONS);
        }
        try {
            Long.decode(this.options.getProperty(CommandLineOptions.RAMSIZE));
        } catch ( NumberFormatException e) {
            System.err.println(String.format("%s option has bad vlue %s", 
                    CommandLineOptions.RAMSIZE, 
                    this.options.getProperty(CommandLineOptions.RAMSIZE)));
            System.exit(DTSLExample.BAD_OPTIONS);
        }
    }

    /**
     * Displays the connection options we are going to use 
     */
    private void showOptions() {
        System.out.println("Options:");
        if (this.options.getProperty(CommandLineOptions.CONFIGDB) != null) {
            System.out.print("   configdb         : "); System.out.println(this.options.getProperty(CommandLineOptions.CONFIGDB));    
            System.out.print("   Manufacturer     : "); System.out.println(this.options.getProperty(CommandLineOptions.MANUFACTURER));
            System.out.print("   Board            : "); System.out.println(this.options.getProperty(CommandLineOptions.BOARD));
            System.out.print("   Debug Operation  : "); System.out.println(this.options.getProperty(CommandLineOptions.DEBUGOPERATION));
        }
        System.out.print("   DTSL script      : "); System.out.println(this.options.getProperty(CommandLineOptions.DTSLSCRIPT));
        System.out.print("   DTSL class       : "); System.out.println(this.options.getProperty(CommandLineOptions.DTSLCLASS));
        String dtslOptions = this.options.getProperty(CommandLineOptions.DTSLOPTIONS);
        if (dtslOptions != null) {
            System.out.print("   DTSL options     : "); System.out.println(dtslOptions);
        }
        System.out.print("   RDDI Config File : "); System.out.println(this.options.getProperty(CommandLineOptions.RDDICONFIGFILE));    
           System.out.print("   Core name        : "); System.out.println(this.options.getProperty(CommandLineOptions.DEVICE));
           String connectionAddress = this.options.getProperty(CommandLineOptions.CONNECTIONADDRESS);
           if (connectionAddress != null) {
               System.out.print("   Connection Addr  : "); System.out.println(connectionAddress);
           }
           String connectionType = this.options.getProperty(CommandLineOptions.CONNECTIONTYPE);
           if (connectionType != null) {
               System.out.print("   Connection Type  : "); System.out.println(connectionType);
           }
        System.out.print("   RAM Address      : "); System.out.println(this.options.getProperty(CommandLineOptions.RAMSTART));
        System.out.print("   RAM Size         : "); System.out.println(this.options.getProperty(CommandLineOptions.RAMSIZE));
    }
    
    /**
     * Makes our connection to DTSL and returns the connection object
     * @return a DTSL connection object which implements IConnection
     * @throws DTSLException if a connection object cannot be created
     *         from the provided connection parameters in this.options 
     */
    private IConnection connectToDTSL() throws DTSLException {
        ConnectionParameters params = new ConnectionParameters();
        params.rddiConfigFile = this.options.getProperty(CommandLineOptions.RDDICONFIGFILE);
        String address = this.options.getProperty(CommandLineOptions.CONNECTIONADDRESS); 
        if (address != null)
            params.address = address;
        params.configScript = this.options.getProperty(CommandLineOptions.DTSLSCRIPT);
        params.configName = this.options.getProperty(CommandLineOptions.DTSLCLASS);
        String dtslOptions = this.options.getProperty(CommandLineOptions.DTSLOPTIONS);
        if (dtslOptions != null) {
            params.optionsFile = dtslOptions;
        }
        System.out.print("Connecting to DTSL ... ");
        long startTime = System.nanoTime();
        IConnection conn = ConnectionManager.openConnection(params);
        conn.connect();
        long timeDelta = System.nanoTime() - startTime;
        if (timeDelta > 0) {
            double time = (double)timeDelta*1.0E-9;
            System.out.println(String.format("done, connection took %.2fs", time));
        } else {
            System.out.println("done");
        }
        return conn;
    }

    /**
     * Prints a list of device names contained in the DTSL configuration
     * @param dtslConfiguration - the DTSL configuration object
     */
    private void showDTSLDevices(
        IConfiguration dtslConfiguration
    ) {
        System.out.println("DTSL Device list:");
        Collection<IDevice> deviceList = dtslConfiguration.getDevices();
        for (IDevice device : deviceList) {
            System.out.println("   " + device.getID() + ": " + device.getName());
        }
    }
    
    /**
     * Returns a device object referenced by name
     * @param dtslConfiguration - the DTSL configuration object
     * @param deviceName - the device name e.e. "Cortex-A9_0"
     * @return the IDevice object or null if not found
     * NOTE: the device object we return implements the IDevice interface
     */
    private IDevice getDTSLDeviceByName(
        IConfiguration dtslConfiguration, 
        String deviceName
    ) {
        // Search the device list first
        Collection<IDevice> deviceList = dtslConfiguration.getDevices();
        for (IDevice device : deviceList) {
            if (device.getName().equals(deviceName))
                return device;
        }
        // If not found, search the device interface list
        // (SMP type devices dont get added to the normal
        // device list)
        Map<String, IDevice> ifList = dtslConfiguration.getDeviceInterfaces();
        IDevice device = ifList.get(deviceName);
        return device;
    }
    
    /**
     * Makes a connection to a core (or other device)
     * @param device the DTSL device to connect to
     * @throws DTSLException if device connection fails
     */
    private void connectToDevice(
        IDevice device
    ) throws DTSLException {
        StringBuilder deviceInfo = new StringBuilder(256);
        System.out.print("Connecting to device ... ");
        long startTime = System.nanoTime();
        device.openConn(null, null, deviceInfo);
        long timeDelta = System.nanoTime() - startTime;
        if (timeDelta > 0) {
            double time = (double)timeDelta*1.0E-9;
            System.out.println(String.format("done, connection took %.2fs", time));
        } else {
            System.out.println("done");
        }
        StringBuilder deviceName = new StringBuilder(256);
        StringBuilder deviceDetails = new StringBuilder(256);
        device.getDeviceDetails(deviceName, deviceDetails);
        System.out.println("Connected to " + deviceName.toString());
        System.out.println("   device info    : " + deviceInfo.toString());
           System.out.println("   device details : " + deviceDetails.toString());
           generateDeviceRegisterNameMap(device);
           generateCoreRegisters(device);
        device.addDebugEventObserver(this.coreObserver);
    }

    /**
     * Creates the this.registerIDMap map. This holds info on all
     * supported registers and allows us to map a register name into
     * the register ID
     * @param device the DTSL device to build the register map for
     * @throws DTSLException if we fail to get the register info from the device
     */
    private void generateDeviceRegisterNameMap(
        IDevice device
    ) throws DTSLException {
        // Read info on all device registers
        DeviceRegisterInfo regInfo = DeviceRegisterInfo.getRegisterInfo(device);
        // Add all to the registerIDMap[]
        for (String regName : regInfo.keySet()) {
            this.registerIDMap.put(regName, regInfo.get(regName).getId());
        }
    }
        
    /**
     * Creates the this.coreRegisterXXXX arrays. These hold the
     * names and the IDs of the core registers in the order defined 
     * by DTSLExample.coreRegisterList
     * @param device the DTSL device to build the register arrays for
     */
    private void generateCoreRegisters(
        IDevice core
    ) {
        int rIdx = 0;
        for (String reg : DTSLExample.coreRegisterList) {
            String[] regNames = reg.split(":");
            for (String regName : regNames) {
                if (this.registerIDMap.containsKey(regName)) {
                    this.coreRegisterNames[rIdx] = reg;
                    this.coreRegisterIDs[rIdx] = this.registerIDMap.get(regName);
                    ++rIdx;
                    break;
                }
            }
        }
        String[] regNames = pcRegName.split(":");
        for (String regName : regNames) {
            if (this.registerIDMap.containsKey(regName)) {
                this.pcRegID = this.registerIDMap.get(regName);
                break;
            }
        }
    }
    
    /**
     * Returns True if reset vector catch is supported. Note that the 
     * list of supported processor breaks is very target dependent, so
     * may not be supported by the debug controller. 
     * @param core the DTSL device which represents a CPU core
     * @return true if reset vector catch is supported, false if not 
     */
    private boolean isResetVectorCatchSupported(
        IDevice core
    ) throws DTSLException {
        String procBreaks[] = core.listProcBreaks();
        for (String pBreak :procBreaks) {
            if (pBreak.contains("RSET"))
                return true;
        }
        return false;
    }

    /** 
     * stops the core. If we dont manage to stop the core we throw a RuntimeError 
     * @param core the DTSL device which represents a CPU core 
     */
    private void stopCore(
        IDevice core
    ) throws DTSLException {
        core.stop();
        this.coreObserver.waitForStop(CORE_STOP_TIMEOUT);
    }

    /**
     * starts the core. If we dont manage to start the core we throw 
     * a RuntimeError. 
     * @param core the DTSL device which represents a CPU core 
     */
    private void startCore(
        IDevice core
    ) throws DTSLException {
        // NOTE: This is not obvious, but if _we_ start the core, we dont get
        //       any async event notification that our core is running.
        //       Se we must manually set our state
        this.coreObserver.setState(RDDI_EVENT_TYPE.RDDI_PROC_STATE_RUNNING);
        try {
            core.go();
        } catch (DTSLException e) {
            // go() failed, so assume we did not start executing. An alternate
            // here would be to set the state to RDDI_EVENT_TYPE.RDDI_PROC_STATE_UNKNOWN
            this.coreObserver.setState(RDDI_EVENT_TYPE.RDDI_PROC_STATE_STOPPED);
            throw e;
        }
    }
    
    /**
     *  Sets or clears reset vector catch
     *  @param core the DTSL device which represents a CPU core
     *  @param state True to turn on, False to turn off
     */
    private void setResetVectorCatch(
        IDevice core, 
        boolean state
    ) throws DTSLException {
        if (state)
            core.setProcBreak("RSET");
        else
            core.clearProcBreak("RSET");
    }

    /** 
     * Resets the core and optionally halt ASAP
     * @param core the DTSL device which represents a CPU core
     * @param postResetStateHalted - true to halt the core ASAP following the reset
     */
    private void resetCore(
        IDevice core, 
        boolean postResetStateHalted
    ) throws DTSLException {
        if (postResetStateHalted) {
            if (isResetVectorCatchSupported(core)) {
                setResetVectorCatch(core, true);
            }
            // For DSTREAM units there is a configuration item to make it try
            // hard to stop execution ASAP after a reset (should vector catch
            // not work for some reason). We try to set it here, but ignore any
            // failure should we not be connected via DSTREAM.
            try {
                core.setConfig("POST_RESET_STATE", "1");
            } catch (DTSLException e) {} // $codepro.audit.disable emptyCatchClause
        } else {
            if (isResetVectorCatchSupported(core)) {
                setResetVectorCatch(core, false);
            }
            try {
                core.setConfig("POST_RESET_STATE", "0");
            } catch (DTSLException e) {}
        }
        core.systemReset(jrddiConstants.RDDI_RST_PERFORM);
    }
    
    /**
     *  Resets and halts the core
     *  @param core the DTSL device which represents a CPU core
     */
    private void resetAndHaltCore(
        IDevice core
    ) throws DTSLException {
        resetCore(core, true);
        try {
            this.coreObserver.waitForStop(CORE_STOP_TIMEOUT);
        } catch (RuntimeException e) {
            try {
                stopCore(core);
            } catch (RuntimeException f) {
                System.err.println("Unable to halt the core");
                throw f;
            }
        }
        System.out.println(String.format(
            "Core reset and Stopped OK with PC=%s", getPCString(core)));
    }
    
    /**
     *  Reads the PC register for the core
     *  @param core the DTSL device which represents a CPU core
     */
    private int getPC(
        IDevice core
    ) throws DTSLException {
        int values[] = new int[1];
        int regList[] = {this.pcRegID};
        core.regReadList(regList, values);
        return values[0];
    }

    /**
     *  Prints out the PC register for the core
     *  @param core the DTSL device which represents a CPU core
     */
    private String getPCString(
        IDevice core
    ) throws DTSLException {
        return String.format("0x%08X", getPC(core));
    }

    /**
     *  Prints out the core register set as defined by the
     *  this.coreRegisterIDs array
     *  @param core the DTSL device which represents a CPU core
     */
    private void showCoreRegisters(
        IDevice core
    ) throws DTSLException {
        System.out.println("Core register set:");
        int values[] = new int[this.coreRegisterIDs.length];
        core.regReadList(this.coreRegisterIDs, values);
        for (int idx=0; idx < this.coreRegisterIDs.length; ++idx) {
            System.out.println(String.format(
                   "%6s = 0x%08X", this.coreRegisterNames[idx], values[idx]));
        }
    }

    /**
     *  Prints out the complete register set
     *  @param core the DTSL device which represents a CPU core
     */
    private void showAllRegisters(
        IDevice core
    ) throws DTSLException {
        System.out.println("Complete register set:");
        int values[] = new int[this.registerIDMap.size()];
        int regIDs[] = new int[this.registerIDMap.size()];
        int regIdx = 0;
        for (int id : this.registerIDMap.values()) {
            regIDs[regIdx++] = id;
        }
        core.regReadList(regIDs, values);
        regIdx = 0;
        for (Map.Entry<String, Integer> entry : this.registerIDMap.entrySet()) {
            System.out.println(String.format(
                   "%10s = 0x%08X", entry.getKey(), values[regIdx]));
            ++regIdx;
        }
    }

    /**
     *  Shows how to modify register values
     *  @param core the DTSL device which represents a CPU core
     */
    private void changeRegisters(
          IDevice core
    ) throws DTSLException {
        // Create a Java array to hold the register value
        int values[] = new int[1];
        // Create a list holding the register IDs we wish to read/write
        int regList[] = new int[1];
        regList[0] = registerIDMap.get("R0");
        // Read and save register values
        core.regReadList(regList, values);
        int r0Val = values[0];
        // Change the values and write them back
        int wVal = 0x12345678;
        values[0] = wVal;
        core.regWriteList(regList, values);
        // Read back the (hopefully) changed values
        core.regReadList(regList, values);
        if (values[0] != 0x12345678) {
            System.out.println(String.format(
                "Failed to modify R0; wrote 0x%08X read 0x%08X", 
                wVal, values[0]));
        }
        // Put back the original values
        values[0] = r0Val;
        core.regWriteList(regList, values);
    }
        
    /**
     *  Runs through an example set of register operations
     *  @param core the DTSL device which represents a CPU core
     */
    private void registerOps(
        IDevice core
    ) throws DTSLException {
        showCoreRegisters(core);
        showAllRegisters(core);
        changeRegisters(core);
    }
    
    /**
     *  Demonstrates memory read operations
     *  @param core the DTSL device which represents a CPU core
     *  @param testParams a dictionary of test parameters shared
     *         between all the memory operation examples
     */
    private void memoryRead(
          IDevice core,
          Map<String,Long> testParams
    ) throws DTSLException {
        long testAddressBase = testParams.get("testAddressBase");
        long testAddressSize = testParams.get("testAddressSize");
        int blockSize = testParams.get("blockSize").intValue();
        long blockCount = testAddressSize / blockSize;
        byte data[] = new byte[blockSize];

        System.out.print("Started timing memory read, please wait ...");
        long startTime = System.nanoTime();
        for (int block = 0; block < blockCount; ++block) {
            core.memRead(0, testAddressBase, RDDI_ACC_SIZE.RDDI_ACC_DEF, 0, blockSize, data);
        }
        long timeDelta = System.nanoTime() - startTime;
        System.out.println(" reading memory complete");
        if (timeDelta > 0) {
            long totalKBytes = (blockSize * blockCount) / 1024;
            double time = (double)timeDelta*1.0E-9;
            double KBperSec = (double)totalKBytes / time;
            System.out.println(String.format("Read %dKB memory in %.2fs, i.e. %.2f KB/s", totalKBytes, time, KBperSec));
        }
    }

    /**
     *  Demonstrates sized memory read/write operations
     *  These are where you can specify the exact access size which
     *  must be used when reading/writing memory. Typical uses for this are
     *  must be used when reading/writing memory. Typical uses for this are
     *  when accessing onchip peripheral registers which _must_ be
     *  read/written using a certain access size.
     *  @param core the DTSL device which represents a CPU core
     *  @param testParams a dictionary of test parameters shared
     *         between all the memory operation examples
     */
    private void sizeMemoryAccess(
          IDevice core,
          Map<String,Long> testParams
    ) throws DTSLException {
        long testAddressBase = testParams.get("testAddressBase");
        // Setup the Java arrays which will hold our sized data
        // NOTE: this code assumes a little-endian memory system
        byte d8[] = {0x01, 0x02, 0x03, 0x04};
        byte data8In[] = d8.clone();
        byte data8Out[] = {0, 0, 0, 0};
        // Show writing 4 bytes and reading back as 32bit, 16bit and 8bit.
        // Note that whatever the access size is, the data is always transfered
        // as a byte array
        core.memWrite(0, testAddressBase, RDDI_ACC_SIZE.RDDI_ACC_BYTE, 0, false, 4, data8In);
        core.memRead(0, testAddressBase, RDDI_ACC_SIZE.RDDI_ACC_WORD, 0, 4, data8Out);
        if (data8Out[0] != d8[0]) 
            System.err.println("Sized memory access failure; 4x8bit vs 1x32[0] bit mismatch");
        if (data8Out[1] != d8[1])
            System.err.println("Sized memory access failure; 4x8bit vs 1x32[1] bit mismatch");
        if (data8Out[2] != d8[2])
            System.err.println("Sized memory access failure; 4x8bit vs 1x32[2] bit mismatch");
        if (data8Out[3] != d8[3])
            System.err.println("Sized memory access failure; 4x8bit vs 1x32[3] bit mismatch");
        core.memRead(0, testAddressBase, RDDI_ACC_SIZE.RDDI_ACC_HALF, 0, 4, data8Out);
        if (data8Out[0] != d8[0])
            System.err.println("Sized memory access failure; 4x8bit vs 2x16[0] bit mismatch");
        if (data8Out[1] != d8[1])
            System.err.println("Sized memory access failure; 4x8bit vs 2x16[1] bit mismatch");
        if (data8Out[2] != d8[2])
            System.err.println("Sized memory access failure; 4x8bit vs 2x16[2] bit mismatch");
        if (data8Out[3] != d8[3])
            System.err.println("Sized memory access failure; 4x8bit vs 2x16[3] bit mismatch");
        core.memRead(0, testAddressBase, RDDI_ACC_SIZE.RDDI_ACC_BYTE, 0, 4, data8Out);
        if (data8Out[0] != d8[0])
            System.err.println("Sized memory access failure; 4x8bit vs 4x8[0] bit mismatch");
        if (data8Out[1] != d8[1])
            System.err.println("Sized memory access failure; 4x8bit vs 4x8[1] bit mismatch");
        if (data8Out[2] != d8[2])
            System.err.println("Sized memory access failure; 4x8bit vs 4x8[2] bit mismatch");
        if (data8Out[3] != d8[3])
            System.err.println("Sized memory access failure; 4x8bit vs 4x8[3] bit mismatch");
        // Show writing 2 half words and reading back as 32bit, 16bit and 8bit.
        // Note that whatever the access size is, the data is always transfered
        // as a byte array
        core.memWrite(0, testAddressBase, RDDI_ACC_SIZE.RDDI_ACC_HALF, 0, false, 4, data8In);
        core.memRead(0, testAddressBase, RDDI_ACC_SIZE.RDDI_ACC_WORD, 0, 4, data8Out);
        if (data8Out[0] != d8[0])
            System.err.println("Sized memory access failure; 2x16bit vs 1x32[0] bit mismatch");
        if (data8Out[1] != d8[1])
            System.err.println("Sized memory access failure; 2x16bit vs 1x32[1] bit mismatch");
        if (data8Out[2] != d8[2])
            System.err.println("Sized memory access failure; 2x16bit vs 1x32[2] bit mismatch");
        if (data8Out[3] != d8[3])
            System.err.println("Sized memory access failure; 2x16bit vs 1x32[3] bit mismatch");
        core.memRead(0, testAddressBase, RDDI_ACC_SIZE.RDDI_ACC_HALF, 0, 4, data8Out);
        if (data8Out[0] != d8[0])
            System.err.println("Sized memory access failure; 2x16bit vs 2x16[0] bit mismatch");
        if (data8Out[1] != d8[1])
            System.err.println("Sized memory access failure; 2x16bit vs 2x16[1] bit mismatch");
        if (data8Out[2] != d8[2])
            System.err.println("Sized memory access failure; 2x16bit vs 2x16[2] bit mismatch");
        if (data8Out[3] != d8[3])
            System.err.println("Sized memory access failure; 2x16bit vs 2x16[3] bit mismatch");
        core.memRead(0, testAddressBase, RDDI_ACC_SIZE.RDDI_ACC_BYTE, 0, 4, data8Out);
        if (data8Out[0] != d8[0])
            System.err.println("Sized memory access failure; 2x16bit vs 4x8[0] bit mismatch");
        if (data8Out[1] != d8[1])
            System.err.println("Sized memory access failure; 2x16bit vs 4x8[1] bit mismatch");
        if (data8Out[2] != d8[2])
            System.err.println("Sized memory access failure; 2x16bit vs 4x8[2] bit mismatch");
        if (data8Out[3] != d8[3])
            System.err.println("Sized memory access failure; 2x16bit vs 4x8[3] bit mismatch");
        // Show writing 1 word and reading back as 32bit, 16bit and 8bit.
        // Note that whatever the access size is, the data is always transfered
        // as a byte array
        core.memWrite(0, testAddressBase, RDDI_ACC_SIZE.RDDI_ACC_WORD, 0, false, 4, data8In);
        core.memRead(0, testAddressBase, RDDI_ACC_SIZE.RDDI_ACC_WORD, 0, 4, data8Out);
        if (data8Out[0] != d8[0])
            System.err.println("Sized memory access failure; 1x32bit vs 1x32[0] bit mismatch");
        if (data8Out[1] != d8[1])
            System.err.println("Sized memory access failure; 1x32bit vs 1x32[1] bit mismatch");
        if (data8Out[2] != d8[2])
            System.err.println("Sized memory access failure; 1x32bit vs 1x32[2] bit mismatch");
        if (data8Out[3] != d8[3])
            System.err.println("Sized memory access failure; 1x32bit vs 1x32[3] bit mismatch");
        core.memRead(0, testAddressBase, RDDI_ACC_SIZE.RDDI_ACC_HALF, 0, 4, data8Out);
        if (data8Out[0] != d8[0])
            System.err.println("Sized memory access failure; 1x32bit vs 2x16[0] bit mismatch");
        if (data8Out[1] != d8[1])
            System.err.println("Sized memory access failure; 1x32bit vs 2x16[1] bit mismatch");
        if (data8Out[2] != d8[2])
            System.err.println("Sized memory access failure; 1x32bit vs 2x16[2] bit mismatch");
        if (data8Out[3] != d8[3])
            System.err.println("Sized memory access failure; 1x32bit vs 2x16[3] bit mismatch");
        core.memRead(0, testAddressBase, RDDI_ACC_SIZE.RDDI_ACC_BYTE, 0, 4, data8Out);
        if (data8Out[0] != d8[0])
            System.err.println("Sized memory access failure; 1x32bit vs 4x8[0] bit mismatch");
        if (data8Out[1] != d8[1])
            System.err.println("Sized memory access failure; 1x32bit vs 4x8[1] bit mismatch");
        if (data8Out[2] != d8[2])
            System.err.println("Sized memory access failure; 1x32bit vs 4x8[2] bit mismatch");
        if (data8Out[3] != d8[3])
            System.err.println("Sized memory access failure; 1x32bit vs 4x8[3] bit mismatch");
    }

    /**
     *  Demonstrates memory write operations
     *  @param core the DTSL device which represents a CPU core
     *  @param testParams a dictionary of test parameters shared
     *         between all the memory operation examples
     */
    private void memoryWrite(
          IDevice core,
          Map<String,Long> testParams
    ) throws DTSLException {
        long testAddressBase = testParams.get("testAddressBase");
        long testAddressSize = testParams.get("testAddressSize");
        int blockSize = testParams.get("blockSize").intValue();
        long blockCount = testAddressSize / blockSize;
        byte data[] = new byte[blockSize];
        Arrays.fill(data, (byte)0);
        System.out.print("Started timing memory write, please wait ...");
        long startTime = System.nanoTime();
        for (int block = 0; block < blockCount; ++block) {
            core.memWrite(0, testAddressBase, RDDI_ACC_SIZE.RDDI_ACC_DEF, 0, false, blockSize, data);
        }
        long timeDelta = System.nanoTime() - startTime;
        System.out.println(" writing memory complete");
        if (timeDelta > 0) {
            long totalKBytes = (blockSize * blockCount) / 1024;
            double time = (double)timeDelta*1.0E-9;
            double KBperSec = (double)totalKBytes / time;
            System.out.println(String.format("Wrote %dKB memory in %.2fs, i.e. %.2f KB/s", totalKBytes, time, KBperSec));
        }
    }

    /**
     *  Demonstrates memory download operation
     *  @param core the DTSL device which represents a CPU core
     *  @param testParams a dictionary of test parameters shared
     *         between all the memory operation examples
     */
    private void memoryDownload(
          IDevice core,
          Map<String,Long> testParams
    ) throws DTSLException {
        long testAddressBase = testParams.get("testAddressBase");
        long testAddressSize = testParams.get("testAddressSize");
        int blockSize = testParams.get("blockSize").intValue();
        long blockCount = testAddressSize / blockSize;
        byte data[] = new byte[blockSize];
        Arrays.fill(data, (byte)0);
        int errorValue[] = {0};
        long errorPage[] = {0};
        long errorAddr[] = {0};
        long errorOffset[] = {0};
        // Memory download is slightly different from memory write in that
        // the first call to memDownload() places the system into down load mode
        // and uses optimized transport techniques to transfer the packets to the
        // target as fast as possible. Note that the memDownload() calls do no
        // error checking. At the end of the download you need to call
        // memDownloadEnd() and this will report any error which occurred
        // during the download.
        System.out.print("Started timing memory download, please wait ...");
        long startTime = System.nanoTime();
        for (int block = 0; block < blockCount; ++block) {
            core.memDownload(0, testAddressBase, RDDI_ACC_SIZE.RDDI_ACC_DEF, 0, false, blockSize, data);
        }
        core.memDownloadEnd(errorValue, errorPage, errorAddr, errorOffset);
        long timeDelta = System.nanoTime() - startTime;
        System.out.println(" download memory complete");
        if (timeDelta > 0) {
            long totalKBytes = (blockSize * blockCount) / 1024;
            double time = (double)timeDelta*1.0E-9;
            double KBperSec = (double)totalKBytes / time;
            System.out.println(String.format("Downloaded %dKB memory in %.2fs, i.e. %.2f KB/s", totalKBytes, time, KBperSec));
        }
    }

    /*
     * Runs through an example set of memory operations.
     * Use this as examples of how to access memory
     * @param core the DTSL device which represents a CPU core
     */
    private void memoryOps(
          IDevice core
    ) throws DTSLException {
        Map<String, Long> testParams = new HashMap<String, Long>(); 
        Long ramStart = Long.decode(this.options.getProperty(CommandLineOptions.RAMSTART));
        testParams.put("testAddressBase", ramStart);
        Long ramSize =  Long.decode(this.options.getProperty(CommandLineOptions.RAMSIZE));
        testParams.put("testAddressSize", ramSize);
           testParams.put("blockSize", 8192L);
        memoryRead(core, testParams);
        memoryWrite(core, testParams);
        sizeMemoryAccess(core, testParams);
        memoryDownload(core, testParams);
    }
    
    /** 
     * Examples of single stepping the core
     * @param core the DTSL device which represents a CPU core
     */
    private void stepOps(
          IDevice core
    ) throws DTSLException {
        //Ensure core is halted
        if (this.coreObserver.getState() == RDDI_EVENT_TYPE.RDDI_PROC_STATE_RUNNING)
            stopCore(core);
        System.out.println(String.format("PC before stepping core is %s", getPCString(core)));
        int stepCount = 100;
        long startTime = System.nanoTime();
        core.step(stepCount, 0);
        long timeDelta = System.nanoTime() - startTime;
        System.out.println(String.format("PC after stepping core is %s", getPCString(core)));
        if (timeDelta > 0) {
            double time = (double)timeDelta*1.0E-9;
            double stepsPerSec = (double)stepCount / time;
            System.out.println(String.format(
                "Stepped %d instructions in %.2fs, i.e. %.2f steps/s", 
                stepCount, time, stepsPerSec));
        }
    }
    
    /** 
     * Examples of executing and halting the core
     * @param core the DTSL device which represents a CPU core
     */
    private void execOps(
          IDevice core
    ) throws DTSLException {
        //Ensure core is halted
        if (this.coreObserver.getState() == RDDI_EVENT_TYPE.RDDI_PROC_STATE_RUNNING)
            stopCore(core);
        System.out.println(String.format("PC before starting executing is %s", getPCString(core)));
        // Set it running
        startCore(core);
        // Give the core some time to run
        try {Thread.sleep(1000);}
        catch (InterruptedException e) {}
        // Halt it
        stopCore(core);
        System.out.println(String.format("PC after halting executing is %s", getPCString(core)));
    }

    /** 
     * Runs through an example set of execution operations
     * Use this as examples of how to control target execution
     * @param core the DTSL device which represents a CPU core
     */
    private void executionOps(
          IDevice core
    ) throws DTSLException {
        stepOps(core);
        execOps(core);
    }
    
    /**
     * This program demonstrates the standalone use of DTSL by a Java program.
     * DTSL (Debug & Trace Services Layer) is used by the DS-5 debugger for low
     * level access to the target system. 
     */
    private void mainProgram(String[] args) {
        System.out.println("DTSL Java example started");    
        try {
            processOptions(args);
            showOptions();
            IConnection dtslConnection = connectToDTSL();
            IConfiguration dtslConfiguration = dtslConnection.getConfiguration();
            try {
                System.out.println("DTSL Configuration name: " + dtslConfiguration.getName());
                showDTSLDevices(dtslConfiguration);
                String coreName = this.options.getProperty(CommandLineOptions.DEVICE);
                System.out.println("Connecting to device "  + coreName);  
                IDevice core = getDTSLDeviceByName(dtslConfiguration, coreName);
                if (core == null) {
                    System.out.println("Could not find "+coreName+" in the device list");
                    System.exit(DTSLExample.DEVICE_NOT_FOUND);
                } else {
                    dtslConfiguration.connect();
                    connectToDevice(core);
                    try {
                        resetAndHaltCore(core);
                        executionOps(core);
                        registerOps(core);
                        memoryOps(core);
                    } catch (DTSLException e) {
                        showDTSLException(e);
                        System.exit(DTSLExample.FAILED_TO_CONTROL_DEVICE);
                    } catch (PyException e) {
                        showJythonException(e);
                        System.exit(DTSLExample.FAILED_TO_CONTROL_DEVICE);
                    } catch (RuntimeException e) {
                        System.out.println(e.getMessage());
                        System.exit(DTSLExample.FAILED_TO_CONTROL_DEVICE);
                    } finally {
                        System.out.println("Closing core connection");    
                        core.closeConn();
                    }
                }
            }
            catch (DTSLException e) {
                showDTSLException(e);
                System.exit(DTSLExample.FAILED_TO_CONNECT_TO_DEVICE);
            } catch (PyException e) {
                showJythonException(e);
                System.exit(DTSLExample.FAILED_TO_CONNECT_TO_DEVICE);
            } finally {
                System.out.println("Closing DTSL connection");    
                dtslConfiguration.disconnect();
                dtslConnection.disconnect();
            }
        }
        catch (DTSLException e) {
            showDTSLException(e);
            System.exit(DTSLExample.DTSL_CONNECTION_FAILED);
        }
        catch (Exception e) {
            System.out.println(e.getMessage());
            System.exit(DTSLExample.DTSL_CONNECTION_FAILED);
        }
    }
    
}
