DTSL Probe Vcc Example
----------------------

This is an example of a stand alone DTSL program which connects to a DSTREAM
unit and shows its configuration items and their current values. Some of these
configuration items allow the identification of the probe connection currently
in use along with the state of target Vcc.

NOTE: that this example is a complete stand-alone application. It can not be run
at the same time as a DS-5 Debugger connection has been made to the same target.

Running the example
-------------------

The example can be run from within DS-5 using the Jython run configuration 
DTSLProbeVcc.launch.

Alternatively, the example can be run on the command-line by starting the 
Windows dbgprobevcc.bat file or the Linux dbgprobevcc bash script. 
Before you run it make sure you have edited the ../DTSL/dtslsetup.bat batch
file or the ../DTSL/dtslsetup bash script to setup the correct environment.
Also, you must edit the dtslexample.bat file (or dtslexample script) and change 
the program parameters to suite the target system you are connecting to.

The batch file is set up to connect to a Keil MCBSTM32E board using the DS-5 config
database as installed to the default location under Windows with a configdb
extension in the Eclipse workspace. To make the batch file functional for your
environment you will have to edit it.

You will need to:
   * Change the connection address for the DSTREAM box to match your box
   * Change the location of the DS-5 configuration database roots to point
     to your installed DS-5 configdb and the path to the configdb
     entry within the project in your Eclipse workspace
   * Change the manufacturer to match the folder name of your platform
     contained in the Boards sub directory of the DS-5 config database
   * Change the board name to match the board folder within the manufacturer
     folder specified above
   * Change the debug operation to match against one of the activity names
     contained in a bare metal debug section of the project_types.xml file
     e.g. <activity id="ICE_DEBUG" type="Debug">
             <name language="en">Debug Cortex-A9_0 via DSTREAM/RVI</name>

