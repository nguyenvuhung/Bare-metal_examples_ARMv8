'''
Stand alone DTSL Jython program.
This example shows how to access the DSTREAM configuration items and
specifically how to monitor the target connection Vcc and probe type.
Copyright (C) 2014 ARM Limited. All rights reserved.
'''

import sys
from com.arm.debug.dtsl import ConnectionManager
from com.arm.debug.dtsl.interfaces import IConfiguration
from com.arm.debug.dtsl import DTSLException
from com.arm.debug.dtsl.interfaces import IDevice
from programoptions import ProgramOptions
from java.lang import StringBuilder
from org.python.core import PyException
from com.arm.rddi import IDebug

class MainProgram:
    ''' A class used to contain the program operation
    '''
    # Program return values
    BAD_OPTIONS = -1
    DTSL_CONNECTION_FAILED = -2
    DEVICE_NOT_FOUND = -3
    FAILED_TO_CONNECT_TO_DEVICE = -4
    FAILED_TO_CONTROL_DEVICE = -5

    def __init__(self):
        self.dtslConnection = None
        self.dtslConfiguration = None

    def showOptions(self, options):
        """ Prints out the program options """
        print "Options:"
        if options.usesConfigdb():
            print("   configdb         : %s" % (options.getConfigDBLocations()))
            print("   Manufacturer     : %s" % (options.getManufacturer()))
            print("   Board            : %s" % (options.getBoard()))
            print("   Debug Operation  : %s" % (options.getDebugOperation()))
        if options.usesDTSLScript():
            print("   DTSL script      : %s" % (options.getDTSLScript()))
            print("   DTSL class       : %s" % (options.getDTSLScriptClass()))
            print("   DTSL options     : %s" % (options.getDTSLOptions()))
        print("   RDDI config file : %s" % (options.getRDDIConfigFile()))
        print("   Connection Type  : %s" % (options.getConnectionType()))
        print("   Connection Addr  : %s" % (options.getConnectionAddress()))

    def getDTSLDeviceByName(self, dtslConfiguration, deviceName):
        """ Returns a device object referenced by name
        Parameters:
            dtslConfiguration - the DTSL configuration object
            deviceName - the device name e.e. "Cortex-A9_0" or "TPIU"
        NOTE: the device object we return implements the IDevice interface
        """
        assert isinstance(dtslConfiguration, IConfiguration)
        deviceList = dtslConfiguration.getDevices()
        for device in deviceList:
            assert isinstance(device, IDevice)
            if deviceName == device.getName():
                return device
        return None

    def showDTSLDevices(self, dtslConfiguration):
        """ Prints a list of device names contained in the DTSL configuration
        NOTE: Right now DTSL does not have a simple way of getting all
              such devices. This will be fixed in the next release.
        Parameters:
            dtslConfiguration - the DTSL configuration object
        """
        assert isinstance(dtslConfiguration, IConfiguration)
        print "DTSL Device list:"
        deviceList = dtslConfiguration.getDevices()
        for device in deviceList:
            assert isinstance(device, IDevice)
            print "   %2d: %s" % (device.getID(), device.getName())

    def showDTSLException(self, e):
        """ Prints out a DTSLException
        The exception chain is traversed and non-duplicated
        information from all levels is displayed
        Parameters:
            e - the DTSLException object
        """
        print >> sys.stderr, "Caught DTSL exception:"
        cause = e
        lastMessage = ""
        while cause != None:
            nextMessage = cause.getMessage()
            if nextMessage != lastMessage:
                if nextMessage != None:
                    print >> sys.stderr, nextMessage
                lastMessage = nextMessage
            cause = cause.getCause()

    def showJythonException(self, e):
        print >> sys.stderr, "Caught Jython exception:"
        print >> sys.stderr, e.toString()

    def showRuntimeError(self, e):
        """ Prints out a RuntimeException
        Parameters:
            e - the RuntimeException object
        """
        print >> sys.stderr, e

    def getDTSLConnection(self, dtslConfigData):
        """ Returns our (unconnected) DTSL connection object """
        params = dtslConfigData.getDTSLConnectionParameters()
        return ConnectionManager.openConnection(params)

    def getVCCDisplayString(self, vccCfgItemString):
        vccValue = int(vccCfgItemString)
        if vccValue == 0x10000000:
            return "unknown"
        elif vccValue == 0x20000000:
            return "low"
        elif vccValue == 0x30000000:
            return "high"
        elif vccValue < 20000:
            return "%.2fV" % (vccValue/1000.0)
        return "bad value (%s)" % (vccCfgItemString)

    def main(self):
        try:
            options = ProgramOptions("dbgrqtest", "1.0")
            options.processOptions()
            self.showOptions(options)
            self.dtslConnection = self.getDTSLConnection(
                options.getDTSLConfigData())
            self.dtslConfiguration = self.dtslConnection.getConfiguration()
            try:
                debug = self.dtslConfiguration.getDebug()
                assert isinstance(debug, IDebug)
                userName = "tony"
                clientInfo = StringBuilder(1024)
                iceInfo = StringBuilder(1024)
                copyrightInfo = StringBuilder(1024)
                debug.connect(userName, clientInfo, iceInfo, copyrightInfo)
                # Read list of all known config items
                output = StringBuilder(1024)
                debug.getConfig(0, "CONFIG_ITEMS", output)
                configItems = output.toString()
                print "Box config items:\n%s" %(configItems)
                if configItems.find("PROBE") != -1:
                    debug.getConfig(0, "PROBE", output)
                    print "PROBE=%s" % (output.toString())
                if configItems.find("VCC") != -1:
                    debug.getConfig(0, "VCC", output)
                    print "VCC=%s" % (output.toString())
                if configItems.find("CONNECTOR") != -1:
                    debug.getConfig(0, "CONNECTOR", output)
                    print "CONNECTOR=%s" % (output.toString())
                debug.disconnect(1)
                while True:
                    debug.connect(userName, clientInfo, iceInfo, copyrightInfo)
                    debug.getConfig(0, "CONNECTOR", output)
                    connector = output.toString()
                    debug.getConfig(0, "VCC", output)
                    vcc = self.getVCCDisplayString(output.toString())
                    print "CONNECTOR=%s Vcc=%s" % (connector, vcc)
                    debug.disconnect(1)
            except DTSLException, e:
                print
                self.showDTSLException(e)
                sys.exit(MainProgram.FAILED_TO_CONNECT_TO_DEVICE)
            except PyException, e:
                print
                self.showJythonException(e)
                sys.exit(MainProgram.FAILED_TO_CONNECT_TO_DEVICE)
            finally:
                print "Closing DTSL connection"
                self.dtslConfiguration.disconnect()
                self.dtslConnection.disconnect()
        except DTSLException, e:
            print
            self.showDTSLException(e)
            sys.exit(MainProgram.DTSL_CONNECTION_FAILED)
        except PyException, e:
            print
            self.showJythonException(e)
            sys.exit(MainProgram.DTSL_CONNECTION_FAILED)
        except RuntimeError, e:
            print
            print >> sys.stderr, e
            sys.exit(MainProgram.DTSL_CONNECTION_FAILED)

if __name__ == "__main__":
    from com.arm.debug.logging import LogFactory
    LogFactory.changeLogLevel("ERROR")  # use DEBUG for lots of logging
    # Create main program and run it
    program = MainProgram()
    program.main()
