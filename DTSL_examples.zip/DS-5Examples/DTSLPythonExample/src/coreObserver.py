from __future__ import with_statement
from com.arm.debug.dtsl.rddi import IDebugObserver
from com.arm.rddi import RDDI_Event
from com.arm.rddi import RDDI_EVENT_TYPE

from threading import Condition
import sys
import time


class CoreObserver(IDebugObserver):

    def __init__(self):
        self.lock = Condition()
        self.clear()

    def processEvent(self, event):
        assert isinstance(event, RDDI_Event)
        deviceID = event.deviceNo
        eventType = event.getEventType()
        try:
            if eventType == RDDI_EVENT_TYPE.RDDI_PROC_STATE_RUNNING:
                if self.getState() != eventType:
                    self.setState(eventType)
                    print "Got state change RDDI_EVENT_TYPE.RDDI_PROC_STATE_RUNNING for device %d" % (deviceID)

            elif eventType == RDDI_EVENT_TYPE.RDDI_PROC_STATE_STOPPED:
                if self.getState() != eventType:
                    self.setState(eventType)
                    print "Got state change RDDI_EVENT_TYPE.RDDI_PROC_STATE_STOPPED for device %d" % (deviceID)

            elif eventType == RDDI_EVENT_TYPE.RDDI_POWERED_DOWN:
                if self.getState() != eventType:
                    self.setState(eventType)
                    print "Got state change RDDI_EVENT_TYPE.RDDI_POWERED_DOWN for device %d" % (deviceID)

            elif eventType == RDDI_EVENT_TYPE.RDDI_HELD_IN_RESET:
                if self.getState() != eventType:
                    self.setState(eventType)
                    print "Got state change RDDI_EVENT_TYPE.RDDI_HELD_IN_RESET for device %d" % (deviceID)

        except Exception, e:
            print >>sys.stderr, e

    def clear(self):
        with self.lock:
            self.coreState = None
            self.coreStateInfo = None

    def setState(self, state, *args):
        with self.lock:
            self.coreState = state
            self.coreStateInfo = args
            self.lock.notify()

    def getState(self):
        with self.lock:
            state = self.coreState
        return state

    def waitForInitialState(self, timeout=None):
        with self.lock:
            if timeout is not None:
                deadline = time.time() + timeout
            while self.coreState is None:
                if timeout is not None:
                    timeLeft = deadline - time.time()
                    if timeLeft < 0:
                        raise RuntimeError("Timeout waiting for initial state")
                else:
                    timeLeft = None
                self.lock.wait(timeout)
            # reached required state
            stateInfo = self.coreStateInfo
        return stateInfo

    def waitForState(self, state, timeout=None):
        with self.lock:
            if timeout is not None:
                deadline = time.time() + timeout
            while self.coreState != state:
                if timeout is not None:
                    timeLeft = deadline - time.time()
                    if timeLeft < 0:
                        raise RuntimeError("Timeout waiting to reach %s" % state)
                else:
                    timeLeft = None
                self.lock.wait(timeout)
            # reached required state
            stateInfo = self.coreStateInfo
        return stateInfo

    def waitForStop(self, timeout=None):
        return self.waitForState(RDDI_EVENT_TYPE.RDDI_PROC_STATE_STOPPED, timeout)

    def waitForStart(self, timeout=None):
        self.waitForState(RDDI_EVENT_TYPE.RDDI_PROC_STATE_RUNNING, timeout)
