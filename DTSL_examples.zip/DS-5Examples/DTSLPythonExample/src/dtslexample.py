'''
Stand alone DTSL Jython program
Copyright (C) 2013 ARM Limited. All rights reserved.
'''

import sys
import time
import struct
from jarray import zeros, array
from com.arm.debug.dtsl import ConnectionManager
from com.arm.debug.dtsl.configurations import DTSLv1
from com.arm.debug.dtsl import DTSLException
from com.arm.debug.dtsl.interfaces import IDevice
from com.arm.debug.dtsl.rddi import DeviceRegisterInfo
from com.arm.rddi import RDDI_ACC_SIZE
from com.arm.rddi import jrddiConstants
from com.arm.rddi import RDDI_EVENT_TYPE
from coreObserver import CoreObserver
from programoptions import ProgramOptions
from java.lang import StringBuilder
from java.lang.System import nanoTime
from org.python.core import PyException
from com.arm.rddi import RDDIException


class MainProgram:
    ''' A class used to contain the program operation
    '''
    VERSION = "1.0"
    # This is the list of registers we display. If the core type
    # changes this may need to change as not all cores have the
    # same register names. Where a name is of the form A:B the
    # A and B names are considered aliases for the same register and
    # we will attempt to detect which one them the target uses
    coreRegisterList = (
        "R0", "R1", "R2", "R3",
        "R4", "R5", "R6", "R7",
        "R8", "R9", "R10", "R11",
        "R12", "SP:R13", "LR:R14", "PC:R15"
    )
    # This is the name of the PC register - on some cores it
    # is PC on others it is R15
    pcRegName = "PC:R15"

    # Program return values
    BAD_OPTIONS = -1
    DTSL_CONNECTION_FAILED = -2
    DEVICE_NOT_FOUND = -3
    FAILED_TO_CONNECT_TO_DEVICE = -4
    FAILED_TO_CONTROL_DEVICE = -5

    # Constants
    CORE_STOP_TIMEOUT = 1.0

    # used to map an RDDI_ACC_SIZE into a number of bytes
    rddiAccessSizeMap = {RDDI_ACC_SIZE.RDDI_ACC_WORD: 4,
                         RDDI_ACC_SIZE.RDDI_ACC_HALF: 2,
                         RDDI_ACC_SIZE.RDDI_ACC_BYTE: 1,
                         RDDI_ACC_SIZE.RDDI_ACC_WORD40: 5,
                         RDDI_ACC_SIZE.RDDI_ACC_WORD64: 8,
                         RDDI_ACC_SIZE.RDDI_ACC_DEF: 1}

    def __init__(self):
        self.registerIDMap = []
        self.coreRegisterNames = []
        self.coreRegisterIDs = []
        self.dtslConnection = None
        self.dtslConfiguration = None
        self.coreObserver = CoreObserver()

    def showOptions(self, options):
        """ Prints out the program options """
        print "Options:"
        if options.usesConfigdb():
            print("   configdb         : %s" % (options.getConfigDBLocations()))
            print("   Manufacturer     : %s" % (options.getManufacturer()))
            print("   Board            : %s" % (options.getBoard()))
            print("   Debug Operation  : %s" % (options.getDebugOperation()))
        if options.usesDTSLScript():
            print("   DTSL script      : %s" % (options.getDTSLScript()))
            print("   DTSL class       : %s" % (options.getDTSLScriptClass()))
            print("   DTSL options     : %s" % (options.getDTSLOptions()))
        print("   RDDI config file : %s" % (options.getRDDIConfigFile()))
        print("   Device name      : %s" % (options.getDeviceName()))
        print("   Connection Type  : %s" % (options.getConnectionType()))
        print("   Connection Addr  : %s" % (options.getConnectionAddress()))
        print("   Memory Address   : %s" % (self.toHex(options.getRAMStart())))
        units, divisor = self.calcMemUnits(options.getRAMSize())
        print("   Memory Size      : %.2f %s" % (options.getRAMSize() / divisor, units))

    def calcMemUnits(self, byteCount):
        '''Returns a reasonably scaled memory size value and units string
        Parameters:
            byteCount
                The size of the memory in bytes
        Returns:
            The scaled memory value
            The units string
        '''
        if (byteCount < 1024):
            return "bytes", 1.0
        elif (byteCount < 1024 * 1024):
            return "KB", 1024.0
        elif (byteCount < 1024 * 1024 * 1024):
            return "MB", 1024.0 * 1024.0
        return "GB", 1024.0 * 1024.0 * 1024.0

    def toHex(self, rVal):
        """ Converts an integer value to a hex string
        Returns a string of the form 0xhhhhhhhh which is the hex
        value of rVal
        Parameters:
            rVal - the integer value to be converted
        """
        return "0x%s" % ("00000000%x" % (rVal & 0xffffffff))[-8:]

    def getDTSLDeviceByName(self, dtslConfiguration, deviceName):
        """ Returns a device object referenced by name
        Parameters:
            dtslConfiguration - the DTSL configuration object
            deviceName - the device name e.e. "Cortex-A9_0" or "TPIU"
        NOTE: the device object we return implements the IDevice interface
        """
        assert isinstance(dtslConfiguration, DTSLv1)
        # Search the device list first
        deviceList = dtslConfiguration.getDevices()
        for device in deviceList:
            assert isinstance(device, IDevice)
            if deviceName == device.getName():
                return device
        # If not found, search the device interface list
        # (SMP type devices dont get added to the normal
        # device list)
        ifList = dtslConfiguration.getDeviceInterfaces()
        device = ifList.get(deviceName)
        if device != None:
            return device
        return None

    def showDTSLDevices(self, dtslConfiguration):
        """ Prints a list of device names contained in the DTSL configuration
        NOTE: Right now DTSL does not have a simple way of getting all
              such devices. This will be fixed in the next release.
        Parameters:
            dtslConfiguration - the DTSL configuration object
        """
        assert isinstance(dtslConfiguration, DTSLv1)
        print "DTSL Device list:"
        deviceList = dtslConfiguration.getDevices()
        for device in deviceList:
            assert isinstance(device, IDevice)
            print "   %2d: %s" % (device.getID(), device.getName())

    def showDTSLException(self, e):
        """ Prints out a DTSLException
        The exception chain is traversed and non-duplicated
        information from all levels is displayed
        Parameters:
            e - the DTSLException object
        """
        print >> sys.stderr, "Caught DTSL exception:"
        cause = e
        lastMessage = ""
        while cause != None:
            nextMessage = cause.getMessage()
            if nextMessage != lastMessage:
                if nextMessage != None:
                    print >> sys.stderr, nextMessage
                lastMessage = nextMessage
            cause = cause.getCause()

    def showRDDIException(self, e):
        """ Prints out a RDDIException
        The exception chain is traversed and non-duplicated
        information from all levels is displayed
        Parameters:
            e - the RDDIException object
        """
        print >> sys.stderr, "Caught RDDI exception:"
        cause = e
        lastMessage = ""
        while cause != None:
            nextMessage = cause.getMessage()
            if nextMessage != lastMessage:
                if nextMessage != None:
                    print >> sys.stderr, nextMessage
                lastMessage = nextMessage
            cause = cause.getCause()

    def showJythonException(self, e):
        print >> sys.stderr, "Caught Jython exception:"
        print >> sys.stderr, e.toString()

    def showRuntimeError(self, e):
        """ Prints out a RuntimeException
        Parameters:
            e - the RuntimeException object
        """
        print >> sys.stderr, e

    def connectToDTSL(self, dtslConfigData):
        """ Makes our connection to DTSL and returns the connection object """
        params = dtslConfigData.getDTSLConnectionParameters()
        print "Connecting to DTSL ...",
        startTime = nanoTime()
        conn = ConnectionManager.openConnection(params)
        conn.connect()
        timeDelta = nanoTime() - startTime
        if timeDelta > 0:
            timeS = timeDelta * 1.0E-9
            print "done, connection took %.2fs" % (timeS)
        else:
            print "done"
        return conn

    def connectToDevice(self, device):
        """ Makes a connection to a core (or other device)
        Parameters:
            core - the DTSL device to connect to
        """
        assert isinstance(device, IDevice)
        deviceInfo = StringBuilder(256)
        print "Connecting to device ...",
        startTime = nanoTime()
        device.openConn(None, None, deviceInfo)
        timeDelta = nanoTime() - startTime
        if timeDelta > 0:
            timeS = timeDelta * 1.0E-9
            print "done, connection took %.2fs" % (timeS)
        else:
            print "done"
        deviceName = StringBuilder(256)
        deviceDetails = StringBuilder(256)
        device.getDeviceDetails(deviceName, deviceDetails)
        print "Connected to " + deviceName.toString()
        print "   device info    : " + deviceInfo.toString()
        print "   device details : " + deviceDetails.toString()
        self.generateDeviceRegisterNameMap(device)
        self.generateCoreRegisters(device)
        device.addDebugEventObserver(self.coreObserver)

    def generateDeviceRegisterNameMap(self, device):
        """ Creates the self.registerIDMap list
        self.registerIDMap[] holds tuples (Name, ID) for each register.
        This lets us convert a register name into its integer ID
        Parameters:
            device - the DTSL device of interest
        """
        assert isinstance(device, IDevice)
        # Read info on all device registers
        regInfo = DeviceRegisterInfo.getRegisterInfo(device)
        # Add all to the registerIDMap[]
        regNames = sorted(regInfo.keySet())
        for regName in regNames:
            self.registerIDMap.append((regName, regInfo[regName].getId()))

    def generateCoreRegisters(self, core):
        """ Creates the self.coreRegisters list
        self.coreRegisters holds the name and integer IDs associated
        with each of the registers in coreRegisterList[].
        Parameters:
            core - the DTSL device which represents a CPU core
        """
        assert isinstance(core, IDevice)
        for reg in MainProgram.coreRegisterList:
            regNames = reg.split(":")
            for name in regNames:
                if not reg in self.coreRegisterNames:
                    for idMap in self.registerIDMap:
                        if name == idMap[0]:
                            self.coreRegisterNames.append(reg)
                            self.coreRegisterIDs.append(idMap[1])

    def stopCore(self, core):
        """ stops the core
        If we dont manage to stop the core we throw a RuntimeError
        Parameters:
            core - the DTSL device which represents a CPU core
        """
        assert isinstance(core, IDevice)
        core.stop()
        self.coreObserver.waitForStop(MainProgram.CORE_STOP_TIMEOUT)

    def startCore(self, core):
        """ starts the core
        If we dont manage to start the core we throw a RuntimeError
        Parameters:
            core - the DTSL device which represents a CPU core
        """
        assert isinstance(core, IDevice)
        # NOTE: This is not obvious, but if _we_ start the core, we dont get
        #       any async event notification that our core is running.
        #       So we must manually set our state
        self.coreObserver.setState(RDDI_EVENT_TYPE.RDDI_PROC_STATE_RUNNING)
        try:
            core.go()
        except DTSLException, e:  #  @UnusedVariable
            # go() failed, so assume we did not start executing. An alternate
            # here would be to set the state to RDDI_EVENT_TYPE.RDDI_PROC_STATE_UNKNOWN
            self.coreObserver.setState(RDDI_EVENT_TYPE.RDDI_PROC_STATE_STOPPED)
            raise

    def showAllRegisters(self, device):
        """ Prints out all the register values in hex
        Parameters:
            device - the DTSL device of interest
        """
        assert isinstance(device, IDevice)
        print "Complete register set:"
        regCount = len(self.registerIDMap)
        if regCount > 0:
            # Create a Java array to receive the register values
            values = zeros(regCount, 'i')
            # Create java array to hold register IDs
            regIDs = zeros(regCount, 'i')
            for idx in range(regCount):
                regIDs[idx] = self.registerIDMap[idx][1]
            # Read all register values
            device.regReadList(regIDs, values)
            for idx in range(regCount):
                print "%s = %s" % (self.registerIDMap[idx][0], self.toHex(values[idx]))

    def showCoreRegisters(self, core):
        """ Prints out the core register values in hex
        Parameters:
            core - the DTSL device which represents a CPU core
        """
        assert isinstance(core, IDevice)
        # Create a Java array to receive the register values
        values = zeros(len(self.coreRegisterIDs), 'i')
        # Read all register values
        core.regReadList(array(self.coreRegisterIDs, 'i'), values)
        print "Core register set:"
        for idx in range(len(self.coreRegisterIDs)):
            print "%6s = %s" % (self.coreRegisterNames[idx], self.toHex(values[idx]))

    def changeRegisters(self, core):
        """ Shows how to modify register values
        Parameters:
            core - the DTSL device which represents a CPU core
        """
        assert isinstance(core, IDevice)
        # Create a Java array to hold the register value
        values = zeros(1, 'i')
        # Create a list holding the register IDs we wish to read/write
        regList = array([self.coreRegisterIDs[
                            self.coreRegisterNames.index("R0")]
                        ], 'i')
        # Read and save register values
        core.regReadList(regList, values)
        r0Val = values[0]
        # Change the values and write them back
        values[0] = 0x12345678
        core.regWriteList(regList, values)
        # Read back the (hopefully) changed values
        core.regReadList(regList, values)
        if values[0] != 0x12345678:
            raise RuntimeError("Failed to modify R0")
        # Put back the original values
        values[0] = r0Val
        core.regWriteList(regList, values)

    def isResetVectorCatchSupported(self, core):
        """ Returns True if reset vector catch is supported
        Parameters:
            core - the DTSL device which represents a CPU core
        """
        assert isinstance(core, IDevice)
        procBreaks = core.listProcBreaks()
        for pBreak in procBreaks:
            if pBreak.find("RSET") != -1:
                return True
        return False

    def setResetVectorCatch(self, core, state):
        """ Sets or clears reset vector catch
        Parameters:
            core - the DTSL device which represents a CPU core
            state - True to turn on, False to turn off
        """
        assert isinstance(core, IDevice)
        if state:
            core.setProcBreak("RSET")
        else:
            core.clearProcBreak("RSET")

    def resetCore(self, core, postResetStateHalted):
        """ Resets the core and optionally halt ASAP
        Parameters:
            core - the DTSL device which represents a CPU core
            postResetStateHalted - True to halt the core ASAP following the reset
        """
        assert isinstance(core, IDevice)
        # Read the list of supported processor breaks (vector catch)
        if postResetStateHalted:
            if self.isResetVectorCatchSupported(core):
                self.setResetVectorCatch(core, True)
            try:
                core.setConfig("POST_RESET_STATE", "1")
            except DTSLException:
                pass
        else:
            if self.isResetVectorCatchSupported(core):
                self.setResetVectorCatch(core, False)
            try:
                core.setConfig("POST_RESET_STATE", "0")
            except DTSLException:
                pass
        core.systemReset(jrddiConstants.RDDI_RST_PERFORM)

    def resetAndHaltCore(self, core):
        """ Resets and halts the core
        Parameters:
            core - the DTSL device which represents a CPU core
        """
        assert isinstance(core, IDevice)
        self.resetCore(core, postResetStateHalted=True)
        try:
            self.coreObserver.waitForStop(1.0)
        except RuntimeError, e:
            try:
                self.stopCore()
            except RuntimeError, e:
                print >> sys.stderr, "Unable to halt the core"
                raise e
        print "Core reset and Stopped OK with PC=%s" % (self.getPCString(core))

    def getPC(self, core):
        """ Read the core PC register
        Parameters:
            core - the DTSL device which represents a CPU core
        """
        assert isinstance(core, IDevice)
        # Create a Java array to receive the register values
        values = zeros(1, 'i')
        # Create register list to read
        regIDs = zeros(1, 'i')
        pcRegID = self.coreRegisterIDs[
                      self.coreRegisterNames.index(MainProgram.pcRegName)
                  ]
        regIDs[0] = pcRegID
        core.regReadList(regIDs, values)
        return values[0]

    def getPCString(self, core):
        """ Formats the PC into a string
        Parameters:
            core - the DTSL device which represents a CPU core
        """
        return self.toHex(self.getPC(core))

    def registerOps(self, core):
        """ Runs through an example set of register operations
        Use this as examples of how to access registers
        Parameters:
            core - the DTSL device which represents a CPU core
        """
        self.showCoreRegisters(core)
        self.showAllRegisters(core)
        self.changeRegisters(core)

    def memoryRead(self, core, testParams):
        """ Demonstrates memory read operations
        Parameters:
            core - the DTSL device which represents a CPU core
            testParams - a dictionary of test parameters shared
                         between all the memory operation examples
        """
        assert isinstance(core, IDevice)
        testAddressBase = testParams["testAddressBase"]
        testAddressSize = testParams["testAddressSize"]
        blockSize = testParams["blockSize"]
        blockCount = testAddressSize / blockSize
        data = zeros(blockSize, 'b')

        print "Started timing memory read, please wait ...",
        t0 = time.time()
        for block in range(blockCount): #@UnusedVariable
            core.memRead(0, testAddressBase, RDDI_ACC_SIZE.RDDI_ACC_DEF, 0, blockSize, data)
        t1 = time.time()
        print "reading memory complete"
        timeDelta = t1 - t0
        totalKBytes = (blockSize * blockCount) / 1024
        KBperSec = totalKBytes / timeDelta
        print("Read %dKB memory in %.2fs, i.e. %.2f KB/s" % (totalKBytes, timeDelta, KBperSec))

    def sizeMemoryAccess2(self, core, testParams):
        """ Demonstrates sized memory read/write operations
        These are where you can specify the exact access size which
        must be used when reading/writing memory. Typical uses for this are
        when accessing onchip peripheral registers which _must_ be
        read/written using a certain access size.
        Parameters:
            core - the DTSL device which represents a CPU core
            testParams - a dictionary of test parameters shared
                         between all the memory operation example
        """
        assert isinstance(core, IDevice)
        testAddressBase = testParams["testAddressBase"]
        # Setup the Java arrays which will hold our sized data
        # NOTE: this code assumes a little-endian memory system
        # NOTE: the last byte is 0x87 to ensure signed value issues are OK
        data8In = struct.pack('<BBBB', 0x12, 0x34, 0x56, 0x87)
        data8Out = zeros(4, 'b')
        # Show writing 4 bytes and reading back as 32bit, 16bit and 8bit.
        # Note that whatever the access size is, the data is always transfered
        # as a byte array
        core.memWrite(0, testAddressBase, RDDI_ACC_SIZE.RDDI_ACC_BYTE, 0, False, 4, data8In)
        core.memRead(0, testAddressBase, RDDI_ACC_SIZE.RDDI_ACC_WORD, 0, 4, data8Out)
        d32 = struct.unpack('<I', data8Out)
        if d32[0] != 0x87563412:
            print >> sys.stderr, "Sized memory access failure; 4x8bit vs 1x32 bit mismatch"
        core.memRead(0, testAddressBase, RDDI_ACC_SIZE.RDDI_ACC_HALF, 0, 4, data8Out)
        d16 = struct.unpack('<HH', data8Out)
        if d16[0] != 0x3412:
            print >> sys.stderr, "Sized memory access failure; 4x8bit vs 2x16[0] bit mismatch"
        if d16[1] != 0x8756:
            print >> sys.stderr, "Sized memory access failure; 4x8bit vs 2x16[1] bit mismatch"
        core.memRead(0, testAddressBase, RDDI_ACC_SIZE.RDDI_ACC_BYTE, 0, 4, data8Out)
        d8 = struct.unpack('<BBBB', data8Out)
        if d8[0] != 0x12:
            print >> sys.stderr, "Sized memory access failure; 4x8bit vs 4x8[0] bit mismatch"
        if d8[1] != 0x34:
            print >> sys.stderr, "Sized memory access failure; 4x8bit vs 4x8[1] bit mismatch"
        if d8[2] != 0x56:
            print >> sys.stderr, "Sized memory access failure; 4x8bit vs 4x8[2] bit mismatch"
        if d8[3] != 0x87:
            print >> sys.stderr, "Sized memory access failure; 4x8bit vs 4x8[3] bit mismatch"
        # Show writing 2 half words and reading back as 32bit, 16bit and 8bit.
        # Note that whatever the access size is, the data is always transfered
        # as a byte array
        core.memWrite(0, testAddressBase, RDDI_ACC_SIZE.RDDI_ACC_HALF, 0, False, 4, data8In)
        core.memRead(0, testAddressBase, RDDI_ACC_SIZE.RDDI_ACC_WORD, 0, 4, data8Out)
        d32 = struct.unpack('<I', data8Out)
        if d32[0] != 0x87563412:
            print >> sys.stderr, "Sized memory access failure; 2x16bit vs 1x32 bit mismatch"
        core.memRead(0, testAddressBase, RDDI_ACC_SIZE.RDDI_ACC_HALF, 0, 4, data8Out)
        d16 = struct.unpack('<HH', data8Out)
        if d16[0] != 0x3412:
            print >> sys.stderr, "Sized memory access failure; 2x16bit vs 2x16[0] bit mismatch"
        if d16[1] != 0x8756:
            print >> sys.stderr, "Sized memory access failure; 2x16bit vs 2x16[1] bit mismatch"
        core.memRead(0, testAddressBase, RDDI_ACC_SIZE.RDDI_ACC_BYTE, 0, 4, data8Out)
        d8 = struct.unpack('<BBBB', data8Out)
        if d8[0] != 0x12:
            print >> sys.stderr, "Sized memory access failure; 2x16bit vs 4x8[0] bit mismatch"
        if d8[1] != 0x34:
            print >> sys.stderr, "Sized memory access failure; 2x16bit vs 4x8[1] bit mismatch"
        if d8[2] != 0x56:
            print >> sys.stderr, "Sized memory access failure; 2x16bit vs 4x8[2] bit mismatch"
        if d8[3] != 0x87:
            print >> sys.stderr, "Sized memory access failure; 2x16bit vs 4x8[3] bit mismatch"
        # Show writing 1 word and reading back as 32bit, 16bit and 8bit.
        # Note that whatever the access size is, the data is always transfered
        # as a byte array
        core.memWrite(0, testAddressBase, RDDI_ACC_SIZE.RDDI_ACC_WORD, 0, False, 4, data8In)
        core.memRead(0, testAddressBase, RDDI_ACC_SIZE.RDDI_ACC_WORD, 0, 4, data8Out)
        d32 = struct.unpack('<I', data8Out)
        if d32[0] != 0x87563412:
            print >> sys.stderr, "Sized memory access failure; 1x32bit vs 1x32 bit mismatch"
        core.memRead(0, testAddressBase, RDDI_ACC_SIZE.RDDI_ACC_HALF, 0, 4, data8Out)
        d16 = struct.unpack('<HH', data8Out)
        if d16[0] != 0x3412:
            print >> sys.stderr, "Sized memory access failure; 1x32bit vs 2x16[0] bit mismatch"
        if d16[1] != 0x8756:
            print >> sys.stderr, "Sized memory access failure; 1x32bit vs 2x16[1] bit mismatch"
        core.memRead(0, testAddressBase, RDDI_ACC_SIZE.RDDI_ACC_BYTE, 0, 4, data8Out)
        d8 = struct.unpack('<BBBB', data8Out)
        if d8[0] != 0x12:
            print >> sys.stderr, "Sized memory access failure; 1x32bit vs 4x8[0] bit mismatch"
        if d8[1] != 0x34:
            print >> sys.stderr, "Sized memory access failure; 1x32bit vs 4x8[1] bit mismatch"
        if d8[2] != 0x56:
            print >> sys.stderr, "Sized memory access failure; 1x32bit vs 4x8[2] bit mismatch"
        if d8[3] != 0x87:
            print >> sys.stderr, "Sized memory access failure; 1x32bit vs 4x8[3] bit mismatch"

    def sizeMemoryAccess(self, core, testParams):
        """ Demonstrates sized memory read/write operations
        These are where you can specify the exact access size which
        must be used when reading/writing memory. Typical uses for this are
        when accessing onchip peripheral registers which _must_ be
        read/written using a certain access size.
        Parameters:
            core - the DTSL device which represents a CPU core
            testParams - a dictionary of test parameters shared
                         between all the memory operation examples
        """
        assert isinstance(core, IDevice)
        testAddressBase = testParams["testAddressBase"]
        # Setup the Java arrays which will hold our sized data
        # NOTE: this code assumes a little-endian memory system
        d8 = [0x01, 0x02, 0x03, 0x87]
        data8In = struct.pack('<BBBB', d8[0], d8[1], d8[2], d8[3])
        data8Out = zeros(4, 'b')
        # Show writing 4 bytes and reading back as 32bit, 16bit and 8bit.
        # Note that whatever the access size is, the data is always transfered
        # as a byte array
        core.memWrite(0, testAddressBase, RDDI_ACC_SIZE.RDDI_ACC_BYTE, 0, False, 4, data8In)
        core.memRead(0, testAddressBase, RDDI_ACC_SIZE.RDDI_ACC_WORD, 0, 4, data8Out)
        d8Out = struct.unpack('<BBBB', data8Out)
        if d8Out[0] != d8[0]:
            print >> sys.stderr, "Sized memory access failure; 4x8bit vs 1x32[0] bit mismatch"
        if d8Out[1] != d8[1]:
            print >> sys.stderr, "Sized memory access failure; 4x8bit vs 1x32[1] bit mismatch"
        if d8Out[2] != d8[2]:
            print >> sys.stderr, "Sized memory access failure; 4x8bit vs 1x32[2] bit mismatch"
        if d8Out[3] != d8[3]:
            print >> sys.stderr, "Sized memory access failure; 4x8bit vs 1x32[3] bit mismatch"
        core.memRead(0, testAddressBase, RDDI_ACC_SIZE.RDDI_ACC_HALF, 0, 4, data8Out)
        d8Out = struct.unpack('<BBBB', data8Out)
        if d8Out[0] != d8[0]:
            print >> sys.stderr, "Sized memory access failure; 4x8bit vs 2x16[0] bit mismatch"
        if d8Out[1] != d8[1]:
            print >> sys.stderr, "Sized memory access failure; 4x8bit vs 2x16[1] bit mismatch"
        if d8Out[2] != d8[2]:
            print >> sys.stderr, "Sized memory access failure; 4x8bit vs 2x16[2] bit mismatch"
        if d8Out[3] != d8[3]:
            print >> sys.stderr, "Sized memory access failure; 4x8bit vs 2x16[3] bit mismatch"
        core.memRead(0, testAddressBase, RDDI_ACC_SIZE.RDDI_ACC_BYTE, 0, 4, data8Out)
        d8Out = struct.unpack('<BBBB', data8Out)
        if d8Out[0] != d8[0]:
            print >> sys.stderr, "Sized memory access failure; 4x8bit vs 4x8[0] bit mismatch"
        if d8Out[1] != d8[1]:
            print >> sys.stderr, "Sized memory access failure; 4x8bit vs 4x8[1] bit mismatch"
        if d8Out[2] != d8[2]:
            print >> sys.stderr, "Sized memory access failure; 4x8bit vs 4x8[2] bit mismatch"
        if d8Out[3] != d8[3]:
            print >> sys.stderr, "Sized memory access failure; 4x8bit vs 4x8[3] bit mismatch"
        # Show writing 2 half words and reading back as 32bit, 16bit and 8bit.
        # Note that whatever the access size is, the data is always transfered
        # as a byte array
        core.memWrite(0, testAddressBase, RDDI_ACC_SIZE.RDDI_ACC_HALF, 0, False, 4, data8In)
        core.memRead(0, testAddressBase, RDDI_ACC_SIZE.RDDI_ACC_WORD, 0, 4, data8Out)
        d8Out = struct.unpack('<BBBB', data8Out)
        if d8Out[0] != d8[0]:
            print >> sys.stderr, "Sized memory access failure; 2x16bit vs 1x32[0] bit mismatch"
        if d8Out[1] != d8[1]:
            print >> sys.stderr, "Sized memory access failure; 2x16bit vs 1x32[1] bit mismatch"
        if d8Out[2] != d8[2]:
            print >> sys.stderr, "Sized memory access failure; 2x16bit vs 1x32[2] bit mismatch"
        if d8Out[3] != d8[3]:
            print >> sys.stderr, "Sized memory access failure; 2x16bit vs 1x32[3] bit mismatch"
        core.memRead(0, testAddressBase, RDDI_ACC_SIZE.RDDI_ACC_HALF, 0, 4, data8Out)
        d8Out = struct.unpack('<BBBB', data8Out)
        if d8Out[0] != d8[0]:
            print >> sys.stderr, "Sized memory access failure; 2x16bit vs 2x16[0] bit mismatch"
        if data8Out[1] != d8[1]:
            print >> sys.stderr, "Sized memory access failure; 2x16bit vs 2x16[1] bit mismatch"
        if d8Out[2] != d8[2]:
            print >> sys.stderr, "Sized memory access failure; 2x16bit vs 2x16[2] bit mismatch"
        if d8Out[3] != d8[3]:
            print >> sys.stderr, "Sized memory access failure; 2x16bit vs 2x16[3] bit mismatch"
        core.memRead(0, testAddressBase, RDDI_ACC_SIZE.RDDI_ACC_BYTE, 0, 4, data8Out)
        d8Out = struct.unpack('<BBBB', data8Out)
        if d8Out[0] != d8[0]:
            print >> sys.stderr, "Sized memory access failure; 2x16bit vs 4x8[0] bit mismatch"
        if d8Out[1] != d8[1]:
            print >> sys.stderr, "Sized memory access failure; 2x16bit vs 4x8[1] bit mismatch"
        if d8Out[2] != d8[2]:
            print >> sys.stderr, "Sized memory access failure; 2x16bit vs 4x8[2] bit mismatch"
        if d8Out[3] != d8[3]:
            print >> sys.stderr, "Sized memory access failure; 2x16bit vs 4x8[3] bit mismatch"
        # Show writing 1 word and reading back as 32bit, 16bit and 8bit.
        # Note that whatever the access size is, the data is always transfered
        # as a byte array
        core.memWrite(0, testAddressBase, RDDI_ACC_SIZE.RDDI_ACC_WORD, 0, False, 4, data8In)
        core.memRead(0, testAddressBase, RDDI_ACC_SIZE.RDDI_ACC_WORD, 0, 4, data8Out)
        d8Out = struct.unpack('<BBBB', data8Out)
        if d8Out[0] != d8[0]:
            print >> sys.stderr, "Sized memory access failure; 1x32bit vs 1x32[0] bit mismatch"
        if d8Out[1] != d8[1]:
            print >> sys.stderr, "Sized memory access failure; 1x32bit vs 1x32[1] bit mismatch"
        if d8Out[2] != d8[2]:
            print >> sys.stderr, "Sized memory access failure; 1x32bit vs 1x32[2] bit mismatch"
        if d8Out[3] != d8[3]:
            print >> sys.stderr, "Sized memory access failure; 1x32bit vs 1x32[3] bit mismatch"
        core.memRead(0, testAddressBase, RDDI_ACC_SIZE.RDDI_ACC_HALF, 0, 4, data8Out)
        d8Out = struct.unpack('<BBBB', data8Out)
        if d8Out[0] != d8[0]:
            print >> sys.stderr, "Sized memory access failure; 1x32bit vs 2x16[0] bit mismatch"
        if d8Out[1] != d8[1]:
            print >> sys.stderr, "Sized memory access failure; 1x32bit vs 2x16[1] bit mismatch"
        if d8Out[2] != d8[2]:
            print >> sys.stderr, "Sized memory access failure; 1x32bit vs 2x16[2] bit mismatch"
        if d8Out[3] != d8[3]:
            print >> sys.stderr, "Sized memory access failure; 1x32bit vs 2x16[3] bit mismatch"
        core.memRead(0, testAddressBase, RDDI_ACC_SIZE.RDDI_ACC_BYTE, 0, 4, data8Out)
        d8Out = struct.unpack('<BBBB', data8Out)
        if d8Out[0] != d8[0]:
            print >> sys.stderr, "Sized memory access failure; 1x32bit vs 4x8[0] bit mismatch"
        if d8Out[1] != d8[1]:
            print >> sys.stderr, "Sized memory access failure; 1x32bit vs 4x8[1] bit mismatch"
        if d8Out[2] != d8[2]:
            print >> sys.stderr, "Sized memory access failure; 1x32bit vs 4x8[2] bit mismatch"
        if d8Out[3] != d8[3]:
            print >> sys.stderr, "Sized memory access failure; 1x32bit vs 4x8[3] bit mismatch"

    def memoryWrite(self, core, testParams):
        """ Demonstrates memory write operations
        Parameters:
            core - the DTSL device which represents a CPU core
            testParams - a dictionary of test parameters shared
                         between all the memory operation examples
        """
        assert isinstance(core, IDevice)
        testAddressBase = testParams["testAddressBase"]
        testAddressSize = testParams["testAddressSize"]
        blockSize = testParams["blockSize"]
        blockCount = testAddressSize / blockSize
        data = zeros(blockSize, 'b')

        print "Started timing memory write, please wait ...",
        t0 = time.time()
        for block in range(blockCount): #@UnusedVariable
            core.memWrite(0, testAddressBase, RDDI_ACC_SIZE.RDDI_ACC_DEF, 0, False, blockSize, data)
        t1 = time.time()
        print "writing memory complete"
        timeDelta = t1 - t0
        totalKBytes = (blockSize * blockCount) / 1024
        KBperSec = totalKBytes / timeDelta
        print("Wrote %dKB memory in %.2fs, i.e. %.2f KB/s" % (totalKBytes, timeDelta, KBperSec))

    def memoryDownload(self, core, testParams):
        """ Demonstrates memory write operations
        Parameters:
            core - the DTSL device which represents a CPU core
            testParams - a dictionary of test parameters shared
                         between all the memory operation examples
        """
        assert isinstance(core, IDevice)
        testAddressBase = testParams["testAddressBase"]
        testAddressSize = testParams["testAddressSize"]
        blockSize = testParams["blockSize"]
        blockCount = testAddressSize / blockSize
        data = zeros(blockSize, 'b')
        # Memory download is slightly different from memory write in that
        # the first call to memDownload() places the system into down load mode
        # and uses optimized transport techniques to transfer the packets to the
        # target as fast as possible. Note that the memDownload() calls do no
        # error checking. At the end of the download you need to call
        # memDownloadEnd() and this will report any error which occurred
        # during the download.
        print "Started timing memory download, please wait ...",
        errorValue = zeros(1, 'i')
        errorPage = zeros(1, 'l')
        errorAddr = zeros(1, 'l')
        errorOffset = zeros(1, 'l')
        t0 = time.time()
        for block in range(blockCount): #@UnusedVariable
            # NOTE: we would normally update the address for each write, but we deliberately dont
            #       so that we dont write outside of a defined (small!) test area
            core.memDownload(0, testAddressBase, RDDI_ACC_SIZE.RDDI_ACC_DEF, 0, False, blockSize, data)
        core.memDownloadEnd(errorValue, errorPage, errorAddr, errorOffset)
        t1 = time.time()
        print "downloading memory complete"
        timeDelta = t1 - t0
        totalKBytes = (blockSize * blockCount) / 1024
        KBperSec = totalKBytes / timeDelta
        print("Downloaded %dKB memory in %.2fs, i.e. %.2f KB/s" % (totalKBytes, timeDelta, KBperSec))

    def memoryOps(self, core, testAddressBase, testAddressSize):
        """ Runs through an example set of memory operations
        Use this as examples of how to access memory
        Parameters:
            core - the DTSL device which represents a CPU core
        """
        assert isinstance(core, IDevice)
        testParams = {"testAddressBase": testAddressBase,
                      "testAddressSize": testAddressSize,
                      "blockSize": 8192}
        self.memoryRead(core, testParams)
        self.memoryWrite(core, testParams)
        self.sizeMemoryAccess(core, testParams)
        self.sizeMemoryAccess2(core, testParams)
        self.memoryDownload(core, testParams)

    def stepOps(self, core):
        """ Examples of single stepping the core
        Parameters:
            core - the DTSL device which represents a CPU core
        """
        assert isinstance(core, IDevice)
        # Ensure core is halted
        if self.coreObserver.getState() == RDDI_EVENT_TYPE.RDDI_PROC_STATE_RUNNING:
            self.stopCore(core)
        print "PC before stepping core is %s" % (self.getPCString(core))
        stepCount = 100
        t0 = time.time()
        core.step(stepCount, 0)
        t1 = time.time()
        timeDelta = t1 - t0
        stepsPerSec = stepCount / timeDelta
        print "PC after stepping core is %s" % (self.getPCString(core))
        print("Stepped %d instructions in %.2fs, i.e. %.2f steps/s" % (stepCount, timeDelta, stepsPerSec))

    def execOps(self, core):
        """ Examples of executing and halting the core
        Parameters:
            core - the DTSL device which represents a CPU core
        """
        assert isinstance(core, IDevice)
        # Ensure core is halted
        if self.coreObserver.getState() == RDDI_EVENT_TYPE.RDDI_PROC_STATE_RUNNING:
            self.stopCore(core)
        print "PC before starting executing is %s" % (self.getPCString(core))
        # Set it running
        self.startCore(core)
        # Give the core some time to run
        time.sleep(1.0)
        # Halt it
        self.stopCore(core)
        print "PC after halting executing is %s" % (self.getPCString(core))

    def executionOps(self, core):
        """ Runs through an example set of execution operations
        Use this as examples of how to control target execution
        Parameters:
            core - the DTSL device which represents a CPU core
        """
        assert isinstance(core, IDevice)
        self.stepOps(core)
        self.execOps(core)

    def configItems(self, device):
        try:
            rddiDebug = self.dtslConfiguration.getDebug()
            cfItemValue = StringBuilder(128)
            rddiDebug.getConfig(0, "mps_dut.dut_sysregs.user_switches_value", cfItemValue)
            print "mps_dut.dut_sysregs.user_switches_value = %s" % (cfItemValue.toString())
        except RDDIException, e:
            self.showRDDIException(e)

        try:
            cfItemValue = StringBuilder(128)
            device.getConfig("coretile.core.semihosting-enable", cfItemValue)
            print "coretile.core.semihosting-enable = %s" % (cfItemValue.toString())
        except DTSLException, e:
            self.showDTSLException(e)

        try:
            cfItemValue = StringBuilder(1024)
            device.getConfig("CONFIG_ITEMS", cfItemValue)
            print "CONFIG_ITEMS = %s" % (cfItemValue.toString())
        except DTSLException, e:
            self.showDTSLException(e)

    def main(self):
        ''' The main program
        This program demonstrates the stand-alone use of DTSL by a Jython program.
        DTSL (Debug & Trace Services Layer) is used by the DS-5 debugger for low
        level access to the target system. DTSL is mainly written in Java, but
        using Jython (instead of plain old Python) lets us access the Java code
        directly from within this program.
        '''
        print "DTSL Jython example started"

        try:
            options = ProgramOptions("dtslexample", MainProgram.VERSION)
            options.processOptions()
            self.showOptions(options)
            self.dtslConnection = self.connectToDTSL(options.getDTSLConfigData())
            self.dtslConfiguration = self.dtslConnection.getConfiguration()
            try:
                print "DTSL Configuration name: " + self.dtslConfiguration.getName()
                self.showDTSLDevices(self.dtslConfiguration)
                print "Connecting to device %s" % (options.getDeviceName())
                device = self.getDTSLDeviceByName(self.dtslConfiguration, options.getDeviceName())
                if device == None:
                    print >> sys.stderr, "Could not find %s in the device list" % (options.getDeviceName())
                    sys.exit(MainProgram.DEVICE_NOT_FOUND)
                self.dtslConfiguration.connect()
                self.connectToDevice(device)
                try:
                    self.resetAndHaltCore(device)
                    self.executionOps(device)
                    self.registerOps(device)
                    self.memoryOps(device, options.getRAMStart(), options.getRAMSize())
                except DTSLException, e:
                    self.showDTSLException(e)
                    sys.exit(MainProgram.FAILED_TO_CONTROL_DEVICE)
                except RuntimeError, e:
                    print >> sys.stderr, e
                    sys.exit(MainProgram.FAILED_TO_CONTROL_DEVICE)
                finally:
                    print "Closing device connection"
                    device.closeConn()
            except DTSLException, e:
                print
                self.showDTSLException(e)
                sys.exit(MainProgram.FAILED_TO_CONNECT_TO_DEVICE)
            except PyException, e:
                print
                self.showJythonException(e)
                sys.exit(MainProgram.FAILED_TO_CONNECT_TO_DEVICE)
            finally:
                print "Closing DTSL connection"
                self.dtslConfiguration.disconnect()
                self.dtslConnection.disconnect()
        except DTSLException, e:
            print
            self.showDTSLException(e)
            sys.exit(MainProgram.DTSL_CONNECTION_FAILED)
        except PyException, e:
            print
            self.showJythonException(e)
            sys.exit(MainProgram.DTSL_CONNECTION_FAILED)
        except RuntimeError, e:
            print
            print >> sys.stderr, e
            sys.exit(MainProgram.DTSL_CONNECTION_FAILED)

if __name__ == "__main__":
    from com.arm.debug.logging import LogFactory
    LogFactory.changeLogLevel("ERROR")  # use DEBUG for lots of logging
    # Create main program and run it
    program = MainProgram()
    program.main()
