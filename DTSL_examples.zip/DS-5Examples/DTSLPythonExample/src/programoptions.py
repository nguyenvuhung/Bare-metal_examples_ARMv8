'''
Module to process command line options
'''
from java.lang import System
from dtslconfigdata import DTSLConfigData
import configDBResolver
from optparse import OptionParser
from optparse import OptionGroup
import sys
import os


class ProgramOptions(object):
    '''
    Parses command line options and provides configuration data to the
    main program
    '''
    CDB32_WIN = "C:\\Program Files (x86)\\DS-5 v5.22.0\\sw\\debugger\\configdb"
    CDB64_WIN = "C:\\Program Files\\DS-5 v5.22.0\\sw\\debugger\\configdb"

    BAD_OPTIONS = -1

    def __init__(self, programName, version):
        '''
        Constructor
        '''
        self.programName = programName
        self.version = version
        self.dtslConfigData = DTSLConfigData()
        self.manufacturer = None
        self.board = None
        self.rddiConfigFile = None
        self.debugOperation = None
        self.connectionType = None
        self.configDBLocations = None
        self.device = None
        self.connectionType = None
        self.connectionAddress = None
        self.workspace = None
        self.dtslScript = None
        self.dtslClass = None
        self.dtslOptions = None
        self.ramStart = None
        self.ramSize = None
        # On Windows we try to setup some defaults
        if self.runningOnWindows():
            if os.path.isdir(ProgramOptions.CDB32_WIN):
                self.configDBLocations = ProgramOptions.CDB32_WIN
            elif os.path.isdir(ProgramOptions.CDB64_WIN):
                self.configDBLocations = ProgramOptions.CDB64_WIN
            homeDir = os.path.expanduser('~')
            posWorkspace = "%s\\My Documents\\DS-5 Workspace" % (homeDir)
            if os.path.isdir(posWorkspace):
                self.workspace = posWorkspace
            posWorkspace = "%s\\Documents\\DS-5 Workspace" % (homeDir)
            if os.path.isdir(posWorkspace):
                self.workspace = posWorkspace

    def runningOnWindows(self):
        os_name = System.getProperty("os.name")
        return os_name.startswith("Windows")

    def examples(self):
        print "e.g. %s --configdb \"c:\\Program Files (x86)\\DS-5 v5.22.0\\sw\\debugger\\configdb;C:\\Users\\tony\\workspace\\DTSLExampleConfigdb\\configdb\"" % (self.programName)
        print "     --manufacturer \"Keil-DTSLExample\" --board \"MCBSTM32E\""
        print "     --debugOperation = \"Debug and Trace of Cortex-M3\""
        print "     --dtslOptions = \"dtsloptions.dtslprops\""
        print "     --connectionType \"DSTREAM\""
        print "     --connectionAddress \"USB\""
        print "e.g. %s --rddiConfigFile \"C:\\Users\\tony\\workspace\\DTSLExampleConfigdb\\configdb\\Boards\\Keil-DTSLExample\\MCBSTM32E\\keil-mcbstm32e.rvc\"" % (self.programName)
        print "     --dtslScript \"C:\\Users\\tony\\workspace\\DTSLExampleConfigdb\\configdb\\Boards\\Keil-DTSLExample\\MCBSTM32E\\keil-mcbstm32e.py\""
        print "     --dtslClass DSTREAMDebugAndTrace"
        print "     --dtslOptions = \"dtsloptions.dtslprops\""
        print "     --connectionAddress \"USB\""

    def processOptions(self):
        """ Processes command line option """

        # Construct option specifications
        parser = OptionParser(usage="usage: %s [options] (use --help to see full option list)" % self.programName,
                              version="%s %s" % (self.programName, self.version),
                              description="DTSL example Jython program")

        group = OptionGroup(parser, "DS-5 ConfigDB Options",
                    "Options when invoked as a stand-alone DTSL program "
                    "getting the connection information from a DS-5 ConfigDB entry")
        group.add_option("-m", "--manufacturer", action="store", type="string",
                         dest="manufacturer", default=None,
                         help="the DS-5 configdb board manufacturer")
        group.add_option("-b", "--board", action="store", type="string",
                         dest="board", default=None,
                         help="the DS-5 configdb board name")
        group.add_option("-o", "--debugOperation", action="store", type="string",
                         dest="debugOperation", default=None,
                         help="the DS-5 debug operation (from project_types.xml)")
        group.add_option("-y", "--connectionType", action="store", type="string",
                         dest="connectionType", default=None,
                         help="the connection type (from project_types.xml)")
        parser.add_option_group(group)

        group = OptionGroup(parser, "DTSL Direct Options",
                    "Options when invoked as a stand-alone DTSL program "
                    "directly specifying the DTSL configuration information")
        group.add_option("-g", "--dtslScript", action="store", type="string",
                         dest="dtslScript", default=None,
                         help="the DTSL platform Jython script")
        group.add_option("-j", "--dtslClass", action="store", type="string",
                         dest="dtslClass", default=None,
                         help="the configuration class name (within the platform Jython script)")
        group.add_option("-r", "--rddiConfigFile", action="store", type="string",
                         dest="rddiConfigFile", default=None,
                         help="the RDDI configuration file (the .rvc file)")
        parser.add_option_group(group)

        group = OptionGroup(parser, "Common Options",
                    "Options which apply for all groups")
        group.add_option("-c", "--configdb", action="store", type="string",
                         dest="configdb", default=None,
                         help="the ; separated list of root configdb locations")
        group.add_option("-k", "--dtslOptions", action="store", type="string",
                         dest="dtslOptions", default=None,
                         help="the name of the DTSL option set")
        group.add_option("-d", "--device", action="store", type="string",
                         dest="device", default=None,
                         help="the DTSL device name e.g. Cortex-M3")
        group.add_option("-n", "--connectionAddress", action="store", type="string",
                         dest="connectionAddress", default="USB",
                         help="the device to connect to e.g. TCP:MyDSTREAM or USB")
        group.add_option("-x", "--examples", action="store_true",
                         dest="examples", default=False,
                         help="shows example invocations then exits")
        group.add_option("-a", "--ramStart", action="store",
                         dest="ramStart", default="0x20000000",
                         help="sets the start address of target RAM area")
        group.add_option("-z", "--ramSize", action="store",
                         dest="ramSize", default="65536",
                         help="sets the size in bytes of target RAM area")
        parser.add_option_group(group)
        # Process all supplied options
        options = parser.parse_args()[0]
        # If user asked for display of example options, show them
        if options.examples:
            self.examples()
            sys.exit(0) # force exit
        # Extract any supplied options into our local values
        if options.configdb != None:
            self.configDBLocations = options.configdb
        if options.manufacturer != None:
            self.manufacturer = options.manufacturer
        if options.board != None:
            self.board = options.board
        if options.debugOperation != None:
            self.debugOperation = options.debugOperation
        if options.connectionType != None:
            self.connectionType = options.connectionType
        if options.connectionAddress != None:
            self.connectionAddress = options.connectionAddress
        if options.rddiConfigFile != None:
            self.rddiConfigFile = options.rddiConfigFile
        if options.dtslScript != None:
            self.dtslScript = options.dtslScript
        if options.dtslClass != None:
            self.dtslClass = options.dtslClass
        if options.dtslOptions != None:
            self.dtslOptions = options.dtslOptions
        if options.device != None:
            self.device = options.device
        if options.ramStart != None:
            self.ramStart = int(options.ramStart, 0)
        if options.ramSize != None:
            self.ramSize = int(options.ramSize, 0)
        # If user specified DS-5 configdb data
        if (self.manufacturer != None) or (self.board != None) or (self.debugOperation != None):
            print "Getting connection parameters from configdb ...",
            params = configDBResolver.getConfigDBParameters(
                        self.configDBLocations,
                        self.manufacturer,
                        self.board,
                        self.debugOperation,
                        self.connectionType)
            if self.rddiConfigFile == None and "rddiConfigFile" in params:
                self.rddiConfigFile = params["rddiConfigFile"]
            if self.dtslScript == None and "dtslScript" in params:
                self.dtslScript = params["dtslScript"]
            if self.dtslClass == None and "dtslClass" in params:
                self.dtslClass = params["dtslClass"]
            if self.device == None and "device" in params:
                self.device = params["device"]
            print "done"
        # Populate the dtslConfigData object with what we have harvested
        self.dtslConfigData.setRDDIConfigurationFile(self.rddiConfigFile)
        self.dtslConfigData.setDTSLScript(self.dtslScript)
        self.dtslConfigData.setDTSLClass(self.dtslClass)
        self.dtslConfigData.setDTSLOptionsFile(self.dtslOptions)
        self.dtslConfigData.setConnectionType(self.connectionType)
        self.dtslConfigData.setConnectionAddress(self.connectionAddress)
        # Check we have enough configuration data
        isComplete, whatsMissing = self.dtslConfigData.isConfigComplete()
        if not isComplete:
            print >> sys.stderr, "Not enough configuration data has been given:"
            print >> sys.stderr, whatsMissing
            parser.print_usage()
            sys.exit(ProgramOptions.BAD_OPTIONS)

    def getDTSLConfigData(self):
        return self.dtslConfigData

    def getDeviceName(self):
        return self.device

    def usesConfigdb(self):
        return (self.manufacturer != None)

    def getConfigDBLocations(self):
        return self.configDBLocations

    def getManufacturer(self):
        return self.manufacturer

    def getBoard(self):
        return self.board

    def getDebugOperation(self):
        return self.debugOperation

    def usesDTSLScript(self):
        return (self.dtslScript != None)

    def getDTSLScript(self):
        return self.dtslScript

    def getDTSLScriptClass(self):
        return self.dtslClass

    def getDTSLOptions(self):
        return self.dtslOptions

    def getRDDIConfigFile(self):
        return self.rddiConfigFile

    def getConnectionType(self):
        return self.connectionType

    def getConnectionAddress(self):
        return self.connectionAddress

    def getRAMStart(self):
        return self.ramStart

    def getRAMSize(self):
        return self.ramSize
