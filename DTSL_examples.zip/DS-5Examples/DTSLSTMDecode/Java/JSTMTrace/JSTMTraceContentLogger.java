package JSTMTrace;

/**
 * If you are building using the workspace imported DTSL standalone dist:
 * javac -cp <workspace>/DTSL/libs/dtsl-bundle.jar -source 1.7 -target 1.7 StatsTraceSink.java
 * 
 * If you are building with access to the DTSL source code you can build using:
 * javac -sourcepath <src-path>/eclipse/plugins/com.arm.debug.dtsl/src StatsTraceSink.java
 */

import com.arm.debug.dtsl.decoders.stm.stmobjects.ISTMObjectReceiver;
import com.arm.debug.dtsl.decoders.stm.stmobjects.STMObject;
import com.arm.debug.dtsl.decoders.stm.stmobjects.STMData;
import com.arm.debug.dtsl.decoders.stm.stmobjects.STMSource;

import java.io.PrintStream;
import java.util.Map;
import java.util.TreeMap;
import java.util.TreeSet;

/**
 * Class which acts as a destination for STM objects and
 * just prints out a string representation of the object
 */
public class JSTMTraceContentLogger implements ISTMObjectReceiver {
    /**
     * The destination where we send the output to
     */
    private PrintStream dest;
    /**
     * Holds a map of Master ID to a set of channel IDs
     */
    private TreeMap<Integer, TreeSet<Integer>> stmSources;
    
    /**
     * Construction
     * @param dest the place we write our text output to
     */
    public JSTMTraceContentLogger(PrintStream dest) {
        this.dest = dest;
        this.stmSources = new TreeMap<Integer, TreeSet<Integer>>();
    }
    
    @Override
    public boolean write(STMObject stmObject) {
        // Only STMData objects have a Master ID and Channel ID source
        // associated with them
        if (stmObject instanceof STMData) {
            STMSource source = ((STMData)stmObject).getSource();
            if (this.stmSources.containsKey(source.masterID)) {
                // Already seen this master so just add channel ID
                this.stmSources.get(source.masterID).add(source.channelID);
            } else {
                // New master, so create and initialise the set()
                TreeSet<Integer> channelSet = new TreeSet<Integer>();
                channelSet.add(source.channelID);
                this.stmSources.put(new Integer(source.masterID), channelSet);
            }
        }
        return true;
    }

    /**
     * Requests us to make sure all our output has been
     * written to this.dest. In this case we use this as
     * a trigger to generate the output.
     */
    public void flush() {
        for (Map.Entry<Integer, TreeSet<Integer>> entry : 
            this.stmSources.entrySet()) {
            this.dest.printf(
                    "MasterID: %d\n", entry.getKey());
            TreeSet<Integer> channelSet = entry.getValue();
            for (Integer channelID : channelSet) {
                this.dest.printf(
                    "   ChannelID: %d\n", channelID);
            }
        }
        this.dest.flush();
    }

}
