package JSTMTrace;

/**
 * If you are building using the workspace imported DTSL standalone dist:
 * javac -cp <workspace>/DTSL/libs/dtsl-bundle.jar -source 1.7 -target 1.7 StatsTraceSink.java
 * 
 * If you are building with access to the DTSL source code you can build using:
 * javac -sourcepath <src-path>/eclipse/plugins/com.arm.debug.dtsl/src StatsTraceSink.java
 */

import com.arm.debug.dtsl.decoders.stm.stmobjects.ISTMObjectReceiver;
import com.arm.debug.dtsl.decoders.stm.stmobjects.STMObject;
import java.io.PrintStream;

/**
 * Class which acts as a destination for STM objects and
 * just prints out a string representation of the object
 */
public class JSTMTracePrinter implements ISTMObjectReceiver {
    /**
     * The destination where we send the output to
     */
    private PrintStream dest;
    
    /**
     * Construction
     * @param dest the place we write our text output to
     */
    public JSTMTracePrinter(PrintStream dest) {
        this.dest = dest;
    }
    
    @Override
    public boolean write(STMObject stmObject) {
        this.dest.println(stmObject.toString());
        return true;
    }

    /**
     * Requests us to make sure all our output has been
     * written to this.dest
     */
    public void flush() {
        this.dest.flush();
    }

}
