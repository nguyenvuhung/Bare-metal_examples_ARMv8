import sys
import os
from com.arm.debug.dtsl import ConnectionManager
from com.arm.debug.dtsl import ConnectionParameters
from com.arm.debug.dtsl.configurations import DTSLv1
from com.arm.debug.dtsl.interfaces import IDevice
from com.arm.debug.dtsl.components import ConnectableDevice
from java.lang import StringBuilder
from java.lang import Long
from jarray import zeros
from jarray import array
import math


class ProgramException(Exception):
    """ Exception class used within this program
    """
    def __init__(self, description, cause=None):
        self.description = description
        self.cause = cause

    def getCause(self):
        return self.cause

    def __str__(self):
        msg = "ProgramException: %s" % (self.description)
        if self.cause is not None:
            msg = msg + "\nCaused by:\n%s" % (self.cause.__str__())
        return msg

    def getMessage(self):
        return "ProgramException: %s" % (self.description)


def showProgramException(e):
    """ Prints out a ProgramException
    The exception chain is traversed and non-duplicated
    information from all levels is displayed
    Parameters:
        e - the ProgramException object
    """
    print >> sys.stderr, "Caught program exception:"
    cause = e
    lastMessage = ""
    while cause is not None:
        nextMessage = cause.getMessage()
        if nextMessage != lastMessage:
            if nextMessage is not None:
                print >> sys.stderr, nextMessage
            lastMessage = nextMessage
        cause = cause.getCause()


def toHex32(rVal):
    """ Converts an integer value to a hex string
    Returns a string of the form 0xhhhhhhhh which is the hex
    value of rVal
    Parameters:
        rVal - the integer value to be converted
    """
    return "0x%s" % ("00000000%X" % (rVal & 0xffffffff))[-8:]


def toHex64(rVal):
    """ Converts an long value to a hex string
    Returns a string of the form 0xhhhhhhhhhhhhhhhh which is the hex
    value of rVal
    Parameters:
        rVal - the long value to be converted
    """
    return "0x%s" % ("0000000000000000%X" % (rVal & 0xffffffffffffffff))[-16:]


def toHex(rVal, bitLength):
    """ Converts an value to a hex string
    Returns a string of the form 0xhhhh which is the hex value of rVal using
    as many nibble values required for the bitLength
    Parameters:
        rVal - the long value to be converted
    """
    if bitLength == 64:
        return toHex64(rVal)
    if bitLength == 32:
        return toHex32(rVal)
    nibbleLength = int((bitLength + 3) / 4)
    mask = int(math.floor(math.ldexp(1, 4 * nibbleLength) - 1))
    lStr = ("%s%X" % ("0" * nibbleLength, rVal & mask))
    hStr = lStr[-nibbleLength:]
    return "0x%s" % (hStr)


multipliers = {
    "KIB": 1024,
    "MIB": 1024 * 1024,
    "GIB": 1024 * 1024 * 1024,
    "K": 1024,
    "M": 1024 * 1024,
    "G": 1024 * 1024 * 1024
}


def formTraceSizeString(byteCount):
    """ Converts a byte count value into a size string suitable for display
    Parameters:
        byteCount the trace size value
    Returns:
        a string of the form <size> <"bytes" | "KiB" | "MiB" | "GiB">
    """
    if byteCount < 1024:
        units = "bytes"
        divisor = 1.0
    elif byteCount < 1024 * 1024:
        units = "KiB"
        divisor = 1024.0
    elif byteCount < 1024 * 1024 * 1024:
        units = "MiB"
        divisor = 1024.0 * 1024.0
    else:
        units = "GiB"
        divisor = 1024.0 * 1024.0 * 1024.0
    return "%.2f %s" % (byteCount / divisor, units)


def decodeSizedString(sizedString, maxSize):
    """ Decodes a string representing a data size.
        The string can contain a number and a units specifier.
        e.g. 2048, 1MiB, 2.5GiB, 1K, 1KiB, 25%
        If the size is given as a %, this represents a % of maxSize
    Params:
        sizedString the data size string
        maxSize the upper limit on the size value
    Returns:
        a number of bytes in the range 0..maxSize
    """
    sizedString = sizedString.strip()
    # Locate last digit in the string
    lastDigitPos = len(sizedString)-1
    while (lastDigitPos >= 0) and not sizedString[lastDigitPos].isdigit():
        lastDigitPos = lastDigitPos - 1
    multiplier = 1
    isPC = False
    if lastDigitPos >= 0:
        unitsStr = sizedString[lastDigitPos+1:].upper()
        if unitsStr == "%":
            isPC = True
        elif unitsStr in multipliers:
            multiplier = multipliers[unitsStr]
    numStr = sizedString[:lastDigitPos+1]
    try:
        numVal = float(numStr) * multiplier
        if isPC:
            numVal = maxSize * numVal / 100
    except ValueError:
        raise ProgramException(
            "Invalid number within data size string: '%s'" % sizedString)
    return min(long(numVal), maxSize)


def decodeTraceSizeString(tString, maxSize):
    """ Decodes a string representing an amount of trace data.
        The string can contain a number and a units specifier.
        e.g. 2048, 1MiB, 2.5GiB, 1K, 1KiB, 25%
    Params:
        tString the trace size string
        maxSize the amount of trace data actually in the trace device
    Returns:
        a number of bytes in the range 0..maxSize
    """
    numVal = decodeSizedString(tString, maxSize)
    if numVal < 0:
        raise ProgramException("-ve size does not make sense '%s'" % tString)
    return numVal


def decodeTracePositionString(tString, maxSize):
    """ Decodes a string representing a position within trace capture device.
        The string can contain a number and a units specifier. If the number
        is -ve it is taken to represent an offset back from the end of the
        trace buffer.
        e.g. 2048, 1MiB, 2.5GiB, 1K, 1KiB, 25%, -2%, -15MB
    Params:
        tString the trace position string
        maxSize the amount of trace data actually in the trace device
    Returns:
        a trace position in the range 0..maxSize-1
    """
    numVal = decodeSizedString(tString, maxSize)
    if numVal < 0:
        numVal = maxSize + numVal
    return min(numVal, maxSize-1)


def formRateString(dataSize, time):
    """Forms a transfer rate string for a transfer which processed
       dataSize values within time seconds
    Params:
        dataSize the byte count of the data processed
        time the time in seconds
    Returns:
        a rate string such as "2.65 MiB/s"
    """
    rateString = ""
    rate = dataSize / time
    if rate < 1024.0:
        rateString = "%.2f bytes/s" % rate
    elif rate/1024.0 < 1024.0:
        rateString = "%.2f KiB/s" % (rate / 1024.0)
    elif rate/(1024.0*1024.0) < 1024.0:
        rateString = "%.2f MiB/s" % (rate / (1024.0*1024.0))
    else:
        rateString = "%.2f GiB/s" % (rate / (1024.0*1024.0*1024.0))
    return rateString


def formTimeStringFromNanoSeconds(nsTime):
    """Forms a time string from a ns time count
    Params:
        nsTime the number of ns of elapsed time
    Returns:
        a time string value with appropriate time units appended
        e.g. "4.32 ms"
    """
    timeString = ""
    if nsTime < 1000:
        timeString = "%d ns" % nsTime
    elif nsTime < 1000*1000:
        timeString = "%.2f us" % (nsTime / 1000.0)
    elif nsTime < 1000*1000*1000:
        timeString = "%.2f ms" % (nsTime / (1000.0*1000.0))
    else:
        timeString = "%.2f s" % (nsTime / (1000.0*1000.0*1000.0))
    return timeString


def getDTSLDeviceByName(dtslConfiguration, deviceName):
    """ Returns a device object referenced by name
    Parameters:
        dtslConfiguration - the DTSL configuration object
        deviceName - the device name e.e. "Cortex-A9_0" or "TPIU"
    NOTE: the device object we return implements the IDevice interface
    """
    assert isinstance(dtslConfiguration, DTSLv1)
    deviceList = dtslConfiguration.getDevices()
    for device in deviceList:
        assert isinstance(device, IDevice)
        if deviceName == device.getName():
            return device
    return None


def showDTSLDevices(dtslConfiguration):
    """ Prints a list of DTSL devices contained in the configuration
    Parameters:
        dtslConfiguration - the DTSL configuration object
    """
    assert isinstance(dtslConfiguration, DTSLv1)
    deviceList = dtslConfiguration.getDevices()
    print "DTSL Device list (device count = %d):" % (len(deviceList))
    print "-----------+------------------"
    print "    ID     | DTSL Device Name"
    print "-----------+------------------"
    for device in deviceList:
        assert isinstance(device, IDevice)
        print "%10d | %s" % (device.getID(), device.getName())


def getDTSLTraceCaptureDeviceNames(dtslConfiguration):
    """ Returns an array of DTSL trace capture device names
    Parameters:
        dtslConfiguration - the DTSL configuration object
    Returns:
        an array of capture device names or None if there are none
    """
    assert isinstance(dtslConfiguration, DTSLv1)
    traceCaptureDevices = dtslConfiguration.getTraceCaptureInterfaces()
    if traceCaptureDevices is None:
        return None
    return traceCaptureDevices.keySet().toArray()


def getDTSLTraceCaptureDevice(
    dtslConfiguration,
    traceCaptureDeviceName
):
    """Returns a TraceCaptureDevice object with a certain name from
       a DTSL configuration
    Params:
        dtslConfiguration the DTSLConfiguration object
        traceCaptureDeviceName the name of the trace capture device
    Returns:
        The TraceCaptureDevice object of the requested name or null
        if the object was not found
    """
    traceCaptureDevices = dtslConfiguration.getTraceCaptureInterfaces()
    if traceCaptureDevices is None or traceCaptureDevices.isEmpty():
        traceCaptureDevice = None
    else:
        traceCaptureDevice = traceCaptureDevices.get(traceCaptureDeviceName)
    return traceCaptureDevice


def findDTSLTraceSourceForATBID(
    traceCaptureDevice,
    atbid
):
    """Returns an ITraceSource object with a certain ATB ID from
       a TraceCaptureDevice
    Params:
        traceCaptureDevice the DTSL TraceCaptureDevice
        atbid the ATB ID of the trace source
    Returns:
        The ITraceSource object which generates the requested atbid, or null
        if the object was not found
    """
    traceSource = traceCaptureDevice.findTraceSourceByID(atbid)
    return traceSource


def showDTSLTraceCaptureDevices(dtslConfiguration):
    """ Prints a list of DTSL trace capture devices contained in the
        configuration
    Parameters:
        dtslConfiguration - the DTSL configuration object
    """
    assert isinstance(dtslConfiguration, DTSLv1)
    print "DTSL Trace Capture Devices:"
    print "+------------------+-------------------------+"
    print "| DTSL Device Name |    Contains / Size      |"
    print "+------------------+-------------------------+"
    traceCaptureDevices = dtslConfiguration.getTraceCaptureInterfaces()
    if traceCaptureDevices is None or traceCaptureDevices.isEmpty():
        print("DTSL Configuration %s has no trace capture devices" %
              dtslConfiguration.getName())
    else:
        for traceCaptureName in traceCaptureDevices.keySet().toArray():
            traceCaptureDevice = traceCaptureDevices.get(traceCaptureName)
            if traceCaptureDevice.isActive():
                if traceCaptureDevice.canQueryCaptureSizeWhenRunning():
                    contentsStr = formTraceSizeString(
                        traceCaptureDevice.getCaptureSize())
                else:
                    contentsStr = "?"
            else:
                captureSize = traceCaptureDevice.getCaptureSize()
                contentsStr = formTraceSizeString(captureSize)
            contentsStr += (" / " + formTraceSizeString(
                traceCaptureDevice.getMaxCaptureSize()))
            print "| %16s | %23s |" % (
                traceCaptureDevice.getName().center(16),
                contentsStr.center(23)
            )
        print "+------------------+-------------------------+"


def showDTSLTraceSourcesForCaptureDevice(
    dtslConfiguration,
    traceCaptureDeviceName
):
    """ Prints a list of DTSL trace sources that are associated with a
        trace capture device
    Parameters:
        dtslConfiguration - the DTSL configuration object
        traceCaptureDeviceName - the name of the trace capture device
    """
    assert isinstance(dtslConfiguration, DTSLv1)
    print "DTSL Trace Sources for %s:" % traceCaptureDeviceName
    print "+-------------------+-------------+--------------------------------"
    print "| Trace Source Name |  Stream ID  | Encoding "
    print "+-------------------+-------------+--------------------------------"
    traceCaptureDevices = dtslConfiguration.getTraceCaptureInterfaces()
    if traceCaptureDevices is None or traceCaptureDevices.isEmpty():
        print("DTSL Configuration %s has no trace capture devices" %
              dtslConfiguration.getName())
    else:
        traceCaptureDevice = traceCaptureDevices.get(traceCaptureDeviceName)
        if traceCaptureDevice is None:
            print("DTSL Configuration %s has no trace capture device names %s"
                  % traceCaptureDeviceName)
        else:
            traceSources = traceCaptureDevice.getTraceSources()
            if traceSources is None or traceSources.isEmpty():
                print("Trace capture device %s has no configured trace sources"
                      % traceCaptureDeviceName)
            else:
                for traceSource in traceSources:
                    print "| %17s | %11s | %s" % (
                        traceSource.getName().center(17),
                        str(traceSource.getStreamID()).center(11),
                        traceSource.getEncodingDisplayName())
    print "+-------------------+-------------+--------------------------------"


def showDTSLException(e):
    """ Prints out a DTSLException
    The exception chain is traversed and non-duplicated
    information from all levels is displayed
    Parameters:
        e - the DTSLException object
    """
    print >> sys.stderr, "Caught DTSL exception:"
    cause = e
    lastMessage = ""
    while cause is not None:
        nextMessage = cause.getMessage()
        if nextMessage != lastMessage:
            if nextMessage is not None:
                print >> sys.stderr, nextMessage
            lastMessage = nextMessage
        cause = cause.getCause()


def showRDDIException(e):
    """ Prints out a RDDIException
    The exception chain is traversed and non-duplicated
    information from all levels is displayed
    Parameters:
        e - the RDDIException object
    """
    print >> sys.stderr, "Caught RDDI exception:"
    cause = e
    lastMessage = ""
    while cause is not None:
        nextMessage = cause.getMessage()
        if nextMessage != lastMessage:
            if nextMessage is not None:
                print >> sys.stderr, nextMessage
            lastMessage = nextMessage
        cause = cause.getCause()


def showJythonException(e):
    print >> sys.stderr, "Caught Jython exception:"
    print >> sys.stderr, e.toString()


def showRuntimeError(e):
    """ Prints out a RuntimeException
    Parameters:
        e - the RuntimeException object
    """
    print >> sys.stderr, e


def createDSTREAMDTSL(dstreamAddress):
    """Creates a DTSL connection from a DSTREAM connection address.
    Params:
        dstreamAddress the connection address for a DSTREAM box. This is a
                       string e.g. 'TCP:hostname' or 'USB' or 'USB:012322'
    Returns:
        a DTSLConnection instance. Note that the instance has _not_ been
        connected.
    """
    myPath = os.path.abspath(sys.argv[0])
    params = ConnectionParameters()
    params.rddiConfigFile = os.path.join(
        os.path.dirname(myPath), 'junodaps.rvc')
    params.address = dstreamAddress
    dtslConnection = ConnectionManager.openConnection(params)
    return dtslConnection


def connectToDTSL(dtslConfigData):
    """ Makes our connection to DTSL and returns the connection object """
    params = dtslConfigData.getDTSLConnectionParameters()
    conn = ConnectionManager.openConnection(params)
    conn.connect()
    return conn


def connectToDevice(device):
    """ Makes a connection to a core (or other device)
    Parameters:
        core - the DTSL device to connect to
    """
    assert isinstance(device, ConnectableDevice)
    deviceInfo = StringBuilder(256)
    device.openConn(None, None, deviceInfo)
    deviceName = StringBuilder(256)
    deviceDetails = StringBuilder(256)
    device.getDeviceDetails(deviceName, deviceDetails)


def cvt32x2to64(values32, offset=0):
    return (values32[offset + 1] << 32) | (values32[offset] & 0xFFFFFFFF)


def cvt32x4to128(values32, offset=0):
    return (
        (values32[offset + 3] << 96) |
        ((values32[offset + 2] << 64) & 0x00000000FFFFFFFF0000000000000000) |
        ((values32[offset + 1] << 32) & 0x0000000000000000FFFFFFFF00000000) |
        (values32[offset] & 0x000000000000000000000000FFFFFFFF))


def readReg64(device, regID):
    assert isinstance(device, IDevice)
    regIDs = array([int(regID), int(regID + 1)], 'i')
    values32 = zeros(2, 'i')
    device.regReadList(regIDs, values32)
    return cvt32x2to64(values32)


def writeReg64(device, regID, value64):
    assert isinstance(device, IDevice)
    # a 64 bit reg write takes 2 x 32 bit reg writes
    regIDs = array([regID, regID + 1], 'i')
    values32 = array([Long(value64 & 0xFFFFFFFF).intValue(),
                      Long(value64 >> 32).intValue()], 'i')
    device.regWriteList(regIDs, values32)
