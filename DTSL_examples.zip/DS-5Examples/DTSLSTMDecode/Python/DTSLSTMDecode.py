#! jython
'''
DTSL Script to analyse a trace buffer full of TPIU content (or rather
CoreSight Trace Formatter content) and extract and decode the STM
data contained within. This script expects to be run from within
a DS-5 debug session.
'''

from org.python.core import PyException
from com.arm.debug.dtsl import ConnectionManager
from com.arm.debug.dtsl import DTSLException
from com.arm.debug.dtsl.decoders.stm.stmobjects import STMSourceMatcherRange
from com.arm.debug.dtsl.decoders.stm.stpprotocol import STPNibbleQueue
from com.arm.debug.dtsl.decoders.stm import STMObjectGenerator
from com.arm.debug.dtsl.decoders.stm.STMObjectGenerator.ThrowModel import GENERATE_STMDECODEERROR_OBJECTS
from com.arm.rddi import RDDIException
from DTSLHelper import showDTSLException
from DTSLHelper import showRDDIException
from DTSLHelper import showJythonException
from DTSLHelper import showDTSLTraceCaptureDevices
from DTSLHelper import showDTSLTraceSourcesForCaptureDevice
from DTSLHelper import getDTSLTraceCaptureDevice
from DTSLHelper import formRateString
from DTSLHelper import formTraceSizeString
from DTSLHelper import ProgramException
from DTSLHelper import showProgramException
from DTSLHelper import decodeTraceSizeString
from DTSLHelper import decodeTracePositionString
from options import ProgramOptions
from progress import Progress
from java.lang.System import nanoTime
from java.lang.System import out as javaStdOut
from java.io import PrintStream
from java.io import File
from jarray import zeros
from STMTracePrinter import STMTracePrinter
from STMTraceContentLogger import STMTraceContentLogger
from sys import stdout
from sys import stderr
import os
import sys

# To enable us to use the project Java code we must add the path containing
# the .class file(s). Then we can import them. The path is modified this way
# so that it works when run either stand alone or from within DS-5.
myPath = os.path.abspath(sys.argv[0])
sys.path.append(os.path.join(os.path.dirname(myPath), '../bin'))
from JSTMTrace import JSTMTracePrinter
from JSTMTrace import JSTMTraceContentLogger

VERSION = "1.0"


def detectDS5():
    """Detects if we have been launched from within DS-5
    Returns:
        True if launched from DS-5
        False if not i.e. run outside of a DS-5 debug session
    """
    fromDS5 = False
    try:
        from arm_ds.debugger_v1 import Debugger
        fromDS5 = True
    except ImportError:
        fromDS5 = False
    return fromDS5


def getDS5DTSL():
    """For an existing DS-5 connection, we return the DTSL connection
    Returns:
        the DTSLConnection instance
    """
    try:
        from arm_ds.debugger_v1 import Debugger
        debugger = Debugger()
        # Ask the debugger to identify the DTSL instance it is using
        dtslConfigurationKey = debugger.getConnectionConfigurationKey()
        # Get hold of the same DTSL instance
        dtslConnection = ConnectionManager.openConnection(
            dtslConfigurationKey)
    except ImportError:
        dtslConnection = None
    return dtslConnection


def createSTMFilter(options):
    """ Creates the STM source filter
    Params:
        options the program options which (may) contain user
        instructions on what to filter
    """
    # Right now we just create a filter which matches all
    # master IDs and channel IDs. Other filters you might
    # find of interest are STMSourceMatcherSet and
    # STMSourceMatcherSingle. You can also create your
    # own as long as it implements the ISTMSourceMatcher
    # interface.
    return STMSourceMatcherRange(0, 128, 0, 65535)
    # return STMSourceMatcherRange(
    #            masterIDLower, masterIDUpper,
    #            channelIDLower, channelIDUpper)


def generateSTMReport(
    captureDevice,
    traceReader,
    offset,
    maxSize,
    stmFilter,
    stmDataConsumer,
    progress
):
    """ Generates an STM report by reading STM trace data (with optional
        filter) and sending it to a consumer (which generates the report)
    Params:
        captureDevice - the DTSL TraceCapture object we use to access
                        the trace data
        traceReader - the object we use to read trace data
        offset - the offset from the start of the trace buffer that we
                 should start reading trace data. If this is 0 or None
                 we start at the beginning.
        maxSize - the max amount of trace data we should decode. If this
                  is None, we decode all of the buffer subject to offset
        stmFilter - the filter to select the STM master IDs and channel IDs
                    to restrict the decode to
        stmDataConsumer - the object which should receive the STMObject
                          stream
        progress - the object we use to report progress
    """
    captureSize = captureDevice.getCaptureSize()
    MAX_READ_SIZE = captureDevice.getRecommendedReadSize()
    # STM data is a nibble based protocol, so we use a utility class
    # to manage the nibble data set
    stpNibbleQueue = STPNibbleQueue()
    # Create the STM object generator which consumes the nibble data
    stmObjectGenerator = STMObjectGenerator(stpNibbleQueue, stmFilter)
    nextPos = zeros(1, 'l')
    if offset is not None:
        tPos = decodeTracePositionString(offset, captureSize)
        nextPos[0] = tPos
        processSize = max(0, captureSize - tPos)
    else:
        nextPos[0] = 0
        processSize = captureSize
    if maxSize is not None:
        processSize = min(processSize,
                          decodeTraceSizeString(maxSize, captureSize))
    traceDataProcessed = 0
    progress.setCurrentOperation("Processing trace data")
    progress.setRange(0, processSize)
    startTime = nanoTime()
    rawData = zeros(MAX_READ_SIZE, 'b')
    while processSize > 0:
        readSize = min(processSize, MAX_READ_SIZE)
        #  print "@ nextpos=%d size=%d" % (nextPos[0], readSize)
        readStartPos = nextPos[0]
        sizeRead = traceReader.read(
            readStartPos, readSize, rawData, nextPos)
        stpNibbleQueue.appendData(rawData, 2 * sizeRead)
        stmObjectGenerator.generate(
            stmDataConsumer,
            GENERATE_STMDECODEERROR_OBJECTS)
        sourceByteCount = nextPos[0] - readStartPos
        processSize -= sourceByteCount
        traceDataProcessed += sourceByteCount
        progress.setProgress(traceDataProcessed)
    # Lets see how long that all took
    timeDelta = nanoTime() - startTime
    if timeDelta > 0:
        time = timeDelta*1.0E-9
        progress.setCompleted(
            "Processing complete, took %.2fs at %s" % (
                time, formRateString(traceDataProcessed, time)))
    else:
        progress.setCompleted("Processing complete")
    print(
        "Read %s from trace buffer" %
        formTraceSizeString(traceDataProcessed))
    stmDataConsumer.flush()


def doSTMDecode(
    captureDevice,
    stmDeviceName,
    stmFilter,
    offset,
    maxSize,
    outputFile,
    contentsOnly,
    progress
):
    """ Generates a report of ATB IDs present in the trace buffer
        along with a map of where the data resides in the trace buffer
    Params:
        captureDevice - the DTSL TraceCapture object we use to access
                        the trace data
        stmDeviceName - the DTSL name for the STM device
        stmFilter - the filter to select the STM master IDs and channel IDs
                    to restrict the decode to
        offset - the offset from the start of the trace buffer that we
                 should start reading trace data. If this is 0 or None
                 we start at the beginning.
        maxSize - the max amount of trace data we should decode. If this
                  is None, we decode all of the buffer subject to offset
        outputFile - the file name to write the output to. If this is None
                     the output is sent to the console
        contentsOnly - True to only generate a report of the Master IDs and
                       channel IDs found in the trace
        progress - the object we use to report progress
    """
    captureSize = captureDevice.getCaptureSize()
    if captureSize == 0:
        print "Trace capture device %s is empty" % captureDevice.getName()
        return
    stmDevice = captureDevice.findTraceSourceByName(stmDeviceName)
    if stmDevice is None:
        print(
            "Could not find STM (%s) device within %s trace sources" %
            (stmDeviceName, captureDevice.getName()))
        return
    # Create the destination for the generated STM objects
    if outputFile is not None:
        # Use the Java analyser - its faster
        outputDest = PrintStream(File(outputFile))
        if contentsOnly:
            stmDataConsumer = JSTMTraceContentLogger(outputDest)
        else:
            stmDataConsumer = JSTMTracePrinter(outputDest)
    else:
        # Use the Jython analyser - it can send to command view
        outputDest = sys.stdout
        if contentsOnly:
            stmDataConsumer = STMTraceContentLogger(outputDest)
        else:
            stmDataConsumer = STMTracePrinter(outputDest)
    # Get hold of a trace reader instance for the STM data
    traceReader = captureDevice.borrowSourceReader(
        "STM Trace Reader", stmDevice.getStreamID())
    try:
        generateSTMReport(
            captureDevice,
            traceReader,
            offset,
            maxSize,
            stmFilter,
            stmDataConsumer,
            progress)
    finally:
        # We must always return the reader to the capture device
        captureDevice.returnSourceReader(traceReader)
        if outputDest != stdout:
            outputDest.close()


if __name__ == "__main__":
    # pydevd.settrace(stdoutToServer=True, stderrToServer=True)
    try:
        # Check we have been run from within a DS-5 debug session
        runFromDS5 = detectDS5()
        if not runFromDS5:
            raise ProgramException(
                "Can only be run from within DS-5 debug session")
        # Process any command line options
        options = ProgramOptions("DTSLSTMDecode.py", VERSION)
        if not options.processOptions():
            raise ProgramException(
                "Failed to process options")
        # Get hold of the DTSL instance used by the debugger
        dtsl = getDS5DTSL()
        # Extract the configuration object (probably a DTSLv1 class created
        # by the DTSL configuration script)
        dtslConfiguration = dtsl.getConfiguration()
        if options.getListOnly():
            showDTSLTraceCaptureDevices(dtslConfiguration)
            showDTSLTraceSourcesForCaptureDevice(
                dtslConfiguration, options.getCaptureDevice())
        else:
            captureDevice = getDTSLTraceCaptureDevice(
                dtslConfiguration, options.getCaptureDevice())
            if captureDevice is not None:
                if captureDevice.isActive():
                    captureDevice.stop()
                progress = Progress(options.getQuiet())
                progress.setOutputSupportsCR(not runFromDS5)
                stmFilter = createSTMFilter(options)
                doSTMDecode(
                    captureDevice,
                    options.getSTMDevice(),
                    stmFilter,
                    options.getOffset(),
                    options.getSize(),
                    options.getOutputFile(),
                    options.getContentsOnly(),
                    progress)
    except RDDIException, eRDDI:
        showRDDIException(eRDDI)
    except DTSLException, eDTSL:
        showDTSLException(eDTSL)
    except ProgramException, eProgram:
        showProgramException(eProgram)
    except PyException, e:
        showJythonException(e)
    except RuntimeError, e:
        print >> stderr, e
