from com.arm.debug.dtsl.decoders.stm.stmobjects import ISTMObjectReceiver
from com.arm.debug.dtsl.decoders.stm.stmobjects import STMData


class STMTraceContentLogger(ISTMObjectReceiver):
    """ Class which acts as a destination for STM objects and
        just records which MasterIDs/ChannelIDs it sees
    """
    def __init__(self, dest):
        """ Constructor
        Params:
            dest the file object we print our output to
        """
        self.dest = dest
        # stmSources is a dictionary of Master IDs indexing to
        # a set of observed Channel IDs
        # e.g. stmSources[128]=set([0,4,100,234])
        self.stmSources = {}

    def write(self, stmObject):
        """ Receives a decoded STM object
        Params:
            stmObject the STM decoded object
        Returns:
            True if we wish to receive more STMObjects,
            False if we wish decoding to stop
        """
        # Only STMData objects have a Master ID and Channel ID source
        # associated with them
        if isinstance(stmObject, STMData):
            source = stmObject.getSource()
            if source.masterID in self.stmSources:
                # Already seen this master so just add channel ID
                self.stmSources[source.masterID].add(source.channelID)
            else:
                # New master, so create and initialise the set()
                self.stmSources[source.masterID] = set([source.channelID])
        return True

    def flush(self):
        """ Used as a trigger to output information on which
            Master IDs and Channel IDs we have seen
        """
        for masterID in self.stmSources.keys():
            print >> self.dest, "MasterID: %d" % masterID
            for channelID in self.stmSources[masterID]:
                print >> self.dest, "   ChannelID: %d" % channelID
