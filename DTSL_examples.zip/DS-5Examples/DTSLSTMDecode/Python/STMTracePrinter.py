from com.arm.debug.dtsl.decoders.stm.stmobjects import ISTMObjectReceiver


class STMTracePrinter(ISTMObjectReceiver):
    """ Class which acts as a destination for STM objects and
        just prints out a string representation of the object
    """
    def __init__(self, dest):
        """ Constructor
        Params:
            dest the file object we print our output to
        """
        self.dest = dest

    def write(self, stmObject):
        """ Receives a decoded STM object
        Params:
            stmObject the STM decoded object
        Returns:
            True if we wish to receive more STMObjects,
            False if we wish decoding to stop
        """
        print >> self.dest, stmObject.toString()
        return True

    def flush(self):
        """ Requests us to make sure all our output has been
            written to self.dest
        """
        self.dest.flush()
