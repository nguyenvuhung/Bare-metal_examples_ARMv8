"""
Module to process command line options
"""
from optparse import OptionParser


class ProgramOptions(object):
    """
    Parses command line options and provides configuration data to the
    main program
    """
    BAD_OPTIONS = -1

    def __init__(self, programName, version):
        """
        Constructor
        Params:
            programName - the name of the program we show when asked for help
            version - string form of the program version
        """
        self.programName = programName
        self.version = version
        self.captureDevice = None
        self.quiet = None
        self.captureDevice = None
        self.stmDevice = None
        self.offset = None
        self.size = None
        self.outputFile = None
        self.contentsOnly = False
        self.listOnly = False

    def processOptions(self):
        """ Processes command line option """
        # Construct option specifications
        parser = OptionParser(
            usage=("usage: %s [options] (use --help to see full "
                   "option list)") % self.programName,
            version="%s %s" % (self.programName, self.version),
            description="STM trace decoder"
            )
        parser.add_option(
            "-d", "--capture-device",
            action="store", type="string",
            dest="captureDevice", default="DSTREAM",
            help="the trace capture device name, default=%default"
            )
        parser.add_option(
            "-s", "--stm-device",
            action="store", type="string",
            dest="stmDevice", default="STM",
            help="the DTSL STM device name, default=%default"
            )
        parser.add_option(
            "-z", "--size",
            action="store", type="string",
            dest="size",
            help="size/length of trace buffer to decode. "
                 "e.g. 65536, 64K, 2.4M"
            )
        parser.add_option(
            "-o", "--offset",
            action="store", type="string",
            dest="offset",
            help="start offset into trace buffer to start decoding from. "
                 "e.g. 1000, -1024, 3.5M, -27K, 10%, -15%"
            )
        parser.add_option(
            "-f", "--output-file",
            action="store", type="string",
            dest="outputFile",
            help="the file to dump STM decode to"
            )
        parser.add_option(
            "-q", "--quiet",
            action="store_true",
            dest="quiet",
            help="turns off the progress display"
            )
        parser.add_option(
            "-c", "--contents",
            action="store_true",
            dest="contentsOnly",
            help="displays the list of master IDs and channel IDs in the "
                 "trace"
            )
        parser.add_option(
            "-l", "--list-only",
            action="store_true",
            dest="listOnly",
            help="displays supported trace capture devices and trace sources"
            )
        # Process all supplied options
        options = parser.parse_args()[0]
        # Extract any supplied options into our local values
        # Extract any supplied options into our local values
        if options.captureDevice is not None:
            self.captureDevice = options.captureDevice
        if options.quiet is not None:
            self.quiet = options.quiet
        if options.offset is not None:
            self.offset = options.offset
        if options.size is not None:
            self.size = options.size
        if options.stmDevice is not None:
            self.stmDevice = options.stmDevice
        if options.outputFile is not None:
            self.outputFile = options.outputFile
        if options.contentsOnly is not None:
            self.contentsOnly = options.contentsOnly
        if options.listOnly is not None:
            self.listOnly = options.listOnly
        return True

    def getCaptureDevice(self):
        return self.captureDevice

    def getQuiet(self):
        return self.quiet

    def getSTMDevice(self):
        return self.stmDevice

    def getOffset(self):
        return self.offset

    def getSize(self):
        return self.size

    def getOutputFile(self):
        return self.outputFile

    def getContentsOnly(self):
        return self.contentsOnly

    def getListOnly(self):
        return self.listOnly
