DTSL Jython Example
-------------------

This is an example of how one can write your own STM processing scripts.

As delivered this script (DTSLSTMDecode.py) expects to be run from within a DS-5
debug session. The script can be used to:
   * Display the available trace capture devices (e.g. DSTREAM....)
   * Display the configured trace sources (e.g. STMs, ETMs ....)
   * Decode the STM data streams and show which Master IDs and Channel IDs are
     present in the data
   * Decode the STM data stream to show the data content and to write the output
     to a file or the DS-5 command view (*)

(*) Note that writing large data sets to the command view is not a good idea.
    The view tries to queue up data and so the script can finish far in advance
    of the data being displayed. This makes it hard to subsequently interact 
    with the command view until all the data has been shown.

Running the example
-------------------

The script only supports being run from within a DS-5 debug session. This can be
done using the DS-5 Commands view and issuing a command such as, for example:

source "DTSLSTMDecode\Python\DTSLSTMDecode.py" -s STM0 -c -f "c:\logs\stm.log"

Alternatively, you can locate the DTSLSTMDecode.py file in the Eclipse Project
Explorer view and click and drag it into the Commands view back drop (not the
Command: line itself) and then append the arguments.

Usage: DTSLSTMDecode.py [options] (use --help to see full option list)

STM trace decoder

Options:
  --version             show program's version number and exit
  -h, --help            show this help message and exit
  -d CAPTUREDEVICE, --capture-device=CAPTUREDEVICE
                        the trace capture device name, default=DSTREAM
  -s STMDEVICE, --stm-device=STMDEVICE
                        the DTSL STM device name, default=STM
  -z SIZE, --size=SIZE  size/length of trace buffer to decode. e.g. 65536,
                        64K, 2.4M
  -o OFFSET, --offset=OFFSET
                        start offset into trace buffer to start decoding from.
                        e.g. 1000, -1024, 3.5M, -27K, 10%, -15%
  -f OUTPUTFILE, --output-file=OUTPUTFILE
                        the file to dump STM decode to
  -q, --quiet           turns off the progress display
  -c, --contents        displays the list of master IDs and channel IDs in the
                        trace
  -l, --list-only       displays supported trace capture devices and trace
                        sources

Note that the default capture device is "DSTREAM" and the default STM device
     name is "STM". 

Note that the -z and -o options take size and offset values which can both be
     specified as a number of bytes with option units or as a % of data in the
     trace buffer. The units strings supported are:
        "KiB": 1024, "MiB": 1024 * 1024, "GiB": 1024 * 1024 * 1024,
        "K": 1024, "M": 1024 * 1024, "G": 1024 * 1024 * 1024

Examples
--------

1. Displaying the available trace capture devices and the names of the trace
   sources for the current platform:

source "DTSLSTMDecode\Python\DTSLSTMDecode.py" -l

DTSL Trace Capture Devices:
+------------------+-------------------------+
| DTSL Device Name |    Contains / Size      |
+------------------+-------------------------+
|       ETF0       | 0.00 bytes / 0.00 bytes |
|       ETR0       | 0.00 bytes / 0.00 bytes |
|     DSTREAM      |  968.45 MiB / 4.00 GiB  |
+------------------+-------------------------+
DTSL Trace Sources for DSTREAM:
+-------------------+-------------+--------------------------------
| Trace Source Name |  Stream ID  | Encoding 
+-------------------+-------------+--------------------------------
|      PTMs[0]      |      16     | Program Flow Trace
|      PTMs[1]      |      17     | Program Flow Trace
|      PTMs[2]      |      18     | Program Flow Trace
|      PTMs[3]      |      19     | Program Flow Trace
|      ETMs[0]      |      32     | Embedded Trace Macrocell
|      ETMs[1]      |      33     | Embedded Trace Macrocell
|      ETMs[2]      |      34     | Embedded Trace Macrocell
|        STM0       |      1      | System Trace Macrocell
+-------------------+-------------+--------------------------------


2. Displaying the master IDs and channel IDs found in the first 100MiB of trace
   data for trace source STM0

source "DTSLSTMDecode\Python\DTSLSTMDecode.py" -s STM0 -c -z 100MiB

100% [++++++++++++++++++++++++++++++++++++++++] Uploading trace data
Processing complete, took 15.69s at 6.38 MiB/s
Read 100.00 MiB from trace buffer
MasterID: 0
   ChannelID: 0
MasterID: 128
   ChannelID: 0
   ChannelID: 144
   
3. Displaying the decoded STM data for the first 100K of trace data

source "DTSLSTMDecode\Python\DTSLSTMDecode.py" -s STM0 -z 100KiB

[snip lots of trace output]
[M:128,C:0]D : D = 0x0040100000000000
[M:128,C:0]D : TS =2.0873748941077864E8s, D = 0x0040100000000000
100% [++++++++++++++++++++++++++++++++++++++++] Uploading trace data

Processing complete, took 0.28s at 358.44 KiB/s
Read 100.00 KiB from trace buffer

3. Displaying the decoded STM data for 1MiB of trace data starting at offset
   14MiB and writing the decoded trace data to file c:\logs\stm.log

source "DTSLSTMDecode\Python\DTSLSTMDecode.py" -s STM0 -z 1MiB -o 14MiB -f "c:\logs\stm.log"

100% [++++++++++++++++++++++++++++++++++++++++] Uploading trace data

Processing complete, took 0.83s at 1.20 MiB/s
Read 1.00 MiB from trace buffer

NOTE: The STM decoder needs to locate a STM sync record before it can start
      decoding data. When using the -z and -o options it is possible that you
      request the processing of a trace area which does not contain a sync
      record and so the decode may not output any data.
