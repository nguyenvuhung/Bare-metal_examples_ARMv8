from java.lang import Math
from com.arm.debug.dtsl.impl import DataSink
from com.arm.debug.dtsl.impl import Deformatter
from com.arm.debug.dtsl.impl import SyncStripper
from com.arm.debug.dtsl.impl import DSTREAMBlockStripper
from com.arm.debug.dtsl.components import ConnectableTraceCaptureBase
from com.arm.debug.dtsl.configurations import ConfigurationBase
import sys
import os
import jarray


class FileBasedTraceCaptureDevice(ConnectableTraceCaptureBase):
    '''
    Base class for a trace capture device which just returns 
    a fixed data set from a file. We override enough of the
    ConnectableTraceCaptureBase methods so that this object appears
    to capture trace, but when trace data is read we just
    return it from the file. The amount of trace data captured
    is just the size of the file.
    '''    
    def __init__(self, configuration, name):
        '''Construction
        Params: configuration - the top level DTSL configuration (the 
                    class you derived from DTSLv1)
                name - the name for the trace capture device
        '''
        ConnectableTraceCaptureBase.__init__(self, configuration, name)
        #print "FileBasedTraceCaptureDevice::__init__"
        self.filename = None
        self.fileOpened = False
        self.hasStarted = False
        self.trcFile =  None
        self.fileSize = 0

    def setTraceFile(self, filename):
        '''Sets the file to use as the trace data source
        Params: filename the file containing the trace data
        '''
        #print "FileBasedTraceCaptureDevice::setTraceFile(%s)" % (filename)
        self.filename = filename

    def connect(self):
        '''We interpret connect() as an opening of the trace data file
        '''
        #print "FileBasedTraceCaptureDevice::connect()"
        if self.filename != None:
            self.trcFile = file(self.filename, 'rb')
            self.fileOpened = True
            self.fileSize = os.path.getsize(self.filename)
    
    def disconnect(self):
        '''We interpret disconnect() as a closing of the trace data file
        '''
        #print "FileBasedTraceCaptureDevice::disconnect()"
        if self.trcFile != None:
            self.trcFile.close()
        self.fileOpened = False
        self.fileSize = 0
        
    def isConnected(self):
        return self.fileOpened

    def startTraceCapture(self):
        self.hasStarted = True

    def stopTraceCapture(self):
        self.hasStarted = False

    def hasPersistentTrace(self):
        return False
        
    def getMaxCaptureSize(self):
        return self.fileSize

    def setMaxCaptureSize(self, size):
        return self.getMaxCaptureSize()

    def getCaptureSize(self):
        return self.fileSize

    def getNewCaptureSize(self):
        return self.getCaptureSize()

    def hasWrapped(self):
        return True
    
    def getSourceData(self, streamID, position, size, data, nextPos):
        '''Reads the trace data from the file 
        Params: streamID - for file formats which contain multiple
                    streams, this identifies the stream for which 
                    data should be returned from
                position - the byte index position to read from
                size - the max size of data (in bytes) we should
                    return
                data - where to write the extracted data
                nextPos - an array into which we set entry [0] to the 
                    next position to read from i.e. the position parameter 
                    value which will return data that immediately follows
                    the last entry written into data
        '''
        return 0


class RawTraceData:
    '''A mixin class to provide the getSourceData method'''
    def getSourceData(self, streamID, position, size, data, nextPos):
        '''Reads the trace data from the file 
        Params: streamID - for file formats which contain multiple
                    streams, this identifies the stream for which 
                    data should be returned from
                position - the byte index position to read from
                size - the max size of data (in bytes) we should
                    return
                data - where to write the extracted data
                nextPos - an array into which we set entry [0] to the 
                    next position to read from i.e. the position parameter 
                    value which will return data that immediately follows
                    the last entry written into data
        '''
        # We assume that size is small enough to allow to read an entire 
        # data block in one operation
        dSize = 0
        if self.trcFile != None:
            self.trcFile.seek(position)
            rawdata = jarray.array(self.trcFile.read(size), 'b')
            nextPos[0] = position+size 
            dest = DataSink(0, 0, size, data)
            dest.push(rawdata)
            dest.flush()
            dSize = dest.size()
        return dSize

        
class ETBTraceData:
    '''A mixin class to provide the getSourceData method'''
    def getSourceData(self, streamID, position, size, data, nextPos):
        '''Reads the ETB trace data from the file 
        Params: streamID - for file formats which contain multiple
                    streams, this identifies the stream for which 
                    data should be returned from
                position - the byte index position to read from
                size - the max size of data (in bytes) we should
                    return
                data - where to write the extracted data
                nextPos - an array into which we set entry [0] to the 
                    next position to read from i.e. the position parameter 
                    value which will return data that immediately follows
                    the last entry written into data
        '''
        #print "ETBFileBasedTraceCaptureDevice::getSourceData()"
        dSize = 0
        if self.trcFile != None:
            # We assume that size is small enough to allow to read an entire 
            # data block in one operation
            self.trcFile.seek(position)
            rawdata = jarray.array(self.trcFile.read(size), 'b')
            nextPos[0] = position+size 
            dest = DataSink(0, 0, size, data)
            # We assume the file contains TPIU frames with sync sequences
            # Se we set up a processing chain as follows:
            # file data -> strip syncs -> de formater -> to our caller
            deformatter = Deformatter(dest, streamID)
            syncStripper = SyncStripper(deformatter)
            syncStripper.forceSync(True)
            syncStripper.push(rawdata)
            syncStripper.flush()
            dSize = dest.size()
        return dSize
       
       
class DSTREAMTraceData:
    '''A mixin class to provide the getSourceData method'''
    def getSourceData(self, streamID, position, size, data, nextPos):
        '''Reads the DSTREAM trace data from the file 
        Params: streamID - for file formats which contain multiple
                    streams, this identifies the stream for which 
                    data should be returned from
                position - the byte index position to read from
                size - the max size of data (in bytes) we should
                    return
                data - where to write the extracted data
                nextPos - an array into which we set entry [0] to the 
                    next position to read from i.e. the position parameter 
                    value which will return data that immediately follows
                    the last entry written into data
        '''
        #print "DSTREAMFileBasedTraceCaptureDevice::getSourceData()"
        dSize = 0
        if self.trcFile != None:
            # limit the request to the buffer limits 
            bytesAvailable = self.getCaptureSize()
            if (bytesAvailable == 0) or (position >= bytesAvailable):
                return 0;
            size = Math.min(size, bytesAvailable-position);
            # Figure out where to start reading from. We  need to read 2 
            # blocks before desired position to ensure we can synchronise to
            # the formatter data and get current source ID at position
            startBlock = position / DSTREAMFileBasedTraceCaptureDevice.BLOCK_SIZE
            actualStartBlock = startBlock - 2
            if (actualStartBlock < 0):
                actualStartBlock = 0
            # calculate the last block needed, reading any partial trailing block
            endBlock = (position+size+DSTREAMFileBasedTraceCaptureDevice.BLOCK_SIZE-1)/DSTREAMFileBasedTraceCaptureDevice.BLOCK_SIZE
            # Allow one extra block (if available) in case the last TPIU packet crosses a DSTREAM block boundary.
            endBlock = endBlock + 1
            blocksAvailable = (self.getCaptureSize()+DSTREAMFileBasedTraceCaptureDevice.BLOCK_SIZE-1)/DSTREAMFileBasedTraceCaptureDevice.BLOCK_SIZE
            if (endBlock > blocksAvailable):
                endBlock = blocksAvailable
            numBlocks = endBlock - actualStartBlock
            # work out buffer index of where requested data is starting from and how much to read
            dataStart = actualStartBlock*DSTREAMFileBasedTraceCaptureDevice.BLOCK_SIZE
            dataSize = numBlocks*DSTREAMFileBasedTraceCaptureDevice.BLOCK_SIZE
            # We assume the file contains DSTREAM data blocks which themselves
            # contain TPIU frames with sync sequences
            # So we set up a processing chain as follows:
            # file data -> DSTREAM block stripper -> strip syncs -> de-formatter -> to our caller
            dest = DataSink(dataStart, position, size, data)
            deformatter = Deformatter(dest, streamID)
            syncStripper = SyncStripper(deformatter)
            blockStripper = DSTREAMBlockStripper(syncStripper, 32)
            # Now read actual data and push through the processing chain
            self.trcFile.seek(dataStart)
            rawdata = jarray.array(self.trcFile.read(dataSize), 'b')
            blockStripper.push(rawdata)
            blockStripper.flush()
            # Must tell caller where to read from next
            nextPos[0] = position+size 
            dSize = dest.size()
        return dSize
    
class RawFileBasedTraceCaptureDevice(RawTraceData, FileBasedTraceCaptureDevice):
    pass
    
class ETBFileBasedTraceCaptureDevice(ETBTraceData, FileBasedTraceCaptureDevice):
    pass

class DSTREAMFileBasedTraceCaptureDevice(DSTREAMTraceData, FileBasedTraceCaptureDevice):
    pass

