from com.arm.debug.dtsl.configurations import DTSLv1
from com.arm.debug.dtsl.configurations import ConfigurationBase
from com.arm.debug.dtsl.components import ConnectableTraceSource
from com.arm.debug.dtsl.interfaces import ITraceSource
from com.arm.debug.dtsl.configurations.options import IntegerOption
from com.arm.debug.dtsl.configurations.options import StringOption
from com.arm.debug.dtsl.configurations.options import EnumOption
from FileBasedTraceCapture import RawFileBasedTraceCaptureDevice
from FileBasedTraceCapture import ETBFileBasedTraceCaptureDevice
from FileBasedTraceCapture import DSTREAMFileBasedTraceCaptureDevice


class FileBasedSTMTraceSource(ConnectableTraceSource):
    """
    A class to represent a trace source. All we have to do is act as a
    carrier for the source name and its ATB ID. The rest of the methods
    we define in here are to override the DTSL methods which would 
    normally try to connect to a real target trace component.
    """
    def __init__(self, configuration, atbID, name):
        ConnectableTraceSource.__init__(self, configuration, 1, atbID, name, ITraceSource.TraceSourceEncodingType.STM, "STM")
        self.isConnected = False
        pass
        
    def connect(self):
        #print "FileBasedTraceSource::connect"
        self.isConnected = True 
        
    def disconnect(self):
        #print "FileBasedTraceSource::disconnect"
        self.isConnected = False
        
    def isConnected(self):
        return self.isConnected


class FILETraceTarget(DTSLv1):
    """
    The class which represents a system which gets the trace data from a file.
    We create the trace components and add them into the component lists
    held by ConfigurationBase. ConfigurationBase also expects to connect
    to some read RDDI based trace source, so we need to override enough
    of ConfigurationBase to prevent it attempting to connect.
    """
    def __init__(self, root):
        DTSLv1.__init__(self, root)
        self.traceFile = None
        self.traceFileType = None
        self.traceCaptureDevice = None
        self.stmATBID = 2
        self.createDevices()

    @staticmethod
    def getOptionList():
        """
        Returns the DTSL options for this configuration class
        """
        return [ 
            IntegerOption(
                name='stmatbid', 
                displayName='STM ATB ID', 
                description='The ATB ID number for the STM device', 
                defaultValue=2,
                isDynamic = False
            ),
            StringOption(
                name='tracefile', 
                displayName='Trace File', 
                description='Binary file containing raw DSTREAM, ETB or STM (STPv2) byte stream', 
                defaultValue='trace.bin',
                isDynamic = False
            ),
            EnumOption(
                name='tracefiletype',
                displayName = 'File Contents',
                description = 'Informs DTSL of the content of the trace file', 
                defaultValue = 'NONE', 
                values = [
                    EnumOption.Value('NONE', 'NONE'), 
                    EnumOption.Value('DSTREAM', 'DSTREAM'), 
                    EnumOption.Value('ETB', 'ETB'), 
                    EnumOption.Value('STM', 'STM(STPv2)')
                ],
                isDynamic = False
            )
        ]

    def createTraceSources(self):
        """
        Creates DTSL trace source components for all known ATB trace sources 
        """
        traceSources = []
        # Generate an STM trace source for ATBID=1
        self.STM = FileBasedSTMTraceSource(self, self.stmATBID, "STM")
        traceSources.append(self.STM)
        # Add any other trace sources we know about .....
        return traceSources

    def createDevices(self):
        """
        Sets up enough trace components to source trace from a file 
        """
        #
        # Create trace sources for all known ATB trace sources
        #
        self.traceSources = self.createTraceSources()
    
    def createTraceCaptureDevice(self, traceFileType):
        if traceFileType == 'STM':
            return RawFileBasedTraceCaptureDevice(self, "FILE") 
        if traceFileType == 'ETB':
            return ETBFileBasedTraceCaptureDevice(self, "FILE") 
        if traceFileType == 'DSTREAM':
            return DSTREAMFileBasedTraceCaptureDevice(self, "FILE") 
        return None

    def connect(self):
        """
        We need to override this so that we make the connections to the
        managed devices [FILE, STM] but we do not try to make any connection 
        to the actual debug/trace h/w - cos there isnt any
        """
        for dev in self.traceSources:
            dev.connect()
        self.traceCaptureDevice.connect()
        self.postConnect()

    def disconnect(self):
        self.preDisconnect()
        for dev in self.traceSources:
            dev.disconnect()
        self.traceCaptureDevice.disconnect()

    def setInitialOptions(self):
        '''Takes the configuration options and configures the 
           DTSL objects prior to target connection
        '''
        self.traceFile = self.getOptionValue('tracefile')
        self.traceFileType = self.getOptionValue('tracefiletype')
        self.stmATBID =  self.getOptionValue('stmatbid')
        self.STM.setStreamID(self.stmATBID)
        if self.traceFileType != 'NONE':
            if self.traceCaptureDevice == None:
                # Create a trace source which reads its data from a file
                self.traceCaptureDevice = self.createTraceCaptureDevice(self.traceFileType)
                self.traceCaptureDevice.setTraceFile(self.traceFile)
                # Add the trace sources to the capture device
                for source in self.traceSources:
                    self.traceCaptureDevice.addTraceSource(source)
                # Tell DTSL about the created trace capture device
                self.addTraceCaptureInterface(self.traceCaptureDevice)
        
    def updateDynamicOptions(self):
        '''Takes any changes to the dynamic options and
           applies them. Note that some trace options may 
           not take effect until trace is (re)started
        '''
        pass
                
    def optionValuesChanged(self):
        '''Callback to update the configuration state after options are changed.
           This will be called:
              * after construction but before device connection
              * during a debug session should the user change the DTSL options
        '''
        if self.isConnected():
            self.updateDynamicOptions()
        else:
            self.setInitialOptions()
