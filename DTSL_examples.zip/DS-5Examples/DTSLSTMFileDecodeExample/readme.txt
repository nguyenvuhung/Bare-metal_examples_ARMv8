DTSL STM File Decode Example
----------------------------

This example shows how to decode STM trace data which has been captured into
a file. The file data can be a DSTREAM buffer, an ETB buffer or just a raw
STPv2 protocol stream.

usage: stmfiledecode
 -h,--help                         print this message
 -i,--stmatbid <arg>               If the file type is DSTREAM or ETB,
                                   this indicates the STM ATB ID within
                                   the formatted trace stream.
 -m,--filetype <DSTREAM|ETB|STM>   set file contents as DSTREAM, ETB or
                                   STM. DSTREAM - is a binary dump of a
                                   DSTREAM trace buffer. ETB - is a binary
                                   dump of an ETB or ETR trace buffer. STM
                                   - is a binary dump of raw STM data
                                   (STPv2 protocol stream).
 -t,--tracefile <tracefile>        specifies the binary trace file


Running the example
-------------------

If you need to rebuild the STMFileDecode.jar file i.e. if you have modified
any of the Java source code and rebuild within Eclipse, from the project 
directory you must issue the following command:

jar cvfm STMFileDecode.jar Manifest.txt -C bin ./stmexample

The example is run by starting the Windows stmfiledecode.bat file or the Linux
stmfiledecode bash script. 
Before you run it make sure you have edited the ../DTSL/dtslsetup.bat batch
file or the ../DTSL/dtslsetup bash script to setup the correct environment.
Also, you must edit the stmfiledecode.bat file (or stmfiledecode script) and change 
the program parameters to suite the target system you are connecting to.

e.g.

stmfiledecode --tracefile "stm-blm.bin" --filetype STM --stmatbid 1
DTSL STM File Decode Example
Using trace file        : stm-blm.bin
Trace file contents     : STM

[snip]
[M:0,C:9]D32 : D = 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000
NULL: TS=465691037260
[M:0,C:1]D32 : D = 0x00000000, 0x00000000, 0x0000011B, 0x00000000, 0x00000DD3
[M:0,C:2]D32 : D = 0x00000000, 0x00000000, 0x0000015A, 0x00000000, 0x00000E03
[M:0,C:3]D32 : D = 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000
[M:0,C:4]D32 : D = 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000
[M:0,C:5]D32 : D = 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000
[M:0,C:6]D32 : D = 0x00000000, 0x00000000, 0x00000271, 0x00000000, 0x00001BD0
[M:0,C:7]D32 : D = 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000
[M:0,C:8]D32 : D = 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000
[M:0,C:9]D32 : D = 0x00000000, 0x00000000, 0x00000004, 0x00000000, 0x00000006
NULL: TS=465691102796
[M:0,C:1]D32 : D = 0x00000000, 0x00000000, 0x00000145, 0x00000000, 0x00000DD0
[M:0,C:2]D32 : D = 0x00000000, 0x00000000, 0x0000013A, 0x00000000, 0x00000E00
[M:0,C:3]D32 : D = 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000
[M:0,C:4]D32 : D = 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000
[M:0,C:5]D32 : D = 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000
[M:0,C:6]D32 : D = 0x00000000, 0x00000000, 0x0000027F, 0x00000000, 0x00001BD0
[M:0,C:7]D32 : D = 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000
[M:0,C:8]D32 : D = 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000
[M:0,C:9]D32 : D = 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000