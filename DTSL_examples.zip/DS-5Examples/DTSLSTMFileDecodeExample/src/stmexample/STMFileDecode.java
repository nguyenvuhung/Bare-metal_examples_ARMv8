/*
 * Copyright (C) 2010-2013 ARM Limited. All rights reserved.
 */
package stmexample;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.GnuParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.OptionBuilder;
import org.apache.commons.cli.ParseException;

import com.arm.debug.dtsl.ConnectionManager;
import com.arm.debug.dtsl.ConnectionParameters;
import com.arm.debug.dtsl.DTSLException;
import com.arm.debug.dtsl.interfaces.IConnection;
import com.arm.debug.dtsl.rddi.IDebugObserver;
import com.arm.debug.dtsl.interfaces.ITraceCapture;
import com.arm.debug.dtsl.interfaces.ITraceSource;
import com.arm.debug.dtsl.impl.IRootConnection;
import com.arm.debug.dtsl.rddi.RDDIConnection;
import com.arm.rddi.IDebug;
import com.arm.rddi.IJTAG;
import com.arm.rddi.ITrace;

public class STMFileDecode {
    /**
     * The DTSL connection 
     */
    private IConnection conn;
    /**
     * The ATB ID for the STM device
     */
    private int stmATBID;
    /**
     * The trace file content
     */
    private enum TraceFileType {
        DSTREAM,
        ETB,
        STM
    }

    /**
     * A dummy target connection - used when the we do not require a real target connection
     */
    static class DummyRootConnection implements IRootConnection
    {
        public DummyRootConnection() throws DTSLException
        {
        }

        @Override
        public void connect() throws DTSLException
        {
        }

        @Override
        public IDebug getDebug() throws DTSLException {
            return null;
        }

        @Override
        public ITrace getTrace() throws DTSLException {
            return null;
        }

        @Override
        public IJTAG getJTAG() throws DTSLException {
            return null;
        }

        @Override
        public void disconnect() {
        }

        @Override
        public String getConnectionAddress() {
            return null;
        }

        @Override
        public String getRDDIInfo() {
            return null;
        }

        @Override
        public String getConnectionInfo() {
            return null;
        }

        @Override
        public void addDebugEventObserver(IDebugObserver observer)
                throws DTSLException {
        }

        @Override
        public void removeDebugEventObserver(IDebugObserver observer)
                throws DTSLException {
        }
    }

    /**
     * A connection factory which creates dummy connections
     */
    private ConnectionManager.IRootConnectionFactory dummyRootConnectionFactory = new ConnectionManager.IRootConnectionFactory()
    {
        @Override
        public IRootConnection createRootConnection(RDDIConnection.ConnectionParameters rddiParams) throws DTSLException
        {
            return new DummyRootConnection();
        }
    };
    
    /**
     * Constructs the demo class
     * @param traceFile the binary file holding the trace data
     * @param traceFileMode the type of data held in the traceFile 
     *   {TraceFileMode.xxxxx}
     * @throws Exception
     */
    STMFileDecode(
            String traceFile, 
            TraceFileType traceFileMode,
            int stmATBID) throws Exception {
    this.stmATBID = stmATBID;
    // Create the DTSL configuration
    ConnectionParameters connectionParameters = new ConnectionParameters();
    connectionParameters.rddiConfigFile = "";
        connectionParameters.configScript = "FileTraceTarget.py"; //$NON-NLS-1$
        connectionParameters.configName = "FILETraceTarget"; //$NON-NLS-1$
        ConnectionManager.setRootConnectionFactory(this.dummyRootConnectionFactory);
        this.conn = ConnectionManager.openConnection(connectionParameters);
        // Set the DTSL options
        this.conn.getConfiguration().setOptionValue("tracefile", traceFile); //$NON-NLS-1$
        this.conn.getConfiguration().setOptionValue("tracefiletype", traceFileMode.name()); //$NON-NLS-1$
        this.conn.getConfiguration().setOptionValue("stmatbid", String.valueOf(this.stmATBID)); //$NON-NLS-1$
    }

    void run() throws DTSLException, Exception {
        this.conn.connect();
        // The DTSL python setup scripts should have created a trace capture device
        // called "FILE", so locate that trace capture device
        ITraceCapture traceCaptureDevice = conn.getTraceCaptureInterfaces().get("FILE"); //$NON-NLS-1$
        if (traceCaptureDevice == null) {
            throw new Exception(
                    "Could not find the \"FILE\" trace capture device - check your configuration script creates one.");
        }
        System.out.println("Connected to trace capture with " + traceCaptureDevice.getMaxCaptureSize() + " byte buffer");
        // The DTSL python setup scripts should have created a trace source
        // called "STM" so locate that trace source
        ITraceSource stmTraceSource = traceCaptureDevice.findTraceSourceByName("STM"); //$NON-NLS-1$
        if (stmTraceSource == null) {
            throw new Exception(
                    "Could not find an STM trace source - check your configuration script creates one.");
        }
        // Create an STM trace reader which can process STM data from the trace stream
        STMTraceReader traceReader = new STMTraceReader(traceCaptureDevice, stmTraceSource);
        traceReader.run();
        this.conn.disconnect();

    }

    private final static String HELP = "help"; //$NON-NLS-1$
    private final static String TRACEFILE = "tracefile"; //$NON-NLS-1$
    private final static String FILETYPE = "filetype"; //$NON-NLS-1$
    private final static String STMATBID = "stmatbid"; //$NON-NLS-1$
    
    @SuppressWarnings("static-access")
public static void main(String[] args) {
        
        Option opt_help = OptionBuilder.withArgName( HELP )
            .withDescription("print this message") //$NON-NLS-1$
            .withLongOpt(HELP)
            .create('h');        
        Option opt_tracefile = OptionBuilder.withArgName( TRACEFILE )
            .hasArg()
            .withDescription("specifies the binary trace file") //$NON-NLS-1$
            .withLongOpt(TRACEFILE)
            .create('t');
        Option opt_tracefiletype = OptionBuilder.withLongOpt( FILETYPE )
            .withDescription( 
            "set file contents as DSTREAM, ETB or STM. " +
            "DSTREAM - is a binary dump of a DSTREAM trace buffer. " +
            "ETB - is a binary dump of an ETB or ETR trace buffer. " +
            "STM - is a binary dump of raw STM data (STPv2 protocol stream)."
            ) //$NON-NLS-1$
            .hasArg()
            .withArgName("DSTREAM|ETB|STM") //$NON-NLS-1$
            .create('m');
        Option opt_stmatbid = OptionBuilder.withLongOpt( STMATBID )
            .withDescription( "If the file type is DSTREAM or ETB, this indicates the " +
                      "STM ATB ID within the formatted trace stream.")//$NON-NLS-1$
            .hasArg()
            .withLongOpt(STMATBID)
            .create('i');
        Options options = new Options();
        options.addOption( opt_help );        
        options.addOption( opt_tracefile );        
        options.addOption( opt_tracefiletype );        
        options.addOption( opt_stmatbid );        
        
        String traceFile = "stm.bin"; //$NON-NLS-1$
        int stmATBID = 2;
        TraceFileType traceFileType = TraceFileType.STM;
        
        // create the parser
        CommandLineParser parser = new GnuParser();
        try {
            // parse the command line arguments
            CommandLine line = parser.parse( options, args );
            
            if( line.hasOption( HELP ) ) {
                HelpFormatter formatter = new HelpFormatter();
                formatter.printHelp( "stmdecode", options ); //$NON-NLS-1$
                System.exit(1);
            }
            if( line.hasOption( TRACEFILE ) ) {
                traceFile = line.getOptionValue( TRACEFILE );
            } else {
                throw new ParseException("You must specify the " + TRACEFILE + " option"); //$NON-NLS-1$ //$NON-NLS-2$
            }
            if( line.hasOption( FILETYPE ) ) {
                String mode = line.getOptionValue( FILETYPE );
                if (TraceFileType.DSTREAM.name().compareToIgnoreCase(mode) == 0)
                    traceFileType = TraceFileType.DSTREAM;
                else if (TraceFileType.ETB.name().compareToIgnoreCase(mode) == 0)
                    traceFileType = TraceFileType.ETB;
                else if (TraceFileType.STM.name().compareToIgnoreCase(mode) == 0)
                    traceFileType = TraceFileType.STM;
                else
                    throw new ParseException("Unknown "+FILETYPE+" setting"); //$NON-NLS-1$ //$NON-NLS-2$
            } else {
                throw new ParseException("You must specify the " + FILETYPE + " option"); //$NON-NLS-1$ //$NON-NLS-2$
            }
            if( line.hasOption( STMATBID ) ) {
            try {
            stmATBID = Integer.parseInt(line.getOptionValue( STMATBID ));
            } catch (NumberFormatException e) {
                    throw new ParseException("The " + STMATBID + " option must be an integer"); //$NON-NLS-1$ //$NON-NLS-2$
            }
            } else {
            if ((traceFileType == TraceFileType.DSTREAM) || (traceFileType == TraceFileType.ETB)) {
                    throw new ParseException("You must specify the " + STMATBID + " option"); //$NON-NLS-1$ //$NON-NLS-2$
            }
            }
        }
        catch( ParseException exp ) {
            System.err.println( "Options parsing failed.  Reason: " + exp.getMessage() ); //$NON-NLS-1$
            System.exit(1);
        }
        
        try {
            System.out.println("DTSL STM File Decode Example"); //$NON-NLS-1$
            System.out.println("Using trace file        : " + traceFile); //$NON-NLS-1$
            System.out.println("Trace file contents     : " + traceFileType.name()); //$NON-NLS-1$
            if (traceFileType != TraceFileType.STM) {
            System.out.println("STM ATB ID              : " + stmATBID); //$NON-NLS-1$
            }
            STMFileDecode stmFileDecode = new STMFileDecode(traceFile, traceFileType, stmATBID);
            stmFileDecode.run();
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }
}
