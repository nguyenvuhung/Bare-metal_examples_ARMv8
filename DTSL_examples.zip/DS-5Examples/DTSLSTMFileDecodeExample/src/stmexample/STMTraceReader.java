/*
 * Copyright (C) 2010-2013 ARM Limited. All rights reserved.
 */
package stmexample;

import java.util.LinkedList;
import java.util.List;

import com.arm.debug.dtsl.DTSLException;
import com.arm.debug.dtsl.interfaces.ISourceReader;
import com.arm.debug.dtsl.interfaces.ITraceCapture;
import com.arm.debug.dtsl.interfaces.ITraceSource;
import com.arm.debug.dtsl.decoders.stm.STMChannelReader;
import com.arm.debug.dtsl.decoders.stm.stmobjects.ISTMObjectReceiver;
import com.arm.debug.dtsl.decoders.stm.stmobjects.STMObject;
import com.arm.debug.dtsl.decoders.stm.stmobjects.STMSourceMatcherRange;

/**
 * Class to read STM trace data and to get it processed into a 
 * text stream.
 */
public class STMTraceReader implements Runnable, ISTMObjectReceiver {
    /**
     * The trace device - FILE or ETB or DSTREAM .....
     */
    private ITraceCapture traceCaptureDevice;
    /**
     * The STM trace source object
     */
    private ITraceSource stmTraceSource;
    /**
     * A list of STMObjects that gets generated for us
     */
    private List<STMObject> stmObjects;
    
    /**
     * Construction
     * @param traceCaptureDevice the trace device (FILE or ETB or DSTREAM ....)
     * @param stmTraceSource the STM trace source object
     */
    public STMTraceReader(ITraceCapture traceCaptureDevice, ITraceSource stmTraceSource) {
        this.stmTraceSource = stmTraceSource;
        this.traceCaptureDevice = traceCaptureDevice;
        this.stmObjects = new LinkedList<STMObject>();
    }
    
    /* (non-Javadoc)
     * @see java.lang.Runnable#run()
     */
    @Override
    public void run() {
        // We read trace data in chunks of this size
        final long MAX_READ_SIZE = 1*1024*1024;
        // The max size of trace we read from the end of the last trace run.
        // The value set here means this size if effectively unlimited i.e. we 
        // process all the trace buffer. If you want to limit this (to the last
        // 1MB (say) then alter this value here.
        final long MAX_PROCESS_SIZE = Long.MAX_VALUE;
        // Create a source matcher that matches any Master and any Channel
        // To limit the STM data processed, change this as appropriate or use one
        // of the other matcher classes
        STMSourceMatcherRange stmSourceMatcher = new STMSourceMatcherRange(0, 128, 0, 65535);
        STMChannelReader stmChannelReader = new STMChannelReader(
                "STM Example", 
                this.traceCaptureDevice, 
                stmSourceMatcher);
        ISourceReader reader = null;
        try {
            // Get a trace reader for the STM data from the trace capture device
            reader = this.traceCaptureDevice.borrowSourceReader("STM Trace Reader", this.stmTraceSource.getStreamID());
            if (reader != null) {
                try {
                    //System.out.println("Processing trace data: "+reader.getName());
                    long captureSize = this.traceCaptureDevice.getCaptureSize();
                    long newCaptureSize = this.traceCaptureDevice.getNewCaptureSize();
                    // Figure out how much _new_ data has been added to the device trace buffer 
                    // and calculate the total amount of data we are going to process
                    long processSize = Math.min(newCaptureSize, MAX_PROCESS_SIZE);
                    // Try to determine if this new data is contiguous with the previous data set
                    boolean traceDataIsContiguous = true;
                    if (captureSize == this.traceCaptureDevice.getMaxCaptureSize()) {
                        // Captured a full buffers worth
                        if (this.traceCaptureDevice.hasWrapped()) {
                            // If the trace wrapped, we have lost continuity
                            traceDataIsContiguous = false;
                        }
                    }
                    if (processSize < newCaptureSize) {    
                        // We are reading less than the new trace data available, 
                        // we have lost continuity 
                        traceDataIsContiguous = false;
                    }
                    if (!traceDataIsContiguous) {
                        stmChannelReader.reSync();
                    }
                    // We start reading at a point 'processSize' back from the end of the buffer
                    long[] nextPos = {captureSize-processSize};
                    while (processSize > 0) {
                        this.stmObjects.clear();
                        long readSize = Math.min(processSize, MAX_READ_SIZE);
                        try {
                            stmChannelReader.read(nextPos[0], readSize, this, nextPos, reader);
                        } catch (DTSLException e) {
                            System.out.println("Caught DTSLException during STPv2 decode:");
                            System.out.println(e.getLocalizedMessage());
                            stmChannelReader.reSync();
                        }
                        for (STMObject stmObj : this.stmObjects) {
                            System.out.println(stmObj.toString());
                        }
                        processSize -= readSize;
                    }
                }
                catch (DTSLException e) {
                    System.out.println("DTSLException:");
                    e.printStackTrace();
                }
                finally {
                    // Must return the trace reader to the trace capture device 
                    // so that DTSL knows we have finished reading
                    this.traceCaptureDevice.returnSourceReader(reader);
                }
            }
        } catch (DTSLException e) {
            System.out.println("Caught DTSLException whilst getting a trace reader");
            System.out.println("DTSLException:");
            e.printStackTrace();
        }
    }

    /* (non-Javadoc)
     * @see com.arm.debug.dtsl.decoders.stm.stmobjects.ISTMObjectReceiver#write(com.arm.debug.dtsl.decoders.stm.stmobjects.STMObject)
     */
    @Override
    public boolean write(STMObject stmObject) {
        this.stmObjects.add(stmObject);
        return true;
    }

}
