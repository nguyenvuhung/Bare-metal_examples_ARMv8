DTSL Jython Show Registers Example
----------------------------------

This example shows how to use DTSL to display the values of a devices
registers. The device must have been created by the platform DTSL 
configuration script, but does not have to be one of the devices actually
used by DS-5 Debugger (though it can be). This allows the register set
from any device in the target platform top be displayed, including
all devices in a VFP model or a real hardware platform.

This example can be run either stand alone or within a DS-5 debug session.

Running the example
-------------------

Within a DS-5 Debug session:
Just drag the main showdeviceregisters.py file onto the backdrop of the debugger's
command view (NOT the command box itself). This should then fill the command box
with the correct command to get the script run. You then need to append any 
parameters the program might require, such as the device name.

e.g.
source "DTSLShowDeviceRegisters/src/showdeviceregisters.py" -d Cortex-M3 -s

Options:
  --version             show program's version number and exit
  -h, --help            show this help message and exit
  -d DEVICE, --device=DEVICE
                        the DTSL device name e.g. Cortex-M3
  -s, --stopDevice      whether to stop execution before reading registers

Outside of DS-5:
The example is run by starting the Windows showregisters.bat file or the Linux
showregisters bash script. However before you run it you must edit the file
and change the program parameters to suite the target system you are connecting
to. Also before you run it make sure you have edited the ../DTSL/dtslsetup.bat batch
file or the ../DTSL/dtslsetup bash script to setup the correct environment.


Options:
  --version             show program's version number and exit
  -h, --help            show this help message and exit
  -d DEVICE, --device=DEVICE
                        the DTSL device name e.g. Cortex-M3
  -s, --stopDevice      whether to stop execution before reading registers

  DS-5 ConfigDB Options:
    Options when invoked as a stand-alone DTSL program getting the
    connection information from a DS-5 ConfigDB entry

    -m MANUFACTURER, --manufacturer=MANUFACTURER
                        the DS-5 configdb board manufacturer
    -b BOARD, --board=BOARD
                        the DS-5 configdb board name
    -o DEBUGOPERATION, --debugOperation=DEBUGOPERATION
                        the DS-5 debug operation (from project_types.xml)
    -y CONNECTIONTYPE, --connectionType=CONNECTIONTYPE
                        the connection type (from project_types.xml)

  DTSL Direct Options:
    Options when invoked as a stand-alone DTSL program directly specifying
    the DTSL configuration information

    -g DTSLSCRIPT, --dtslScript=DTSLSCRIPT
                        the DTSL platform Jython script
    -j DTSLCLASS, --dtslClass=DTSLCLASS
                        the configuration class name (within the platform
                        Jython script)
    -r RDDICONFIGFILE, --rddiConfigFile=RDDICONFIGFILE
                        the RDDI configuration file (the .rvc file)

  Common Options:
    Options which apply for all groups

    -c CONFIGDB, --configdb=CONFIGDB
                        the ; separated list of root configdb locations
    -k DTSLOPTIONS, --dtslOptions=DTSLOPTIONS
                        the name of the DTSL option set
    -n CONNECTIONADDRESS, --connectionAddress=CONNECTIONADDRESS
                        the device to connect to e.g. TCP:MyDSTREAM or USB
