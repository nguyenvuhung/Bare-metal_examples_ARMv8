'''
Class to hold DTSL configuration data
'''

from com.arm.debug.dtsl import ConnectionParameters


class DTSLConfigData(object):
    '''
    Abstracts our configuration information
    '''
    RDDI_CONFIG_FILE = "rddiconfigfile"
    CONNECTION_TYPE = "connectiontype"
    CONNECTION_ADDRESS = "connectionaddress"
    DTSL_SCRIPT = "dtslscript"
    DTSL_CLASS = "dtslclass"
    DTSL_OPTIONS_FILE = "dtsloptionsfile"
    TRACE_CAPTURE_OPTION = "tracecaptureoption"
    SETUP_STEPS = "setupsteps"

    def __init__(self):
        '''
        Constructor
        '''
        # This holds all the DTSL configuration data
        self.configdata = {
            DTSLConfigData.RDDI_CONFIG_FILE: None,
            DTSLConfigData.CONNECTION_TYPE: None,
            DTSLConfigData.CONNECTION_ADDRESS: None,
            DTSLConfigData.DTSL_SCRIPT: None,
            DTSLConfigData.DTSL_CLASS: None,
            DTSLConfigData.DTSL_OPTIONS_FILE: None,
            DTSLConfigData.TRACE_CAPTURE_OPTION: None,
            DTSLConfigData.SETUP_STEPS: None
        }

    def setRDDIConfigurationFile(self, rddiConfigurationFile):
        '''
        Assigns the configurations RDDI configuration file
        Parameters:
            rddiConfigurationFile
                the full path to the RDDI configuration file (for DSTREAM
                this is the .rvc file)
        '''
        self.configdata[DTSLConfigData.RDDI_CONFIG_FILE] = rddiConfigurationFile

    def setConnectionType(self, connectionType):
        '''
        Assigns the configurations connection type i.e. DSTREAM, ULINKpro .....
        Note that not all DS_5 configdb entries require this
        Parameters:
            connectionType
                the string which identifies the connection type
        '''
        self.configdata[DTSLConfigData.CONNECTION_TYPE] = connectionType

    def setConnectionAddress(self, connectionAddress):
        '''
        Assigns the configurations connection address
        Parameters:
            connectionAddress
                the string which identifies which debug controller
                we should connect to e.g. a DSTREAM connection string, for
                example "TCP:mydstream"
        '''
        self.configdata[DTSLConfigData.CONNECTION_ADDRESS] = connectionAddress

    def setDTSLScript(self, dtslScript):
        '''
        Assigns the DTSL platform Jython script
        Parameters:
        Param: dtslScript - the full path to the DTSL Jython script
        '''
        self.configdata[DTSLConfigData.DTSL_SCRIPT] = dtslScript

    def setDTSLClass(self, dtslClass):
        '''
        Assigns the DTSL class name which creates the DTSL configuration. This
        class must be defined in the DTSL platform Jython script.
        Parameters:
            dtslClass
                the DTSL class name
        '''
        self.configdata[DTSLConfigData.DTSL_CLASS] = dtslClass

    def setDTSLOptionsFile(self, dtslOptionsFile):
        '''
        Assigns the DTSL options file which contains the DTSL options
        Parameters:
            dtslOptionsFile
                the full path to the DTSL options file
        '''
        self.configdata[DTSLConfigData.DTSL_OPTIONS_FILE] = dtslOptionsFile

    def setTraceCaptureOption(self, traceCaptureOption):
        '''
        Assigns the name of the trace capture option which holds the currently
        selected trace capture device name
        Parameters:
            traceCaptureOption
                the option name
        '''
        self.configdata[DTSLConfigData.TRACE_CAPTURE_OPTION] = traceCaptureOption

    def setSetupSteps(self, setupSteps):
        '''
        Assigns the platform setup steps - usually an array/list of strings
        which can be understood as a list of instructions on how to prepare
        the target/platform
        Parameters:
            setupSteps
                the steps required to prepare the target/platform
        '''
        self.configdata[DTSLConfigData.SETUP_STEPS] = setupSteps

    def getRDDIConfigurationFile(self):
        '''
        Returns the configurations RDDI configuration file
        '''
        return self.configdata[DTSLConfigData.RDDI_CONFIG_FILE]

    def getConnectionAddress(self):
        '''
        Returns the configurations connection address
        '''
        return self.configdata[DTSLConfigData.CONNECTION_ADDRESS]

    def getConnectionType(self):
        '''
        Returns the configurations connection type
        '''
        return self.configdata[DTSLConfigData.CONNECTION_TYPE]

    def getDTSLScript(self):
        '''
        Returns the DTSL platform Jython script
        '''
        return self.configdata[DTSLConfigData.DTSL_SCRIPT]

    def getDTSLClass(self):
        '''
        Returns the DTSL class name which creates the DTSL configuration.
        '''
        return self.configdata[DTSLConfigData.DTSL_CLASS]

    def getDTSLOptionsFile(self):
        '''
        Returns the DTSL options file which contains the DTSL options
        '''
        return self.configdata[DTSLConfigData.DTSL_OPTIONS_FILE]

    def getTraceCaptureOption(self):
        '''
        Returns the name of the trace capture option which holds the currently
        selected trace capture device name
        '''
        return self.configdata[DTSLConfigData.TRACE_CAPTURE_OPTION]

    def getSetupSteps(self):
        '''
        Returns the platform setup steps - usually an array/list of strings
        which can be understood as a list of instructions on how to prepare
        the target/platform
        '''
        return self.configdata[DTSLConfigData.SETUP_STEPS]

    def isConfigComplete(self):
        '''
        Indicates if we have enough data to create a DTSL connection
        '''
        isComplete = True
        missingItems = ""
        if self.configdata[DTSLConfigData.RDDI_CONFIG_FILE] is not None:
            isComplete = False
            missingItems += "The RDDI config file has not been specified\n"
        if self.configdata[DTSLConfigData.CONNECTION_ADDRESS] is not None:
            isComplete = False
            missingItems += "The debug probe connection address has not been specified\n"
        if self.configdata[DTSLConfigData.DTSL_SCRIPT] is not None:
            if self.configdata[DTSLConfigData.DTSL_CLASS] is not None:
                isComplete = False
                missingItems += "The DTSL configuration class has not been specified\n"
        return isComplete, missingItems

    def getDTSLConnectionParameters(self):
        params = ConnectionParameters()
        params.rddiConfigFile = self.configdata[DTSLConfigData.RDDI_CONFIG_FILE]
        params.address = self.configdata[DTSLConfigData.CONNECTION_ADDRESS]
        params.configScript = self.configdata[DTSLConfigData.DTSL_SCRIPT]
        params.configName = self.configdata[DTSLConfigData.DTSL_CLASS]
        params.optionsFile = self.configdata[DTSLConfigData.DTSL_OPTIONS_FILE]
        return params
