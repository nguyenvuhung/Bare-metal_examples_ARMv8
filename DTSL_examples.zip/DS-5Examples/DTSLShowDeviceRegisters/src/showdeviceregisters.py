'''
Stand alone DTSL Jython program
Copyright (C) 2013-2015 ARM Limited. All rights reserved.
'''

import sys
from com.arm.debug.dtsl import ConnectionManager
from com.arm.debug.dtsl.configurations import DTSLv1
from com.arm.debug.dtsl import DTSLException
from com.arm.debug.dtsl.interfaces import IDevice
from com.arm.debug.dtsl.interfaces import IDeviceConnection
from com.arm.debug.dtsl.rddi import DeviceRegisterInfo
from programoptions import ProgramOptions
from java.lang import StringBuilder
from java.lang.System import nanoTime
from org.python.core import PyException
from jarray import zeros
from com.arm.rddi import RDDIException
from com.arm.rddi import RDDI_EVENT_TYPE
from com.arm.rddi import RDDI_CAP_ID
from com.arm.rddi import RDDI


class MainProgram:
    ''' A class used to contain the program operation
    '''
    VERSION = "1.0"
    # Program return values
    BAD_OPTIONS = -1
    DTSL_CONNECTION_FAILED = -2
    DEVICE_NOT_FOUND = -3
    FAILED_TO_CONNECT_TO_DEVICE = -4
    FAILED_TO_CONTROL_DEVICE = -5

    def __init__(self):
        self.registerIDMap = []
        self.runFromDS5 = False
        self.dtslConnection = None
        self.dtslConfiguration = None

    def showOptions(self, options):
        """ Prints out the program options """
        print "Options:"
        if not self.runFromDS5:
            if options.usesConfigdb():
                print("  configdb         : %s" % (options.getConfigDBLocations()))
                print("  Manufacturer     : %s" % (options.getManufacturer()))
                print("  Board            : %s" % (options.getBoard()))
                print("  Debug Operation  : %s" % (options.getDebugOperation()))
            if options.usesDTSLScript():
                print("  DTSL script      : %s" % (options.getDTSLScript()))
                print("  DTSL class       : %s" % (options.getDTSLScriptClass()))
                print("  DTSL options     : %s" % (options.getDTSLOptions()))
            print("  RDDI config file : %s" % (options.getRDDIConfigFile()))
            print("  Connection Type  : %s" % (options.getConnectionType()))
            print("  Connection Addr  : %s" % (options.getConnectionAddress()))
        print("  Device name      : %s" % (options.getDeviceName()))

    def toHex(self, rVal):
        """ Converts an integer value to a hex string
        Returns a string of the form 0xhhhhhhhh which is the hex
        value of rVal
        Parameters:
            rVal - the integer value to be converted
        """
        return "0x%s" % ("00000000%x" % (rVal & 0xffffffff))[-8:]

    def getDTSLDeviceByName(self, dtslConfiguration, deviceName):
        """ Returns a device object referenced by name
        Parameters:
            dtslConfiguration - the DTSL configuration object
            deviceName - the device name e.e. "Cortex-A9_0" or "TPIU"
        NOTE: the device object we return implements the IDevice interface
        """
        assert isinstance(dtslConfiguration, DTSLv1)
        deviceList = dtslConfiguration.getDevices()
        for device in deviceList:
            assert isinstance(device, IDevice)
            if deviceName == device.getName():
                return device
        return None

    def showDTSLDevices(self, dtslConfiguration):
        """ Prints a list of device names contained in the DTSL configuration
        NOTE: Right now DTSL does not have a simple way of getting all
              such devices. This will be fixed in the next release.
        Parameters:
            dtslConfiguration - the DTSL configuration object
        """
        assert isinstance(dtslConfiguration, DTSLv1)
        print "DTSL Device list:"
        deviceList = dtslConfiguration.getDevices()
        for device in deviceList:
            assert isinstance(device, IDevice)
            print "   %2d: %s" % (device.getID(), device.getName())

    def showDTSLException(self, e):
        """ Prints out a DTSLException
        The exception chain is traversed and non-duplicated
        information from all levels is displayed
        Parameters:
            e - the DTSLException object
        """
        print >> sys.stderr, "Caught DTSL exception:"
        cause = e
        lastMessage = ""
        while cause is not None:
            nextMessage = cause.getMessage()
            if nextMessage != lastMessage:
                if nextMessage is not None:
                    print >> sys.stderr, nextMessage
                lastMessage = nextMessage
            cause = cause.getCause()

    def showRDDIException(self, e):
        """ Prints out a RDDIException
        The exception chain is traversed and non-duplicated
        information from all levels is displayed
        Parameters:
            e - the RDDIException object
        """
        print >> sys.stderr, "Caught RDDI exception:"
        cause = e
        lastMessage = ""
        while cause is not None:
            nextMessage = cause.getMessage()
            if nextMessage != lastMessage:
                if nextMessage is not None:
                    print >> sys.stderr, nextMessage
                lastMessage = nextMessage
            cause = cause.getCause()

    def showJythonException(self, e):
        print >> sys.stderr, "Caught Jython exception:"
        print >> sys.stderr, e.toString()

    def showRuntimeError(self, e):
        """ Prints out a RuntimeException
        Parameters:
            e - the RuntimeException object
        """
        print >> sys.stderr, e

    def detectDS5(self):
        """Detects if we have been launched from within DS-5
        Returns:
            True if launched from DS-5
            False if not i.e. run outside of a DS-5 debug session
        """
        self.runFromDS5 = False
        try:
            from arm_ds.debugger_v1 import Debugger
            self.runFromDS5 = True
        except ImportError:
            self.runFromDS5 = False
        return self.runFromDS5

    def getDS5DTSL(self):
        """For an existing DS-5 connection, we return the DTSL connection
        Returns:
            the DTSLConnection instance
        """
        try:
            from arm_ds.debugger_v1 import Debugger
            debugger = Debugger()
            dtslConfigurationKey = debugger.getConnectionConfigurationKey()
            dtslConnection = ConnectionManager.openConnection(
                dtslConfigurationKey)
        except ImportError:
            dtslConnection = None
        return dtslConnection

    def connectToDTSL(self, dtslConfigData):
        """ Makes our connection to DTSL and returns the connection object """
        params = dtslConfigData.getDTSLConnectionParameters()
        print "Connecting to DTSL ...",
        startTime = nanoTime()
        conn = ConnectionManager.openConnection(params)
        conn.connect()
        timeDelta = nanoTime() - startTime
        if timeDelta > 0:
            timeS = timeDelta * 1.0E-9
            print "done, connection took %.2fs" % (timeS)
        else:
            print "done"
        return conn

    def connectToDevice(self, device):
        """ Makes a connection to a core (or other device)
        Parameters:
            core - the DTSL device to connect to
        Returns:
            True if we connected to the device
            False if the device was already connected
        """
        assert isinstance(device, IDevice)
        weDidConnect = False
        shouldConnect = True
        deviceInfo = StringBuilder(256)
        # If the device implements IDeviceConnection we can
        # discover if it is already connected
        if isinstance(device, IDeviceConnection):
            if device.isConnected():
                shouldConnect = False
        if shouldConnect:
            try:
                startTime = nanoTime()
                device.openConn(None, None, deviceInfo)
                timeDelta = nanoTime() - startTime
                weDidConnect = True
                print "Connected to device %s " % device.getName(),
                if timeDelta > 0:
                    timeS = timeDelta * 1.0E-9
                    print ", connection took %.2fs" % (timeS)
                else:
                    print
            except DTSLException, e:
                # The assumption here is that the connect failed
                # because the device was already connected
                if isinstance(e.cause, RDDIException):
                    if (e.cause.getError() !=
                        RDDI.RDDI_DEVINUSE):
                        raise e
        deviceName = StringBuilder(256)
        deviceDetails = StringBuilder(256)
        device.getDeviceDetails(deviceName, deviceDetails)
        print "Connected to " + deviceName.toString()
        print "   device info    : " + deviceInfo.toString()
        print "   device details : " + deviceDetails.toString()
        return weDidConnect

    def generateDeviceRegisterNameMap(self, device):
        """ Creates the self.registerIDMap list
        self.registerIDMap[] holds tuples (Name, ID) for each register.
        This lets us convert a register name into its integer ID
        Parameters:
            device - the DTSL device of interest
        """
        assert isinstance(device, IDevice)
        # Read info on all device registers
        regInfo = DeviceRegisterInfo.getRegisterInfo(device)
        # Add all to the registerIDMap[]
        if regInfo is not None:
            for regName in sorted(regInfo.keySet()):
                # NOTE: for some targets the register width is not a
                #       whole multiple of 32, but the register read
                #       interface needs multiples of 32 bits. So we
                #       must round up bit widths to 32.
                rInfo = (regName,
                         regInfo[regName].getId(),
                         (regInfo[regName].getSize() + 31) / 32)
                # rInfo[0] is the name
                # rInfo[1] is the register ID
                # rInfo[2] is the size
                self.registerIDMap.append(rInfo)

    def showRegisters(self, device):
        """ Prints out all the register values in hex
        Parameters:
            device - the DTSL device of interest
        """
        assert isinstance(device, IDevice)
        regCount = len(self.registerIDMap)
        for idx in range(0, regCount):
            sz = self.registerIDMap[idx][2]
            # Create a Java array to receive the register values
            values = zeros(sz, 'i')
            # Create java array to hold register IDs
            regIDs = zeros(sz, 'i')
            for i in range(sz):
                regIDs[i] = self.registerIDMap[idx][1] + i
            # Read all register values
            try:
                device.regReadList(regIDs, values)
                print "%s = %s" % (self.registerIDMap[idx][0],
                                   ', '.join(self.toHex(v) for v in values))
            except DTSLException, e:
                print "%s = not readable: %s" % (self.registerIDMap[idx][0],
                                                 e.getMessage())

    def registerOps(self, device):
        """ Runs through an example set of register operations
        Use this as examples of how to access registers
        Parameters:
            device - the DTSL device to show the registers for
        """
        self.generateDeviceRegisterNameMap(device)
        if len(self.registerIDMap) > 0:
            self.showRegisters(device)
        else:
            print "The device '%s' does not expose its register set" % (
                device.getName())

    def setupLogging(self):
        from com.arm.debug.logging import LogFactory
        LogFactory.changeLogLevel("ERROR")  # use DEBUG for lots of logging

    def deviceIsExecuting(self, device):
        """Determines if a device is executing
        Params:
            device - the DTSL device which is assumed to
                     support execution state
        Returns:
            True if we think it is executing or cant determing its
                 execution state at some point close to 'now'
            False if we think it is stopped at some point close to 'now'
        """
        isExecuting = False
        state = zeros(1, 'i')
        cause = zeros(1, 'i')
        detail = zeros(1, 'l')
        tripPage = zeros(1, 'l')
        tripAddress = zeros(1, 'l')
        device.getExecStatus(state, cause, detail, tripPage, tripAddress)
        if state[0] == RDDI_EVENT_TYPE.RDDI_PROC_STATE_STOPPED.swigValue():
            isExecuting = False
        else:
            isExecuting = True
        return isExecuting

    def deviceSupportsExecution(self, device):
        """Determines if the device supports execution state.
           Cores always do, but other devices (like caches or CoreSight
           components) probably do not
        Params:
            device - the DTSL device
        Returns:
            True if the device supports execution state
            False if the device does not support execution state
        """
        supportsExecution = False
        capabilityValues = zeros(RDDI.RDDI_CAPDATA_DEV_SIZE, 'i')
        entriesUsed = zeros(1, 'i')
        device.getCapabilities(
            RDDI_CAP_ID.RDDI_CAP_DEV, capabilityValues, entriesUsed)
        if (capabilityValues[RDDI.RDDI_CAP_DEV_MSGGRP] &
            RDDI.RDDI_CAP_DEV_MGRP_EXE != 0):
            supportsExecution = True
        return supportsExecution

    def deviceSupportsRegReadWhenExecuting(self, device):
        """Determines if the device supports reading register
           values whist executing
        Params:
            device - the DTSL device
        Returns:
            True if the device supports reading register
            values whist executing
            False if the device does not support reading register
            values whist executing
        """
        supportsRegReadWhenExecuting = False
        capabilityValues = zeros(RDDI.RDDI_CAPDATA_DEV_SIZE, 'i')
        entriesUsed = zeros(1, 'i')
        device.getCapabilities(
            RDDI_CAP_ID.RDDI_CAP_DEV, capabilityValues, entriesUsed)
        if (capabilityValues[RDDI.RDDI_CAP_DEV_MSGGRPEXEC] &
            RDDI.RDDI_CAP_DEV_MGRP_REG != 0):
            supportsRegReadWhenExecuting = True
        return supportsRegReadWhenExecuting

    def main(self):
        ''' The main program
        '''
        try:
            self.detectDS5()
            options = ProgramOptions(
                "showdeviceregisters", MainProgram.VERSION, self.runFromDS5)
            options.processOptions()
            self.showOptions(options)
            if self.runFromDS5:
                self.dtslConnection = self.getDS5DTSL()
            else:
                self.setupLogging()
                self.dtslConnection = self.connectToDTSL(
                    options.getDTSLConfigData())
            self.dtslConfiguration = self.dtslConnection.getConfiguration()
            weDidTheDeviceConnection = False
            try:
                print("DTSL Configuration name: " +
                      self.dtslConfiguration.getName())
                self.showDTSLDevices(self.dtslConfiguration)
                device = self.getDTSLDeviceByName(
                    self.dtslConfiguration, options.getDeviceName())
                if device is None:
                    print >> sys.stderr, (
                        "Could not find %s in the device list" %
                        (options.getDeviceName()))
                    sys.exit(MainProgram.DEVICE_NOT_FOUND)
                if not self.runFromDS5:
                    print("Connecting to DTSL configuration %s" %
                          (self.dtslConfiguration.getName()))
                    self.dtslConfiguration.connect()
                weDidTheDeviceConnection = self.connectToDevice(device)
                try:
                    okToReadRegs = True
                    if self.deviceSupportsExecution(device):
                        if options.getStopDevice():
                            if self.deviceIsExecuting(device):
                                device.stop()
                        elif not self.deviceSupportsRegReadWhenExecuting(device):
                            if self.deviceIsExecuting(device):
                                okToReadRegs = False
                                print(
                                    "Device %s can't read registers whilst executing" % 
                                    device.getName())
                    if okToReadRegs:
                        self.registerOps(device)
                except DTSLException, e:
                    self.showDTSLException(e)
                    sys.exit(MainProgram.FAILED_TO_CONTROL_DEVICE)
                except RuntimeError, e:
                    print >> sys.stderr, e
                    sys.exit(MainProgram.FAILED_TO_CONTROL_DEVICE)
                finally:
                    if weDidTheDeviceConnection:
                        print "Closing device connection"
                        device.closeConn()
            except DTSLException, e:
                print
                self.showDTSLException(e)
                sys.exit(MainProgram.FAILED_TO_CONNECT_TO_DEVICE)
            except PyException, e:
                print
                self.showJythonException(e)
                sys.exit(MainProgram.FAILED_TO_CONNECT_TO_DEVICE)
            finally:
                if not self.runFromDS5:
                    print "Closing DTSL connection"
                    self.dtslConfiguration.disconnect()
                    self.dtslConnection.disconnect()
        except DTSLException, e:
            print
            self.showDTSLException(e)
            sys.exit(MainProgram.DTSL_CONNECTION_FAILED)
        except PyException, e:
            print
            self.showJythonException(e)
            sys.exit(MainProgram.DTSL_CONNECTION_FAILED)
        except RuntimeError, e:
            print
            print >> sys.stderr, e
            sys.exit(MainProgram.DTSL_CONNECTION_FAILED)

#sys.path.append('C:\Program Files\DS-5 v5.22.0\sw\eclipse\plugins\org.python.pydev_3.9.2.201502050007\pysrc')
#import pydevd

if __name__ == "__main__":
#    pydevd.settrace(stdoutToServer=True, stderrToServer=True)
    # Create main program and run it
    program = MainProgram()
    program.main()
