DTSL Trace Dump Example
-----------------------

This is an example of how you can dump a DTSL trace capture device's 
buffer to a disc file. The example has been written so that it may be 
used both as a stand alone DTSL program, or as a DS-5 Debugger script.
The program parameter set depends on its run mode.

If run as a DS-5 Debugger script
--------------------------------
Use the --list option to show you the names of the available trace
capture devices.

Use the --device option (defaults to "DSTREAM") to specify the name 
of the trace capture device you wish to dump.

Use the --outputfile option to specify the name of the file to dump
into.

When run as a debugger script, the program will use the DTSL 
configuration currently in use by the debugger.

If run as a stand alone DTSL program
------------------------------------
In common with most DTSL example programs, you can either specify
a configdb entry or directly specify the DTSL connection parameters.
See the tdump.bat file for an example of how to run the program under 
Windows, or the tdump script for Linux. 
Also provided are two Eclipse launch configurations which demonstrate 
the two methods of specifying the DTSL connection parameters.

Program options are also available to;

  * dump part of the trace buffer
  * extract and dump just the raw data from an ATB source
    (assumes trace content is TPIU frames)
  * add an 'RVT Header' to the output file so that the file
    can be processed by the rvtview.exe program (available on
    request from ARM Support)

