'''
Module to process command line options
'''
from dtslconfigdata import DTSLConfigData
from optparse import OptionParser
from optparse import OptionGroup
import sys


class DS5ProgramOptions(object):
    '''
    Parses command line options and provides configuration data to the
    main program
    '''
    BAD_OPTIONS = -1

    def __init__(self, programName, version):
        '''
        Constructor
        '''
        self.programName = programName
        self.version = version
        self.dtslConfigData = DTSLConfigData()
        self.outputFile = None
        self.device = None
        self.stream = 0
        self.position = 0
        self.size = 0
        self.rvtheader = False
        self.list = False

    def examples(self):
        print "e.g. %s --device DSTREAM" % (self.programName)
        print "     --output \"c:\\Users\\tony\\tracedump.bin\""

    def processOptions(self):
        """ Processes command line option """
        parser = OptionParser(usage="usage: %s [options]" % self.programName,
                              version="%s %s" % (self.programName, self.version),
                              description="used to dump trace data to a file")

        group = OptionGroup(parser, "DS-5 Debugger Options",
                    "Options when invoked from the DS-5 Debugger")
        group.add_option("-d", "--device", action="store", type="string",
                         dest="device", default="DSTREAM",
                         help="the DTSL trace capture device name e.g. DSTREAM")
        group.add_option("-l", "--list", action="store_true", dest="list",
                         help="list the available trace capture devices")
        group.add_option("-f", "--outputfile", action="store", type="string",
                         dest="filename", default="tracedump.bin", metavar="FILE",
                         help="the output file to receive the trace data")
        group.add_option("-i", "--stream", action="store", type="int",
                         dest="stream", default="0",
                         help="the optional ATBID of any trace stream to extract "
                              "from the raw trace data. Default to it store complete"
                              "device raw trace data")
        group.add_option("-p", "--position", action="store", type="int",
                         dest="position", default="0",
                         help="the offset within the trace data to start dumping from")
        group.add_option("-s", "--size", action="store", type="int",
                         dest="size", default="0",
                         help="the max size of trace data to store")
        group.add_option("-t", "--rtvheader", action="store_true",
                         dest="header", default=False,
                         help="whether to add the RVT header (for use by rvtview.exe)")
        group.add_option("-x", "--examples", action="store_true",
                         dest="examples", default=False,
                         help="shows example invocations then exits")
        parser.add_option_group(group)
        options = parser.parse_args()[0]

        if options.examples:
            self.examples()
            sys.exit(0)

        self.outputFile = options.outputfile
        self.stream = options.stream
        self.position = options.position
        self.size = options.size
        self.rvtheader = options.rvtheader
        self.device = options.device
        self.list = options.list

    def getDTSLConfigData(self):
        return self.dtslConfigData

    def getOutputFile(self):
        return self.outputFile

    def getDeviceName(self):
        return self.device

    def getStream(self):
        return self.stream

    def getPosition(self):
        return self.position

    def getSize(self):
        return self.size

    def getRVTHeader(self):
        return self.rvtheader

    def getList(self):
        return self.list
