'''
Class to hold DTSL configuration data
'''


class DTSLConfigData(object):
    '''
    Abstracts our configuration information
    '''
    RVC_FILE = "rvcfile"
    CONNECTION = "connection"
    DTSL_SCRIPT = "dtslscript"
    DTSL_CLASS = "dtslclass"
    DTSL_OPTIONS_FILE = "dtsloptionsfile"
    TRACE_CAPTURE_OPTION = "tracecaptureoption"

    def __init__(self):
        '''
        Constructor
        '''
        # This holds all the DTSL configuration data
        self.configdata = {
            DTSLConfigData.RVC_FILE: None,
            DTSLConfigData.CONNECTION: None,
            DTSLConfigData.DTSL_SCRIPT: None,
            DTSLConfigData.DTSL_CLASS: None,
            DTSLConfigData.DTSL_OPTIONS_FILE: None,
            DTSLConfigData.TRACE_CAPTURE_OPTION: None
        }

    def setRVCFile(self, rvcFile):
        '''
        Assigns the configurations RVC file
        Parameters:
            rvcFile
                the full path to the rvc file
        '''
        self.configdata[DTSLConfigData.RVC_FILE] = rvcFile

    def setConnection(self, connection):
        '''
        Assigns the configurations connection
        Parameters:
            connection
                the string which identifies which debug controller
                we should connect to e.g. a DSTREAM connection string, for
                example "TCP:mydstream"
        '''
        self.configdata[DTSLConfigData.CONNECTION] = connection

    def setDTSLScript(self, dtslScript):
        '''
        Assigns the DTSL platform Jython script
        Parameters:
        Param: dtslScript - the full path to the DTSL Jython script
        '''
        self.configdata[DTSLConfigData.DTSL_SCRIPT] = dtslScript

    def setDTSLClass(self, dtslClass):
        '''
        Assigns the DTSL class name which creates the DTSL configuration. This
        class must be defined in the DTSL platform Jython script.
        Parameters:
            dtslClass
                the DTSL class name
        '''
        self.configdata[DTSLConfigData.DTSL_CLASS] = dtslClass

    def setDTSLOptionsFile(self, dtslOptionsFile):
        '''
        Assigns the DTSL options file which contains the DTSL options
        Parameters:
            dtslOptionsFile
                the full path to the DTSL options file
        '''
        self.configdata[DTSLConfigData.DTSL_OPTIONS_FILE] = dtslOptionsFile

    def setTraceCaptureOption(self, traceCaptureOption):
        '''
        Assigns the name of the trace capture option which holds the currently
        selected trace capture device name
        Parameters:
            traceCaptureOption
                the option name
        '''
        self.configdata[DTSLConfigData.TRACE_CAPTURE_OPTION] = traceCaptureOption

    def getRVCFile(self):
        '''
        Returns the configurations RVC file
        '''
        return self.configdata[DTSLConfigData.RVC_FILE]

    def getConnection(self):
        '''
        Returns the configurations connection
        '''
        return self.configdata[DTSLConfigData.CONNECTION]

    def getDTSLScript(self):
        '''
        Returns the DTSL platform Jython script
        '''
        return self.configdata[DTSLConfigData.DTSL_SCRIPT]

    def getDTSLClass(self):
        '''
        Returns the DTSL class name which creates the DTSL configuration.
        '''
        return self.configdata[DTSLConfigData.DTSL_CLASS]

    def getDTSLOptionsFile(self):
        '''
        Returns the DTSL options file which contains the DTSL options
        '''
        return self.configdata[DTSLConfigData.DTSL_OPTIONS_FILE]

    def getTraceCaptureOption(self):
        '''
        Returns the name of the trace capture option which holds the currently
        selected trace capture device name
        '''
        return self.configdata[DTSLConfigData.TRACE_CAPTURE_OPTION]

    def isConfigComplete(self):
        '''
        Indicates if we have enough data to create a DTSL connection
        '''
        isComplete = True
        missingItems = ""
        if self.configdata[DTSLConfigData.RVC_FILE] == None:
            isComplete = False
            missingItems += "The RVC file has not been specified\n"
        if self.configdata[DTSLConfigData.CONNECTION] == None:
            isComplete = False
            missingItems += "The debug probe connection has not been specified\n"
        if self.configdata[DTSLConfigData.DTSL_SCRIPT] == None:
            isComplete = False
            missingItems += "The DTSL platform script has not been specified\n"
        if self.configdata[DTSLConfigData.DTSL_CLASS] == None:
            isComplete = False
            missingItems += "The DTSL configuration class has not been specified\n"
        return isComplete, missingItems
