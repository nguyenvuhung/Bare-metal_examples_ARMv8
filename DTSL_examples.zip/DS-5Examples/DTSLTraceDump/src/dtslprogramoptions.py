'''
Module to process command line options
'''
from java.lang import System
from dtslconfigdata import DTSLConfigData
import configDBResolver
from optparse import OptionParser
from optparse import OptionGroup
import sys
import os


class DTSLProgramOptions(object):
    '''
    Parses command line options and provides configuration data to the
    main program
    '''
    CDB32_WIN = "C:\\Program Files (x86)\\DS-5 v5.22.0\\sw\\debugger\\configdb"
    CDB64_WIN = "C:\\Program Files\\DS-5 v5.22.0\\sw\\debugger\\configdb"

    BAD_OPTIONS = -1

    def __init__(self, programName, version):
        '''
        Constructor
        '''
        self.programName = programName
        self.version = version
        self.dtslConfigData = DTSLConfigData()
        self.manufacturer = None
        self.board = None
        self.debugOperation = None
        self.connectionType = None
        self.launch = None
        self.configDBLocations = None
        self.outputFile = None
        self.stream = 0
        self.position = 0
        self.size = 0
        self.rvtheader = False
        self.device = None
        # On Windows we try to setup some defaults
        if self.runningOnWindows():
            if os.path.isdir(DTSLProgramOptions.CDB32_WIN):
                self.configDBLocations = DTSLProgramOptions.CDB32_WIN
            elif os.path.isdir(DTSLProgramOptions.CDB64_WIN):
                self.configDBLocations = DTSLProgramOptions.CDB64_WIN
            homeDir = os.path.expanduser('~')
            posWorkspace = "%s\\My Documents\\DS-5 Workspace" % (homeDir)
            if os.path.isdir(posWorkspace):
                self.workspace = posWorkspace
            posWorkspace = "%s\\Documents\\DS-5 Workspace" % (homeDir)
            if os.path.isdir(posWorkspace):
                self.workspace = posWorkspace

    def runningOnWindows(self):
        os_name = System.getProperty("os.name")
        return os_name.startswith("Windows")

    def examples(self):
        print "e.g. %s --configdb \"c:\\Program Files (x86)\\DS-5 v5.22.0\\sw\\debugger\\configdb\"" % (self.programName)
        print "     --manufacturer \"Altera\" --board \"Cyclone V SoC\""
        print "     --debugOperation = \"Debug Cortex-A9x2 SMP via Altera USB-Blaster\""
        print "     --dtslOptions = \"C:\\Users\\tony\\Documents\\DS-5 Workspace\\.metadata\\.plugins\\com.arm.ds\\DTSL\\Altera+-+Cyclone+V+SoC\\dtsl_config_script\\USBBlaster_DtslScript\\default.dtslprops\""
        print "     --connectionAddress \"USB-Blaster on localhost [USB-0]:USB-Blaster USB-0\""
        print "     --output \"c:\\Users\\tony\\tracedump.bin\""
        print "e.g. %s --rvcFile \"C:\\Program Files (x86)\\DS-5 v5.22.0\\sw\debugger\\configdb\\Boards\\Altera\\Cyclone V SoC\\Altera_DEV5XS1.rvc\"" % (self.programName)
        print "     --dtslScript \"C:\\Program Files (x86)\\DS-5 v5.22.0\\sw\debugger\\configdb\\Boards\\Altera\\Cyclone V SoC\\dtsl_config_script.py\""
        print "     --dtslClass USBBlaster_DtslScript"
        print "     --dtslOptions = \"C:\\Users\\tony\\Documents\\DS-5 Workspace\\.metadata\\.plugins\\com.arm.ds\\DTSL\\Altera+-+Cyclone+V+SoC\\dtsl_config_script\\USBBlaster_DtslScript\\default.dtslprops\""
        print "     --connectionAddress \"USB-Blaster on localhost [USB-0]:USB-Blaster USB-0\""
        print "     --output \"c:\\Users\\tony\\tracedump.bin\""

    def processOptions(self):
        """ Processes command line option """
        parser = OptionParser(usage="usage: %s [options]" % self.programName,
                              version="%s %s" % (self.programName, self.version),
                              description="used to dump trace data to a file")

        group = OptionGroup(parser, "DS-5 ConfigDB Options",
                    "Options when invoked as a stand-alone DTSL program "
                    "getting the connection information from a DS-5 ConfigDB entry")
        group.add_option("-c", "--configdb", action="store", type="string",
                         dest="configdb", default=None,
                         help="the ; separated list of root configdb locations")
        group.add_option("-m", "--manufacturer", action="store", type="string",
                         dest="manufacturer", default=None,
                         help="the DS-5 configdb board manufacturer")
        group.add_option("-b", "--board", action="store", type="string",
                         dest="board", default=None,
                         help="the DS-5 configdb board name")
        group.add_option("-o", "--debugOperation", action="store", type="string",
                         dest="debugOperation", default=None,
                         help="the DS-5 debug operation (from project_types.xml)")
        group.add_option("-y", "--connectionType", action="store", type="string",
                         dest="connectionType", default=None,
                         help="the connection type (from project_types.xml)")
        parser.add_option_group(group)

        group = OptionGroup(parser, "DTSL Direct Options",
                    "Options when invoked as a stand-alone DTSL program "
                    "directly specifying the DTSL configuration information")
        group.add_option("-g", "--dtslScript", action="store", type="string",
                         dest="dtslScript", default=None,
                         help="the DTSL platform Jython script")
        group.add_option("-j", "--dtslClass", action="store", type="string",
                         dest="dtslClass", default=None,
                         help="the configuration class name (within the platform Jython script)")
        group.add_option("-u", "--traceCaptureOption", action="store", type="string",
                         dest="traceCaptureOption", default=None,
                         help="the DTSL option name which specifies the trace "
                              "capture device name e.g. options.traceBuffer.traceCaptureDevice"
                              "Use in conjunction with --dtslOptions")
        group.add_option("-r", "--rddiConfigFile", action="store", type="string",
                         dest="rddiConfigFile", default=None,
                         help="the RDDI configuration file (the .rvc file)")
        parser.add_option_group(group)

        group = OptionGroup(parser, "Common Options",
                    "Options which apply for all groups")
        group.add_option("-d", "--device", action="store", type="string",
                         dest="device", default=None,
                         help="the DTSL trace capture device name e.g. DSTREAM "
                              "If not specified, the device indicated in any DTSL "
                              "options will be used")
        group.add_option("-f", "--outputFile", action="store", type="string",
                         dest="outputFile", default="tracedump.bin", metavar="FILE",
                         help="the output file to receive the trace data")
        group.add_option("-i", "--stream", action="store", type="int",
                         dest="stream", default="0",
                         help="the optional ATBID of any trace stream to extract "
                              "from the raw trace data. Default to it store complete"
                              "device raw trace data")
        group.add_option("-p", "--position", action="store", type="int",
                         dest="position", default="0",
                         help="the offset within the trace data to start dumping from")
        group.add_option("-n", "--connectionAddress", action="store", type="string",
                         dest="connectionAddress", default="USB",
                         help="the device to connect to e.g. TCP:MyDSTREAM")
        group.add_option("-s", "--size", action="store", type="int",
                         dest="size", default="0",
                         help="the max size of trace data to store")
        group.add_option("-t", "--rvtheader", action="store_true",
                         dest="rvtheader", default=False,
                         help="whether to add the RVT header (for use by rvtview.exe)")
        group.add_option("-k", "--dtslOptions", action="store", type="string",
                         dest="dtslOptions", default=None,
                         help="the name of the DTSL option set")
        group.add_option("-x", "--examples", action="store_true",
                         dest="examples", default=False,
                         help="shows example invocations then exits")
        parser.add_option_group(group)
        options = parser.parse_args()[0]

        if options.examples:
            self.examples()
            sys.exit(0)

        if options.configdb != None:
            self.configDBLocations = options.configdb
        if options.manufacturer != None:
            self.manufacturer = options.manufacturer
        if options.board != None:
            self.board = options.board
        if options.debugOperation != None:
            self.debugOperation = options.debugOperation
        if options.connectionType != None:
            self.connectionType = options.connectionType

        if (self.manufacturer != None) or (self.board != None) or (self.debugOperation != None):
            print "Getting connection parameters from configdb ...",
            params = configDBResolver.getConfigDBParameters(
                        self.configDBLocations,
                        self.manufacturer,
                        self.board,
                        self.debugOperation,
                        self.connectionType)
            self.dtslConfigData.setRVCFile(params["rddiConfigFile"])
            self.dtslConfigData.setDTSLScript(params["dtslScript"])
            self.dtslConfigData.setDTSLClass(params["dtslClass"])
            self.dtslConfigData.setTraceCaptureOption(params["traceCaptureOption"])
            self.coreName = params["device"]
            print "done"

        if options.rddiConfigFile != None:
            self.dtslConfigData.setRVCFile(options.rddiConfigFile)
        if options.dtslScript != None:
            self.dtslConfigData.setDTSLScript(options.dtslScript)
        if options.dtslClass != None:
            self.dtslConfigData.setDTSLClass(options.dtslClass)
        if options.dtslOptions != None:
            self.dtslConfigData.setDTSLOptionsFile(options.dtslOptions)
        if options.connectionAddress != None:
            self.dtslConfigData.setConnection(options.connectionAddress)
        if options.traceCaptureOption != None:
            self.dtslConfigData.setTraceCaptureOption(options.traceCaptureOption)
        self.device = options.device
        self.outputFile = options.outputFile
        self.stream = options.stream
        self.position = options.position
        self.size = options.size
        self.rvtheader = options.rvtheader

        # Check we have enough configuration data
        isComplete, whatsMissing = self.dtslConfigData.isConfigComplete()
        if self.outputFile == None:
            isComplete = False
            whatsMissing += "No output file was specified\n"
        if not isComplete:
            print >> sys.stderr, "Not enough configuration data has been given:"
            print >> sys.stderr, whatsMissing
            parser.print_help()
            sys.exit(DTSLProgramOptions.BAD_OPTIONS)

    def getDTSLConfigData(self):
        return self.dtslConfigData

    def getOutputFile(self):
        return self.outputFile

    def getStream(self):
        return self.stream

    def getPosition(self):
        return self.position

    def getSize(self):
        return self.size

    def getRVTHeader(self):
        return self.rvtheader

    def getDeviceName(self):
        return self.device
