from java.lang import StringBuilder

from com.arm.debug.dtsl.interfaces import IConnection
from com.arm.debug.dtsl.interfaces import IConfiguration
from com.arm.debug.dtsl import DTSLException
from com.arm.debug.dtsl import ConnectionManager
from com.arm.debug.dtsl import ConnectionParameters
from com.arm.debug.dtsl.components import CSDAP
import sys


class DTSLTraceLauncher(object):
    '''
    Class to launch a connection to a DTSL configuration
    '''
    def __init__(self, dtslConfigData):
        '''Construction
        Parameters:
            dtslConfigData - the object holding the DTSL configuration data
        '''
        self.dtslConfigData = dtslConfigData
        self.dtslConnection = None
        self.dtslConfiguration = None
        self.platformLauncher = None

    def getDTSLExceptionString(self, e):
        '''Forms a DTSLException string
        Forms a DTSLException string by walking the exception chain
        and constructing a stack of error messages.
        Parameters:
            e - the DTSLException object
        '''
        assert isinstance(e, DTSLException)
        message = StringBuilder(1024)
        lastException = e
        lastMsg = e.getMessage()
        message.append(lastMsg)
        nextException = lastException.getCause()
        while (nextException != lastException) and (nextException != None):
            nextMsg = nextException.getMessage()
            if nextMsg != lastMsg:
                message.append(", ")
                message.append(nextMsg)
                lastMsg = nextMsg
            lastException = nextException
        return message.toString()

    def showDTSLException(self, e):
        '''Prints out a DTSLException
        The exception chain is traversed and non-duplicated
        information from all levels is displayed
        Parameters:
            e - the DTSLException object
        '''
        print self.getDTSLExceptionString(e)

    def showRuntimeError(self, e):
        ''' Prints out a RuntimeException
        Parameters:
            e - the RuntimeException object
        '''
        print >> sys.stderr, e

    def getFilteredManagedDeviceList(self, captureDevice):
        '''Returns a list of devices we allow the DTSL configuration
           to auto connect to. This includes any DAP devices and the
           required trace capture device.
        Parameters:
            captureDevice
                the name of the capture device - we make sure that is in the
                list!
        '''
        filteredList = []
        for device in self.dtslConfiguration.getManagedComponents():
            if device.getName() == "CSMEMAP":
                filteredList.append(device)
            elif isinstance(device, CSDAP):
                filteredList.append(device)
        filteredList.append(captureDevice)
        return filteredList

    def createDTSLConnection(self):
        '''Creates a DTSL Connection based on the information contained
           in self.dtslConfigData.
        Returns:
            an object which implements IConnection
        '''
        params = ConnectionParameters()
        params.rddiConfigFile = self.dtslConfigData.getRVCFile()
        params.address = self.dtslConfigData.getConnection()
        params.configScript = self.dtslConfigData.getDTSLScript()
        params.configName = self.dtslConfigData.getDTSLClass()
        params.optionsFile = self.dtslConfigData.getDTSLOptionsFile()
        self.dtslConnection = ConnectionManager.openConnection(params)
        assert isinstance(self.dtslConnection, IConnection)

    def launchForTraceCapture(self, traceCaptureDeviceName):
        '''Creates a connected DTSL Configuration instance suitable for use in a
           trace capture session only
        Parameters:
            traceCaptureDeviceName
                The name of the trace capture device to use. If this is None
                we will look up the configured trace capture device in any
                DTSL options
        Returns:
            the connected DTSL configuration
                Will be None if we fail to connect. When you are finished with
                the connection you should call shutdown()
            the DTSL Trace Capture Device object
                Will be None if traceCaptureDeviceName does not exists or there
                is no configured trace capture device
        '''
        try:
            if self.dtslConnection == None:
                self.createDTSLConnection()
            self.dtslConfiguration = self.dtslConnection.getConfiguration()
            assert isinstance(self.dtslConfiguration, IConfiguration)
            # Find the requested trace capture device
            if traceCaptureDeviceName == None:
                traceCaptureDeviceName = self.getSelectedTraceCaptureDeviceName()
                if traceCaptureDeviceName == None:
                    print >> sys.stderr, "No selected trace capture device found"
                    return self.dtslConfiguration, None
            captureDevice = self.dtslConfiguration.getTraceCaptureInterfaces().get(traceCaptureDeviceName)
            if (captureDevice == None):
                print >> sys.stderr, ("No such trace capture device found: %s" %
                      (traceCaptureDeviceName))
                return self.dtslConfiguration, None
            try:
                # replace the configurations list of managed devices with a new
                # list that only contains the trace capture device. This will
                # prevent the configuration connecting to all the other devices
                self.dtslConfiguration.setManagedDevices(
                    self.getFilteredManagedDeviceList(captureDevice))
                # Try to stop the trace device loosing its content when we connect
                captureDevice.setAutoStartTraceOnConnect(False)
                captureDevice.setClearOnConnect(False)
                # Get the configuration connected
                self.dtslConnection.connect()
                return self.dtslConfiguration, captureDevice
            except DTSLException, e:
                print >> sys.stderr, ("Failed to connect root debug connection (%s)" %
                               (self.getDTSLExceptionString(e)))
                return None, None
        except DTSLException, e:
            print >> sys.stderr, "\nFailed to create the DTSL configuration. Reported error is:"
            self.showDTSLException(e)
            return None, None

    def shutdown(self):
        '''Shutsdown (disconnects) from the DTSL connection'''
        if self.dtslConnection != None:
            self.dtslConnection.disconnect()

    def getTraceCaptureDevices(self):
        '''Returns a list of trace capture devices along with the name of any
           currently selected trace capture device
        Returns:
            the name of the selected trace device or None if there isn't one
            a name list of available trace capture devices or None
        '''
        deviceList = None
        selectedDevice = None
        if self.dtslConnection == None:
            self.createDTSLConnection()
        self.dtslConfiguration = self.dtslConnection.getConfiguration()
        captureDevices = self.dtslConnection.getTraceCaptureInterfaces()
        if captureDevices != None:
            deviceList = captureDevices.keySet()
            selectedTraceDeviceOptionName = self.dtslConfigData.getTraceCaptureOption()
            try:
                optionValues = self.dtslConfiguration.getOptionValues()
                selectedDevice = optionValues[selectedTraceDeviceOptionName]
            except DTSLException, e: # @UnusedVariable
                print >> sys.stderr, ("Failed to read currently selected trace capture device from %s" % (
                        selectedTraceDeviceOptionName))
                return None, None
        return selectedDevice, deviceList

    def getSelectedTraceCaptureDeviceName(self):
        '''Returns the selected trace capture device. This usually means the one
           selected in any DTSL options we have available.
        '''
        selectedTraceCaptureDeviceName = self.getTraceCaptureDevices()[0]
        return selectedTraceCaptureDeviceName
