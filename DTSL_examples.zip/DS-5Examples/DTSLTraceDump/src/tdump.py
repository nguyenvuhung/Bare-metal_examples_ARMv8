#! /usr/bin/env python

from com.arm.debug.dtsl import ConnectionManager
from com.arm.debug.dtsl.interfaces import IConfiguration
from ds5programoptions import DS5ProgramOptions
from dtslprogramoptions import DTSLProgramOptions
from tracedump import TraceDump
from progress import Progress
from dtsltracelauncher import DTSLTraceLauncher
import sys

VERSION = "1.0"


def dumpDS5DebuggerTrace():
    '''Dump the trace when connected via DS-5 Debugger'''
    # Use debugger launch options
    options = DS5ProgramOptions("tdump", VERSION)
    options.processOptions()
    # Connect to DS-5 Debugger
    debugger = Debugger()
    assert isinstance(debugger, Debugger)
    if not debugger.isConnected():
        return
    # Access the underlying DTSL configuration
    dtslConnectionConfigurationKey = debugger.getConnectionConfigurationKey()
    dtslConnection = ConnectionManager.openConnection(dtslConnectionConfigurationKey)
    dtslConfiguration = dtslConnection.getConfiguration()
    assert isinstance(dtslConfiguration, IConfiguration)
    # Locate the trace capture device
    traceCaptureDeviceName = options.getDeviceName()
    captureDevice = dtslConfiguration.getTraceCaptureInterfaces().get(traceCaptureDeviceName)
    if (captureDevice == None):
        print >> sys.stderr, "No such trace capture device found: %s" % (traceCaptureDeviceName)
    else:
        td = TraceDump(dtslConfiguration)
        progressReporter = Progress(False)
        td.dumpTrace(captureDevice, options.getStream(),
                     options.getPosition(), options.getSize(),
                     options.getRVTHeader(), options.getOutputFile(),
                     progressReporter)


def dumpDTSLTrace():
    '''Dump the trace as a stand alone DTSL program'''
    try:
        # Get stand alone program options
        options = DTSLProgramOptions("tdump", VERSION)
        options.processOptions()
        # Get the platform and DTSL configuration all connected up
        launcher = DTSLTraceLauncher(options.getDTSLConfigData())
        traceCaptureDeviceName = options.getDeviceName()
        dtslConfiguration, traceCaptureDevice = launcher.launchForTraceCapture(traceCaptureDeviceName)
        try:
            if dtslConfiguration != None and traceCaptureDevice != None:
                td = TraceDump(dtslConfiguration)
                progressReporter = Progress(False)
                td.dumpTrace(traceCaptureDevice, options.getStream(),
                             options.getPosition(), options.getSize(),
                             options.getRVTHeader(), options.getOutputFile(),
                             progressReporter)
        finally:
            # Must shut down what we started up
            launcher.shutdown()
    except RuntimeError, e:
        print >> sys.stderr, e


if __name__ == "__main__":
    # Detect whether we were launched from DS-5 Debugger or not
    try:
        from arm_ds.debugger_v1 import Debugger
        dumpDS5DebuggerTrace()
    except ImportError, e:
        dumpDTSLTrace()
