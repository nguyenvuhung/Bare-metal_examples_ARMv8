from java.lang import Math
from java.lang import Throwable
from java.io import BufferedOutputStream
from java.io import FileOutputStream
from java.io import FileNotFoundException
from java.io import IOException
from java.lang import StringBuilder
from java.lang.System import nanoTime

from com.arm.debug.dtsl.interfaces import ITraceCapture
from com.arm.debug.dtsl import DTSLException
import sys
import jarray
from progress import Progress


class TraceDump(object):
    """
    Class to dump the content of a trace capture device to a file
    """
    def __init__(self, dtslConfiguration):
        """Construction
        Parameters:
            dtslConfiguration - the object holding the connected DTSL
            configuration instance
        """
        self.dtslConfiguration = dtslConfiguration

    def getDTSLExceptionString(self, e):
        '''Forms a DTSLException string
        Forms a DTSLException string by walking the exception chain
        and constructing a stack of error messages.
        Parameters:
            e - the DTSLException object
        '''
        assert isinstance(e, DTSLException)
        message = StringBuilder(1024)
        lastException = e
        lastMsg = e.getMessage()
        message.append(lastMsg)
        nextException = lastException.getCause()
        while (nextException != lastException) and (nextException != None):
            nextMsg = nextException.getMessage()
            if nextMsg != lastMsg:
                message.append(", ")
                message.append(nextMsg)
                lastMsg = nextMsg
            lastException = nextException
        return message.toString()

    def showDTSLException(self, e):
        '''Prints out a DTSLException
        The exception chain is traversed and non-duplicated
        information from all levels is displayed
        Parameters:
            e - the DTSLException object
        '''
        print self.getDTSLExceptionString(e)

    def showRuntimeError(self, e):
        """ Prints out a RuntimeException
        Parameters:
            e - the RuntimeException object
        """
        print >> sys.stderr, e

    def calcRate(self, byteCount, timeS):
        '''Returns a reasonably scaled transfer rate value and units string
        Parameters:
            byteCount
                The size of the transfer in bytes
            timeS
                The time the transfer took in seconds
        Returns:
            The transfer rate value
            The units string
        '''
        if timeS == 0:
            return float('inf'), "bytes/s"
        rate = byteCount / timeS
        if rate < 1024.0:
            return rate, "bytes/s"
        rate = rate / 1024.0
        if rate < 1024.0:
            return rate, "KB/s"
        rate = rate / 1024.0
        if rate < 1024.0:
            return rate, "MB/s"
        rate = rate / 1024.0
        return rate, "GB/s"

    def calcMemUnits(self, byteCount):
        '''Returns a reasonably scaled memory size value and units string
        Parameters:
            byteCount
                The size of the memory in bytes
        Returns:
            The scaled memory value
            The units string
        '''
        if (byteCount < 1024):
            return "bytes", 1.0
        elif (byteCount < 1024 * 1024):
            return "KB", 1024.0
        elif (byteCount < 1024 * 1024 * 1024):
            return "MB", 1024.0 * 1024.0
        return "GB", 1024.0 * 1024.0 * 1024.0

    def addRVTHeader(self, out):
        minimalHeader = [
            "\x52\x56\x54\x00", # RVT header
            "\x70\x00\x00\x00", # Total length of header
            "\x01\x00\x04\x00\x00\x01\x00\x00", # FILE_VERSION_INFO
            "\x02\x00\x0C\x00\x01\x02\x00\x01\x90\x00\x00\x00\x15\xD5\xF8\x46", # CAPTURE_UID
            "\x04\x00\x0C\x00\x03\x00\x0C\x00\x00\x00\x00\x00\x00\x00\x00\x00", # TRACE_FOTMAT_ID
            "\x05\x00\x04\x00\x00\x00\x00\x00", # TRACE STREAM_FORMAT
            "\x06\x00\x0C\x00\x63\x00\x02\x00\x08\x00\x00\x00\x00\x00\x00\x00", # TRIGGER_INFO
            # TRACE_SOURCE_INFO
            "\x07\x00\x08\x00\x04\x00\xFF\x03\x10\x00\x01\x00\x0A\x00\x20\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
            ]
        out.write(''.join(minimalHeader))

    def dumpTrace(self, captureDevice, streamID, startPos, maxSize, addRVTHeader, filename, progress):
        '''
        Dumps all the trace content to a file in pure binary format
        Parameters:
            captureDevice
                The DTSL object that implements ITraceCapture
            streamID
                0 for the RAW captured data, non-zero to just extract the
                trace data for the specified streamID (usually an ATB ID)
            startPos
                offset from start of trace to start dump from
            maxSize
                max size of trace data to dump, in bytes
            addRVTHeader
                True to add the RVT header to the start of the dump file
            filename
                the name of the file to dump the trace to
            progress
                the object to which we report our progress/state/errors
        '''
        assert isinstance(captureDevice, ITraceCapture)
        assert isinstance(progress, Progress)
        # If capture device is empty - do not overwrite any previous file
        try:
            captureSize = captureDevice.getCaptureSize()
            if (captureSize == 0):
                progress.error("Trace capture device %s is empty" %
                               (captureDevice.getName()))
                return
        except DTSLException, e:
            progress.error("Failed to read from capture device %s (%s)" %
                           (captureDevice.getName(), self.getDTSLExceptionString(e)))
            return
        if streamID == 0:
            streamID = ITraceCapture.RAW_DATA
        if maxSize:
            dumpSize = min(captureSize, maxSize)
        else:
            dumpSize = captureSize
        if startPos + dumpSize > captureSize:
            dumpSize = captureSize - startPos
        progress.setProgress(0)
        try:
            # We use the Java file IO system to write to the file
            progress.setCurrentOperation("Opening output file %s" % (filename))
            out = BufferedOutputStream(FileOutputStream(filename))
        except FileNotFoundException, e:
            progress.error("Failed to create output file %s (%s)" %
                           (filename, e.getLocalizedMessage()))
            return
        if addRVTHeader:
            self.addRVTHeader(out)
        startTime = nanoTime()
        try:
            # big chunk size ensures reasonable performance from large capture devices
            MAX_CHUNK = captureDevice.getRecommendedReadSize()
            # Create a byte array as a data buffer
            captureBuf = jarray.zeros(MAX_CHUNK, 'b')
            units, divisor = self.calcMemUnits(dumpSize)
            progress.setCurrentOperation("Dumping %.1f%s of trace data" %
                                  (dumpSize / divisor, units))
            bytesLeft = dumpSize
            pcComplete = 0
            # This is used to tell us where to read from next
            nextPos = jarray.zeros(1, 'l')
            nextPos[0] = startPos
            pcComplete = 0
            progress.setProgress(pcComplete)
            while (bytesLeft > 0):
                newPCComplete = 100 * nextPos[0] / dumpSize
                if (newPCComplete > pcComplete + 5):
                    pcComplete = newPCComplete
                    progress.setProgress(pcComplete)
                bytesThisChunk = Math.min(bytesLeft, MAX_CHUNK)
                extractedBytes = captureDevice.getSourceData(
                                    streamID,
                                    nextPos[0], bytesThisChunk, captureBuf,
                                    nextPos)
                out.write(captureBuf, 0, extractedBytes)
                bytesLeft -= bytesThisChunk
            progress.setProgress(100)
            timeDelta = nanoTime() - startTime
            if timeDelta > 0:
                timeS = timeDelta * 1.0E-9
                rate, rateUnits = self.calcRate(dumpSize, timeS)
                print 
                print("Completed reading %.1f%s of trace data in %.2fs, i.e. %.2f %s" % (
                                        dumpSize / divisor, units, timeS, rate, rateUnits))
        except IOException, e:
            progress.error("Failed to write to output file %s (%s)" %
                           (filename, e.getLocalizedMessage()))
        except DTSLException, e:
            progress.error("Failed to read from capture device %s (%s)" %
                           (captureDevice.getName(), self.getDTSLExceptionString(e)))
        except Throwable, e:
            progress.error("Failed to read from capture device %s (%s)" %
                           (captureDevice.getName(), e.getLocalizedMessage()))
        finally:
            out.close()

    def dumpAllTraceToFile(self, traceCaptureDeviceName, filename, progress):
        """Dumps the raw content of a trace capture device to a disk file
        Parameters:
            traceCaptureDeviceName
                the name of one of the trace capture devices this
                configuration created
            filename
                to dump the trace content to
            progress
                used to report our progress
        """
        self.dumpTrace(traceCaptureDeviceName, 0, 0, 0, False, filename, progress)
