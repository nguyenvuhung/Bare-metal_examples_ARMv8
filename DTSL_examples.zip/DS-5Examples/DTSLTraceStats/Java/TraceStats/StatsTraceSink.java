package TraceStats;

/**
 * If you are building using the workspace imported DTSL standalone dist:
 * javac -cp <workspace>/DTSL/libs/dtsl-bundle.jar -source 1.7 -target 1.7 StatsTraceSink.java
 * 
 * If you are building with access to the DTSL source code you can build using:
 * javac -sourcepath <src-path>/eclipse/plugins/com.arm.debug.dtsl/src StatsTraceSink.java
 */

import com.arm.debug.dtsl.impl.PipelineStageBase;
import com.arm.debug.dtsl.interfaces.ITraceSource;

/**
 * Class which associates a trace sink with a DTSL trace source. The 
 * PipelineStageBase will collect our received data stats which can then
 * be associated with the trace source which generated the data.
 */
public class StatsTraceSink extends PipelineStageBase {

    /**
     * The DTSL trace source associated with this data sink. If this is
     * null, there is no association.
     */
    private ITraceSource dtslTraceSource;
    
    public StatsTraceSink(ITraceSource dtslTraceSource) {
        this.dtslTraceSource = dtslTraceSource;
    }
    
    public ITraceSource getDTSLTraceSource() {
        return this.dtslTraceSource;
    }
    
    @Override
    public void consume(int count) {
    }

    @Override
    public void flush() {
    }

}
