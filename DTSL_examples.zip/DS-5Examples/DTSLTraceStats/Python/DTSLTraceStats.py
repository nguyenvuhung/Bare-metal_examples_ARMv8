#! jython
'''
DTSL Script to analyse a trace buffer full of TPIU content (or rather
CoreSight Trace Formatter content) and let us know which trace sources
are present in the buffer.
'''

from jarray import zeros
from java.lang import StringBuilder
from java.lang import Thread
from java.lang.System import nanoTime
from java.util import HashMap
import os
import sys

from DTSLHelper import findDTSLTraceSourceForATBID
from DTSLHelper import formRateString
from DTSLHelper import formTraceSizeString
from DTSLHelper import getDTSLTraceCaptureDevice
from DTSLHelper import showDTSLException
from DTSLHelper import showDTSLTraceCaptureDevices
from DTSLHelper import showDTSLTraceSourcesForCaptureDevice
from DTSLHelper import showJythonException
from DTSLHelper import showRDDIException
from com.arm.debug.dtsl import ConnectionManager
from com.arm.debug.dtsl import DTSLException
from com.arm.debug.dtsl.impl import Deformatter
from com.arm.debug.dtsl.impl import PipelineStageBase
from com.arm.debug.dtsl.impl import SyncStripper
from com.arm.debug.dtsl.interfaces import ITraceCapture
from com.arm.rddi import RDDIException
from options import ProgramOptions
from org.python.core import PyException
from progress import Progress
from tracedataconsumer import TraceDataConsumer


# To enable us to use the project Java code we must add the path containing
# the .class file(s). Then we can import them. The path is modified this way
# so that it works when run either stand alone or from within DS-5.
myPath = os.path.abspath(sys.argv[0])
sys.path.append(os.path.join(os.path.dirname(myPath), '../Java'))
from TraceStats import StatsTraceSink 

VERSION = "2.0"


class ProgramException(Exception):
    """ Exception class used within this program
    """
    def __init__(self, description, cause=None):
        self.description = description
        self.cause = cause

    def getCause(self):
        return self.cause

    def __str__(self):
        msg = "ProgramException: %s" % (self.description)
        if self.cause is not None:
            msg = msg + "\nCaused by:\n%s" % (self.cause.__str__())
        return msg

    def getMessage(self):
        return "ProgramException: %s" % (self.description)


def getDTSLConfiguration(debugger):
    """ Returns the DTSL configuration object
        currently being used by the DS-5 debuggerTraceDataProcessor
    Parameters:
        debugger - the DS-5 debugger interface
    """
    dtslConnectionConfigurationKey = debugger.getConnectionConfigurationKey()
    dtslConnection = ConnectionManager.openConnection(
        dtslConnectionConfigurationKey)
    return dtslConnection.getConfiguration()


def showProgramException(e):
    """ Prints out a ProgramException
    The exception chain is traversed and non-duplicated
    information from all levels is displayed
    Parameters:
        e - the ProgramException object
    """
    print >> sys.stderr, "Caught program exception:"
    cause = e
    lastMessage = ""
    while cause is not None:
        nextMessage = cause.getMessage()
        if nextMessage != lastMessage:
            if nextMessage is not None:
                print >> sys.stderr, nextMessage
            lastMessage = nextMessage
        cause = cause.getCause()


def detectDS5():
    """Detects if we have been launched from within DS-5
    Returns:
        True if launched from DS-5
        False if not i.e. run outside of a DS-5 debug session
    """
    fromDS5 = False
    try:
        from arm_ds.debugger_v1 import Debugger
        fromDS5 = True
    except ImportError:
        fromDS5 = False

    return fromDS5


def getDS5DTSL():
    """For an existing DS-5 connection, we return the DTSL connection
    Returns:
        the DTSLConnection instance
    """
    try:
        from arm_ds.debugger_v1 import Debugger
        debugger = Debugger()
        dtslConfigurationKey = debugger.getConnectionConfigurationKey()
        dtslConnection = ConnectionManager.openConnection(
            dtslConfigurationKey)
    except ImportError:
        dtslConnection = None
    return dtslConnection


def buildTraceSourcePipeline(captureDevice):
    """ Create a trace processing pipeline which terminates in a
        collection of StatsTraceSink objects - one for each possible
        trace ATBID value.
    Params:
        captureDevice - the trace capture device used to capture the
                        raw trace
    Returns:
        An array of IDataPipelineStage objects (does not include the
        StatsTraceSink objects) and a Map which maps ATBID to the
        StatsTraceSink object
    """
    targetsAndDestinations = HashMap()
    for atbid in range(1, 0x70):
        statsTraceSync = StatsTraceSink(
            findDTSLTraceSourceForATBID(captureDevice, atbid))
        targetsAndDestinations.put(atbid, statsTraceSync)
    deformatter = Deformatter(targetsAndDestinations)
    syncStripper = SyncStripper(deformatter)
    pipeline = [syncStripper, deformatter]
    return pipeline, targetsAndDestinations


def processTraceData(captureDevice, traceDataSink, progress):
    """Reads trace data from a capture device and sends it to a trace
       data sink
    Params:    syncStripper = SyncStripper(statsTraceSync)

        captureDevice - the trace capture device we read from
        traceDataSink - the trace sink to which we send the data (note that
                        this is typically the first stage of a multi-stage
                        data processing pipeline)
        progress - the Progress object we update with our progress
    """
    # We read trace data on the current thread and process the trace data
    # on another thread. This lets us overlap the reading and processing
    # of trace data
    # Get a trace reader which returns us CAPTURED data i.e. any capture
    # device specific formatting has been removed
    traceReader = captureDevice.borrowSourceReader(
        "traceStats", ITraceCapture.CAPTURED_DATA)
    try:
        MAX_READ_SIZE = captureDevice.getRecommendedReadSize()
        MAX_PROCESS_SIZE = captureDevice.getMaxCaptureSize()
        print("Reading trace in chunks of %s" %
              formTraceSizeString(MAX_READ_SIZE))
        # Have 2 data blocks - one we fill with data whilst the other is being
        # processed by the processing thread
        dataBlocks = [zeros(MAX_READ_SIZE, 'b'), zeros(MAX_READ_SIZE, 'b')]
        blockID = 0
        captureSize = captureDevice.getCaptureSize()
        processSize = min(captureSize, MAX_PROCESS_SIZE)
        # Create our Runnable trace data processing object
        dataProcessor = TraceDataConsumer(traceDataSink)
        processingThread = None
        # We start reading at a point 'processSize' back from the end of the
        # buffer
        nextPos = zeros(1, 'l')
        nextPos[0] = captureSize-processSize
        traceDataProcessed = 0
        progress.setCurrentOperation("Uploading trace data")
        progress.setRange(0, processSize)
        sourceTotal = 0
        startTime = nanoTime()
        while processSize > 0:
            readSize = min(processSize, MAX_READ_SIZE)
            sourceByteCount = traceReader.read(
                nextPos[0], readSize, dataBlocks[blockID], nextPos)
            sourceTotal += sourceByteCount
            if sourceByteCount > 0:
                # If we have a previous decode thread then we must wait for it
                # to have completed
                if processingThread is not None:
                    processingThread.join()
                # Inform data processor of new data set
                dataProcessor.setDataset(dataBlocks[blockID], sourceByteCount)
                # Get data processor run in a new thread
                processingThread = Thread(dataProcessor)
                processingThread.start()
            # Switch buffer blocks to the 'other one'
            blockID = 1 - blockID
            processSize -= readSize
            traceDataProcessed += readSize
            progress.setProgress(traceDataProcessed)
        # Make sure all data has been processed
        if processingThread is not None and processingThread.isAlive():
            processingThread.join()
        traceDataSink.flush()
        # Lets see how long that all took
        timeDelta = nanoTime() - startTime
        if timeDelta > 0:
            time = timeDelta * 1.0E-9
            progress.setCompleted(
                "Processing complete, took %.2fs at %s" % (
                    time, formRateString(traceDataProcessed, time)))
        else:
            progress.setCompleted("Processing complete")
        print "Read %s from trace buffer" % formTraceSizeString(sourceTotal)
    finally:
        # We must always return the reader to the capture device
        captureDevice.returnSourceReader(traceReader)


def createConnectedDTSL(options):
    """ Creates a connection to DTSL and returns the connection object
    Params:
        options - our processed command line options from which we can get
                  the DTSL connection parameters
    """
    dtslConfigData = options.getDTSLConfigData()
    params = dtslConfigData.getDTSLConnectionParameters()
    print "Connecting to DTSL ...",
    startTime = nanoTime()
    conn = ConnectionManager.openConnection(params)
    conn.connect()
    timeDelta = nanoTime() - startTime
    if timeDelta > 0:
        timeS = timeDelta * 1.0E-9
        print "done, connection took %.2fs" % (timeS)
    else:
        print "done"
    return conn


def setupLogging():
    from com.arm.debug.logging import LogFactory
    LogFactory.changeLogLevel("INFO")  # use DEBUG for lots of logging


def doFullTraceAnalysis(captureDevice, progress):
    """ Does a full analysis of the trace capture device content to generate
        a report showing the present ATB IDs and how much trace data is
        presents for each of the ATB IDs. This can take a long time!
    Params:
        captureDevice - the DTSL TraceCapture object we use to access
                        the trace data
        progress - the object we use to report progress
    """
    pipeline, targetsAndDestinations = buildTraceSourcePipeline(
        captureDevice)
    processTraceData(captureDevice, pipeline[0], progress)
    for pipelineStage in pipeline:
        stageName = pipelineStage.toString().split('@')[0]
        counterValues = pipelineStage.collectCounterValues()
        print "%s received %s" % (
            stageName,
            formTraceSizeString(
                counterValues.get(PipelineStageBase.RECEIVED_DATA)
                ))
    print "Trace Stats Report:"
    print "+------------------+------------------+"
    print "|      ATB ID      |       Size       |"
    print "+------------------+------------------+"
    for atbid in targetsAndDestinations.keySet():
        target = targetsAndDestinations[atbid]
        counterValues = target.collectCounterValues()
        byteCount = counterValues.get(
            PipelineStageBase.RECEIVED_DATA)
        traceSource = target.getDTSLTraceSource()
        if byteCount > 0:
            if traceSource is None:
                sourceName = "%d" % atbid
            else:
                sourceName = "%s[%d]" % (
                    traceSource.getName(), atbid)
            print "| %16s | %16s |" % (
                sourceName.center(16),
                formTraceSizeString(byteCount).center(16))
    print "+------------------+------------------+"


def getBucketSize(targetSize):
    """ Returns valid bucket size for a requested target size.
        The smallest allowed bucket size is 2K and a valid size
        is a power of 2. So we return:
            bucketSize = 2^n > targetSize > 2^(n-1)
    Params:
        targetSize -
    """
    # Min allowed bucket size if 2K
    if targetSize < 2048:
        return 2048
    # Check if already a power of 2
    if (targetSize & (targetSize-1)) == 0:
        return targetSize
    # while not a power of 2 ...
    while (targetSize & (targetSize-1)) != 0:
        # remove lowest set bit
        targetSize = targetSize & (targetSize-1)
    # Left with power of 2 with all lower bits removed,
    # so we need next highest power of 2
    return 2*targetSize


def formSourceMapEntriesString(slots, presenceData):
    """ Forms a single 'line' of ATB ID location within the trace buffer
    Params:
        slots - how many display slots (characters) we should generate
        presenceData - a BitSet each bit set to true if trace data is
                       present for a slot
    Returns:
        a string with slots characters representing presence of trace data
        e.g. "X...XXXXXXXXXXXXX........XXXXXXXXXXXX......................."
    """
    sourceMapEntriesString = StringBuilder(slots)
    for bitPos in range(slots):
        if presenceData.get(bitPos):
            sourceMapEntriesString.append("X")
        else:
            sourceMapEntriesString.append(".")
    return sourceMapEntriesString.toString()


def doQuickTraceAnalysis(captureDevice, progress):
    """ Generates a report of ATB IDs present in the trace buffer
        along with a map of where the data resides in the trace buffer
    Params:
        captureDevice - the DTSL TraceCapture object we use to access
                        the trace data
        progress - the object we use to report progress
    """
    captureSize = captureDevice.getCaptureSize()
    if captureSize == 0:
        print "Trace capture device %s is empty" % captureDevice.getName()
        return
    # maxWidth gives the max character width of the ATB ID location map string
    # increasing this effectively zooms in the 'display'
    maxWidth = 128
    # bucketSize is the amount of trace buffer data represented by one bit
    # of returned dataPresence data
    bucketSize = getBucketSize(captureSize / maxWidth)
    # slots is the actual number of display characters we need for a line
    # of ATB ID location data
    slots = (captureSize + bucketSize - 1) / bucketSize
    print "Trace Buffer ATB ID Report:"
    print "+------------------+-%s-+" % ("".rjust(slots, "-"))
    print "|      ATB ID      | %s |" % ("Location within trace buffer content".center(slots, " "))
    print "+------------------+<0%s>+" % (formTraceSizeString(captureSize).rjust(slots-1,"-"))
    # Get the map of ATB IDs to the bit set of 'present in buffer' data
    # each bit of which covers a bucketSize chunk of trace data
    dataPresence = captureDevice.getTraceSearch().getSourceDataPresence(
        0, captureSize, bucketSize)
    # Now process the map one ATB ID at a time
    for atbID in dataPresence.keySet():
        traceSource = findDTSLTraceSourceForATBID(
            captureDevice, atbID)
        if traceSource is None:
            sourceName = "%d" % atbID
        else:
            sourceName = "%s[%d]" % (
                traceSource.getName(), atbID)
        sourceMapEntries = formSourceMapEntriesString(
            slots, dataPresence.get(atbID))
        print "| %16s | %s |" % (sourceName.center(16), sourceMapEntries)
    print "+------------------+-%s-+" % ("".rjust(slots, "-"))


if __name__ == "__main__":
#    pydevd.settrace(stdoutToServer=True, stderrToServer=True)
    try:
        runFromDS5 = detectDS5()
        options = ProgramOptions("tracestats", VERSION, runFromDS5)
        if not options.processOptions():
            raise ProgramException(
                "Failed to process options")
        dtsl = None
        try:
            if runFromDS5:
                dtsl = getDS5DTSL()
            else:
                setupLogging()
                dtsl = createConnectedDTSL(options)
            dtslConfiguration = dtsl.getConfiguration()
            showDTSLTraceCaptureDevices(dtslConfiguration)
            showDTSLTraceSourcesForCaptureDevice(
                dtslConfiguration, options.getCaptureDevice())
            captureDevice = getDTSLTraceCaptureDevice(
                dtslConfiguration, options.getCaptureDevice())
            if captureDevice is not None:
                if captureDevice.isActive():
                    captureDevice.stop()
                progress = Progress(options.getQuiet())
                progress.setOutputSupportsCR(not runFromDS5)
                if options.getFullAnalysis():
                    doFullTraceAnalysis(captureDevice, progress)
                else:
                    doQuickTraceAnalysis(captureDevice, progress)
        finally:
            if not runFromDS5 and dtsl is not None:
                dtsl.disconnect()
    except RDDIException, eRDDI:
        showRDDIException(eRDDI)
    except DTSLException, eDTSL:
        showDTSLException(eDTSL)
    except ProgramException, eProgram:
        showProgramException(eProgram)
    except PyException, e:
        showJythonException(e)
    except RuntimeError, e:
        print >> sys.stderr, e
