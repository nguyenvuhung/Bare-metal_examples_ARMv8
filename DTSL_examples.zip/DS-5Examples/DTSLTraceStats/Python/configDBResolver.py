import java.io
import os

from com.arm.debug.configdatabase import ConfigDatabase
from com.arm.debug.configdatabase.interfaces import ConfigDatabaseException


def getCDBPlatform(configDBLocations, manufacturer, board):
    ''' Returns a config database Platform object for the specified platform
    Parameters:
        configDBLocations
            a ';' separated list of file paths which point to the
            root entries for DS-5 configuration databases.
        manufacturer
            the name of the manufacturer as specified in by the
            configdb folder name (below Boards) e.g. "pandaboard.org"
        board
            the board name as specified by the configdb folder name within
            the manufacturer folder e.g. "OMAP_4430"
    Returns:
        the com.arm.debug.configdatabase object and
        the com.arm.debug.configdatabase.internal.Platform object
    '''
    locations = configDBLocations.split(os.pathsep)
    try:
        cdb = ConfigDatabase(
                None,
                [java.io.File(r) for r in locations])
        pname = cdb.getPlatformName(manufacturer, board)
    except ConfigDatabaseException, e:
        raise RuntimeError(
                "Could not find the configdb entry for %s, %s\nError was: %s" %
                (manufacturer, board, e.getMessage()))
    return cdb, cdb.getPlatform(pname)

def resolvePath(cdb, platform, path):
    ''' Resolves a CDB:// file path to its absolute location
    Parameters:
        platform
            the configdb platform entry object
        path
            the path to be resolved
    Returns:
        the absolute location of the path. If the path cannot be resolved to
        an existing file, or the file is not located within the configdb, the 
        returned path is identical to the input path
    '''
    # Config database specifies paths relative to board's entry with CDB:// prefix
    spath = path.strip()
    rFile = cdb.resolveFile(platform, spath)
    if rFile != None:
        path = rFile.getAbsolutePath()
    return path

def resolveConfigdbPath(configDBLocations, manufacturer, board, pathToResolve):
    ''' Resolves a configdb file path for the specified platform
    Parameters:
        configDBLocations
            a ';' separated list of file paths which point to the
            root entries for DS-5 configuration databases.
        manufacturer
            the name of the manufacturer as specified in by the
            configdb folder name (below Boards) e.g. "pandaboard.org"
        board
            the board name as specified by the configdb folder name within
            the manufacturer folder e.g. "OMAP_4430"
        pathToResolve - the path to be resolved into afully qualified path
    Returns:
        a fully qualified file path
    '''
    cdb, platform = getCDBPlatform(configDBLocations, manufacturer, board)
    return resolvePath(cdb, platform, pathToResolve)

def getActivityParameters(platform, debugOperation, connectionType):
    '''Gets the set of parameters for a platform debug operation
    Parameters:
        platform - the configdb com.arm.debug.configdatabase.internal.Platform
                   object
        debugOperation
            the activity name (see project_types.xml) for the
            bare metal debug operation
            e.g. "Debug Cortex-A9_0 via DSTREAM/RVI"
        connectionType
            the type of target connection we make
            e.g. "DSTREAM/RVI" or "ULINK2" ....
    Returns:
        a dictionary of parameters names and values. If no matching 
        debug operation is found, an empty dictionary is returned 
    '''
    params = {}
    executionEnvironmentNames = platform.getExecutionEnvironments()
    for execEnvName in executionEnvironmentNames:
        execEnv = platform.getExecutionEnvironment(execEnvName)
        for activity in execEnv.getActivities():
            if activity.getName() == debugOperation:
                if activity.getConnectionType() == connectionType:
                    for p in execEnv.getParameters():
                        params[p.getID()] = p
                    for p in activity.getParameters():
                        params[p.getID()] = p
                    params["coreName"] = activity.getCoreID()
                    return params
    return params

def getConfigDBParameters(configDBLocations, manufacturer, board, debugOperation, connectionType):
    ''' Retrieves the rvc file and DTSL script information for the specified platform
    Parameters:
        configDBLocations
            a ';' separated list of file paths which point to the
            root entries for DS-5 configuration databases.
        manufacturer
            the name of the manufacturer as specified in by the
            configdb folder name (below Boards) e.g. "pandaboard.org"
        board
            the board name as specified by the configdb folder name within
            the manufacturer folder e.g. "OMAP_4430"
        debugOperation
            the activity name (see project_types.xml) for the
            bare metal debug operation
            e.g. "Debug Cortex-A9_0 via DSTREAM/RVI"
        connectionType
            the type of target connection we make
            e.g. "DSTREAM/RVI" or "ULINK2" ....
    Returns:
        a parameter list containing entries for:
            params["rddiConfigFile"]
            params["dtslScript"]
            params["dtslClass"]
            params["device"]
            params["traceCaptureOption"]
    '''
    cdb, platform = getCDBPlatform(configDBLocations, manufacturer, board)
    platform.setProjectType("Bare Metal Debug") # this is assumed in this example
    params = getActivityParameters(platform, debugOperation, connectionType)
    if len(params) == 0:
        raise RuntimeError(
            "Could not locate the bare metal debug operation '%s' for %s, %s, %s" %
            (debugOperation, manufacturer, board, connectionType))
    # Extract the parameters we are interested in
    rvcFile = None
    dtslScript = None
    dtslConfig = None
    traceCaptureOption = None
    coreName = None
    if params.has_key("config_file"):
        rvcFile = params["config_file"].getDefaultValue()
    if params.has_key("dtsl_config_script"):
        dtslScript = params["dtsl_config_script"].getDefaultValue()
    if params.has_key("dtsl_config"):
        dtslConfig = params["dtsl_config"].getDefaultValue()
    if params.has_key("dtsl_tracecapture_option"):
        traceCaptureOption = params["dtsl_tracecapture_option"].getDefaultValue()
    if params.has_key("coreName"):
        coreName = params["coreName"]
    params.clear()
    # Map the database parameters to the program options of the same name
    if rvcFile:
        rvcFile = resolvePath(cdb, platform, rvcFile)
        params["rddiConfigFile"] = rvcFile
    if dtslScript:
        dtslScript = resolvePath(cdb, platform, dtslScript)
        params["dtslScript"] = dtslScript
    if dtslConfig:
        params["dtslClass"] = dtslConfig
    if coreName:
        params["device"] = coreName
    if traceCaptureOption:
        params["traceCaptureOption"] = traceCaptureOption
    return params
