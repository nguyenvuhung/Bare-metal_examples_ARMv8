"""
Module to process command line options
"""
from optparse import OptionParser
from java.lang import System
from dtslconfigdata import DTSLConfigData
import sys
import os


class ProgramOptions(object):
    """
    Parses command line options and provides configuration data to the
    main program
    """
    CDB32_WIN = "C:\\Program Files (x86)\\DS-5 v5.22.0\\sw\\debugger\\configdb"
    CDB64_WIN = "C:\\Program Files\\DS-5 v5.22.0\\sw\\debugger\\configdb"

    BAD_OPTIONS = -1

    def __init__(self, programName, version, runFromDS5):
        """
        Constructor
        Params:
            programName - the name of the program we show when asked for help
            version - string form of the program version
            runFromDS5 - True if we have been invoked from DS-5, False if
                         invoked as a standalone program
        """
        self.programName = programName
        self.version = version
        self.captureDevice = None
        self.runFromDS5 = runFromDS5
        self.dtslConfigData = DTSLConfigData()
        self.manufacturer = None
        self.board = None
        self.rddiConfigFile = None
        self.debugOperation = None
        self.connectionType = None
        self.configDBLocations = None
        self.connectionAddress = None
        self.workspace = None
        self.dtslScript = None
        self.dtslClass = None
        self.dtslOptions = None
        self.quiet = None
        self.deepAnalysis = False
        # On Windows we try to setup some defaults
        if self.runningOnWindows():
            if os.path.isdir(ProgramOptions.CDB32_WIN):
                self.configDBLocations = ProgramOptions.CDB32_WIN
            elif os.path.isdir(ProgramOptions.CDB64_WIN):
                self.configDBLocations = ProgramOptions.CDB64_WIN
            homeDir = os.path.expanduser('~')
            posWorkspace = "%s\\My Documents\\DS-5 Workspace" % (homeDir)
            if os.path.isdir(posWorkspace):
                self.workspace = posWorkspace
            posWorkspace = "%s\\Documents\\DS-5 Workspace" % (homeDir)
            if os.path.isdir(posWorkspace):
                self.workspace = posWorkspace

    def runningOnWindows(self):
        os_name = System.getProperty("os.name")
        return os_name.startswith("Windows")

    def checkOptions(self):
        rCode = True
        return rCode

    def processOptions(self):
        """ Processes command line option """
        # Construct option specifications
        parser = OptionParser(
            usage=("usage: %s [options] (use --help to see full "
                   "option list)") % self.programName,
            version="%s %s" % (self.programName, self.version),
            description="Trace buffer source analyser")
        parser.add_option("-d", "--capture-device", 
            action="store", type="string",
            dest="captureDevice", default="DSTREAM",
            help="the trace capture device name")
        parser.add_option("-f", "--full-analysis", 
            action="store_true",
            dest="fullAnalysis", default=False,
            help="analyse for ATB IDs _and_ quantity")
        parser.add_option("-q", "--quiet", 
            action="store_true",
            dest="quiet", default=False,
            help="turns off the progress display")
        if not self.runFromDS5:
            parser.add_option("-m", "--manufacturer", 
                action="store", type="string", dest="manufacturer", 
                default=None,
                help="the DS-5 configdb board manufacturer")
            parser.add_option("-b", "--board", 
                action="store", type="string",
                dest="board", default=None,
                help="the DS-5 configdb board name")
            parser.add_option("-o", "--debugOperation", 
                action="store", type="string",
                dest="debugOperation", default=None,
                help="the DS-5 debug operation (from project_types.xml)")
            parser.add_option("-y", "--connectionType", 
                action="store", type="string",
                dest="connectionType", default=None,
                help="the connection type (from project_types.xml)")
            parser.add_option("-c", "--configdb", 
                action="store", type="string",
                dest="configdb", default=None,
                help="the ; separated list of root configdb locations")
            parser.add_option("-k", "--dtslOptions", 
                action="store", type="string",
                dest="dtslOptions", default=None,
                help="the name of the DTSL option set")
            parser.add_option("-n", "--connectionAddress", 
                action="store", type="string",
                dest="connectionAddress", default="USB",
                help="the device to connect to e.g. TCP:MyDSTREAM or USB")
        # Process all supplied options
        options = parser.parse_args()[0]
        # Extract any supplied options into our local values
        if not self.runFromDS5:
            import configDBResolver
            if options.configdb != None:
                self.configDBLocations = options.configdb
            if options.manufacturer != None:
                self.manufacturer = options.manufacturer
            if options.board != None:
                self.board = options.board
            if options.debugOperation != None:
                self.debugOperation = options.debugOperation
            if options.connectionType != None:
                self.connectionType = options.connectionType
            if options.connectionAddress != None:
                self.connectionAddress = options.connectionAddress
            if options.dtslOptions != None:
                self.dtslOptions = options.dtslOptions
            # If user specified DS-5 configdb datacaptureDevice
            print "Getting connection parameters from configdb ...",
            params = configDBResolver.getConfigDBParameters(
                        self.configDBLocations,
                        self.manufacturer,
                        self.board,
                        self.debugOperation,
                        self.connectionType)
            if "rddiConfigFile" in params:
                self.rddiConfigFile = params["rddiConfigFile"]
            if "dtslScript" in params:
                self.dtslScript = params["dtslScript"]
            if "dtslClass" in params:
                self.dtslClass = params["dtslClass"]
            print "done"
            # Populate the dtslConfigData object with what we have harvested
            self.dtslConfigData.setRDDIConfigurationFile(self.rddiConfigFile)
            self.dtslConfigData.setDTSLScript(self.dtslScript)
            self.dtslConfigData.setDTSLClass(self.dtslClass)
            self.dtslConfigData.setDTSLOptionsFile(self.dtslOptions)
            self.dtslConfigData.setConnectionType(self.connectionType)
            self.dtslConfigData.setConnectionAddress(self.connectionAddress)
            # Check we have enough configuration data
            isComplete, whatsMissing = self.dtslConfigData.isConfigComplete()
            if not isComplete:
                print >> sys.stderr, (
                    "Not enough configuration data has been given:")
                print >> sys.stderr, whatsMissing
                parser.print_usage()
                sys.exit(ProgramOptions.BAD_OPTIONS)
        # Extract any supplied options into our local values
        if options.captureDevice is not None:
            self.captureDevice = options.captureDevice
        if options.quiet is not None:
            self.quiet = options.quiet
        if options.fullAnalysis is not None:
            self.fullAnalysis = options.fullAnalysis
        return self.checkOptions()

    def getCaptureDevice(self):
        return self.captureDevice

    def getQuiet(self):
        return self.quiet

    def getDTSLConfigData(self):
        return self.dtslConfigData

    def getFullAnalysis(self):
        return self.fullAnalysis
