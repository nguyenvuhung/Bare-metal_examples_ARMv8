DTSL Jython Example
-------------------

This is an example of how to process trace data using DTSL.

This uses DTSL to create a trace processing pipeline which identifies all 
ATB ID sources within the trace capture device.

This example can be run either stand alone or within a DS-5 debug session.

Running the example
-------------------

Within a DS-5 Debug session:
Just drag the main DTSLTraceStats.py file onto the backdrop of the debugger's
command view (NOT the command box itself). This should then fill the command box
with the correct command to get the script run. You then need to append any 
parameters the program might require.

e.g. 
source "DTSLTraceStats\Python\DTSLTraceStats.py" -h
Usage: tracestats [options] (use --help to see full option list)

Trace buffer source analyser

Options:
  --version             show program's version number and exit
  -h, --help            show this help message and exit
  -d CAPTUREDEVICE, --capture-device=CAPTUREDEVICE
                        the trace capture device name
  -f, --full-analysis   analyse for ATB IDs _and_ quantity
  -q, --quiet           turns off the progress display

e.g.
source "DTSLTraceStats\Python\DTSLTraceStats.py" -d DSTREAM

Alternatively, the example can be run from within DS-5 using the Jython run configuration 
DTSLTraceStats.launch.


Outside of DS-5:
The example is run by starting the tracestats shell script file or the 
tracestats.bat batch file. However before you run it you must edit the file
and change the program parameters to suite the target system you are connecting
to. Also before you run it make sure you have edited the ../DTSL/dtslsetup.bat batch
file or the ../DTSL/dtslsetup bash script to setup the correct environment.

