#
# Copyright (C) 2012 ARM Limited. All rights reserved.
#
# DS-5 Debugger Jython script example
#
# Calculates md5 hash of some data in memory
#
# Parameters:
#     1: address
#     2: length in bytes
#     3: -0  (i.e. dash 0, optional) calculate hash up to (but excluding) 0 byte
#            this is useful for zero-terminated strings
#
# Usage:
#     source /some/path/memhash.py '$PC' 5000
#     source /some/path/memhash.py '0x8000' 5000
#     source /some/path/memhash.py '$R0' 10000 -0

import hashlib
import sys

from arm_ds.debugger_v1 import Debugger
from arm_ds.debugger_v1 import DebugException


debugger = Debugger()

# process arguments
if not len(sys.argv) >= 3:
    print "Wrong number of arguments!"
    sys.exit()
address = sys.argv[1]
length = int(sys.argv[2])
if len(sys.argv) >= 4 and sys.argv[3]=='-0':
    zero_term = True
else:
    zero_term = False


# read memory in 'buffer' size chunks and calculate md5
buffer = 1000 # bytes
m = hashlib.md5()
print "Reading memory..."
ec = debugger.getExecutionContext(0)
actual_len = 0
for i in range(0, length, buffer):
    chunk = ec.getMemoryService().read(address, min(buffer, length))

    found_end = False
    if zero_term:
        end = 0
        for b in chunk:
            if b == 0:
                found_end = True
                break
            end += 1

        chunk = chunk[:end]

    actual_len += len(chunk)

    m.update(chunk)

    if found_end:
        break

print "Read " + str(actual_len) + " bytes of memory starting from address " + address
print "MD5 hash is: " + m.hexdigest()
