#
# Copyright (C) 2012 ARM Limited. All rights reserved.
#
# DS-5 Debugger Jython script example
#
# Prints custom formatted program state information
#
# Parameters:
#     1: stack frame limit (optional, default 3; -1 means unlimited)
#
# Usage:
#     source /some/path/infostate.py
#     source /some/path/infostate.py 10
#     source /some/path/infostate.py -1    # i.e. no limit on stack frames to print.


import sys

from arm_ds.debugger_v1 import Debugger
from arm_ds.debugger_v1 import DebugException


debugger = Debugger()

# process arguments
if len(sys.argv) >= 2:
    stack_limit = int(sys.argv[1])
else:
    stack_limit = 3

INDENT = "    "
LEVEL_FORMAT = "%2d  " # instead of one indent to print numbers of frames and execution contexts
ind = 0


def IND(cnt = -1):
    """Returns indentation string at the point when called."""
    global INDENT
    global ind
    if cnt == -1: cnt = ind
    if cnt == 0: return ""
    return INDENT + IND(cnt-1)


def print_where_am_i(ec_or_frame):
    """Prints list of source locations corresponding to the program address of
    the given stack frame or the top level stack frame of given execution context
    """
    if hasattr(ec_or_frame, 'getExecutionContext'):
        # it is a stack frame
        ec = ec_or_frame.getExecutionContext()
        pa = ec_or_frame.getProgramAddress()
    else:
        # it is an execution context
        ec = ec_or_frame
        pa = ec.getTopLevelStackFrame().getProgramAddress()
    
    print IND() + str(ec.getSourceService().getSourceLocations(pa))


def print_core_registers(ec_or_frame):
    """Print registers for given stack frame or execution context.
    Optionally filtered by starts_with for qualified register names.
    """
    registers = ec_or_frame.getRegisterService().getRegisterNames()
    registers = filter(lambda name: name.startswith("Core::R"), registers)
    values = [register_value(ec_or_frame, name)
              for name in registers]

    print IND() + ", ".join(map(lambda name,value: "%s=%s" % (name[6:],str(value)), registers, values))


def register_value(frame, name):
    # R0-R3, R12, LR & CPSR may only really be valid at the top stack frame
    try:
        return frame.getRegisterService().getValue(name)
    except DebugException, je:
        # In case the error code changes, use print je.getErrorCode()
        if je.getErrorCode() == "TAB183":
            return "-"
        else:
            raise


print "State information"
print "================="
print IND() + "Number of execution contexts: %d" % debugger.getExecutionContextCount()
print IND() + INDENT + "Name, Identifier, Kind, State, isScheduled"
for i in range(debugger.getExecutionContextCount()):
    # Refer to internal.py for possible values and meaning of getKind(), etc
    ec = debugger.getExecutionContext(i)
    print IND() + LEVEL_FORMAT%i + "%s, %s, %s, %s, %s" % (ec.getName(),
                                                           ec.getIdentifier(),
                                                           ec.getKind(),
                                                           ec.getState(),
                                                           ec.isScheduledContext())
    ind += 1
    if stack_limit > 0 or stack_limit == -1:
        print IND() + "Stack:"
        frames_seen = 0
        frame = ec.getTopLevelStackFrame()

        ind += 1
        while frame and (frames_seen < stack_limit or stack_limit == -1):
            # print stack frame info
            rs = frame.getRegisterService()
            pA = frame.getProgramAddress()
            level = frame.getLevel()

            # print registers
            vals_formatted = ""
            if frames_seen == 0:
                vals = (frame.getProgramAddress(), rs.getValue("PC"), rs.getValue("SP"), rs.getValue("LR"), rs.getValue("CPSR"))
                vals_formatted = "pA:%s, PC:%s, SP:%s, LR:%s, CPSR:%s" % vals
            else:
                vals = (frame.getProgramAddress(), rs.getValue("PC"), rs.getValue("SP"))
                vals_formatted = "pA:%s, PC:%s, SP:%s" % vals
            print IND() + LEVEL_FORMAT % level + vals_formatted
            # getProgramAddress() and getValue("PC") are similar but different:
            #   getValue("PC") returns the value of PC e.g. 0x8000, whereas
            #   getProgramAddress() returns the memory space too, if appropriate e.g. S:0x8000
            # fully-qualified register names e.g. getValue("Core::LR") could equally well be used

            ind += 1
            print_core_registers(frame)
            
            # print source locations
            print_where_am_i(frame)
    
            # print disassembly
            before = 2
            after = 3
            for i,instr in enumerate(ec.getDisassembleService().disassemble(pA, bw=before, fw=after)):
                now = "*" if i == before else ""
                print IND() + "%s%d%s\t%s" % (now, i, now, instr)
                
            ind -= 1
            
            # get next frame
            frame = frame.next()
            frames_seen += 1
            
        ind -= 1
            
    ind -= 1
    
ind -=1
