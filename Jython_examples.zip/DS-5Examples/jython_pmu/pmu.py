# Performance Monitor Unit (PMU) Analyzer
# DS-5 Debugger Jython script example
# Copyright (C) 2013 ARM Limited. All rights reserved.

import sys

from arm_ds.debugger_v1 import Debugger
from arm_ds.debugger_v1 import DebugException

# Script version
version = '5.18'

# Config written by the parameter parser
config = {'command':            [],
          'start':              0,
          'end':                0,
          'events':             0,
          'cpu':                0 }

Event_List = {}

CortexA15_Events = {    'SW_INCR': 0x00,
                        'L1I_CACHE_REFILL': 0x01,
                        'L1I_TLB_REFILL': 0x02,
                        'L1D_CACHE_REFILL': 0x03,
                        'L1D_CACHE': 0x04,
                        'L1D_TLB_REFILL': 0x05,
                        'INST_RETIRED': 0x08,
                        'EXC_TAKEN': 0x09,
                        'EXC_RETURN': 0x0A,
                        'CID_WRITE_RETIRED': 0x0B,
                        'BR_MIS_PRED': 0x10,
                        'CPU_CYCLES': 0x11,
                        'BR_PRED': 0x12,
                        'MEM_ACCESS': 0x13,
                        'L1I_CACHE': 0x14,
                        'L1D_CACHE_WB': 0x15,
                        'L2D_CACHE': 0x16,
                        'L2D_CACHE_REFILL': 0x17,
                        'L2D_CACHE_WB': 0x18,
                        'BUS_ACCESS': 0x19,
                        'MEMORY_ERROR': 0x1A,
                        'INST_SPEC': 0x1B,
                        'TTBR_WRITE_RETIRED': 0x1C,
                        'BUS_CYCLES': 0x1D,
                        'L1D_CACHE_LD': 0x40,
                        'L1D_CACHE_ST': 0x41,
                        'L1D_CACHE_REFILL_LD': 0x42,
                        'L1D_CACHE_REFILL_ST': 0x43,
                        'L1D_CACHE_WB_VICTIM': 0x46,
                        'L1D_CACHE_WB_CLEAN': 0x47,
                        'L1D_CACHE_INVAL': 0x48,
                        'L1D_TLB_REFILL_LD': 0x4C,
                        'L1D_TLB_REFILL_ST': 0x4D,
                        'L2D_CACHE_LD': 0x50,
                        'L2D_CACHE_ST': 0x51,
                        'L2D_CACHE_REFILL_LD': 0x52,
                        'L2D_CACHE_REFILL_ST': 0x53,
                        'L2D_CACHE_WB_VICTIM': 0x56,
                        'L2D_CACHE_WB_CLEAN': 0x57,
                        'L2D_CACHE_INVAL': 0x58,
                        'BUS_ACCESS_LD': 0x60,
                        'BUS_ACCESS_ST': 0x61,
                        'BUS_ACCESS_SHARED': 0x62,
                        'BUS_ACCESS_NOT_SHARED': 0x63,
                        'BUS_ACCESS_NORMAL': 0x64,
                        'BUS_ACCESS_PERIPH': 0x65,
                        'MEM_ACCESS_LD': 0x66,
                        'MEM_ACCESS_ST': 0x67,
                        'UNALIGNED_LD_SPEC': 0x68,
                        'UNALIGNED_ST_SPEC': 0x69,
                        'UNALIGNED_LDST_SPEC': 0x6A,
                        'LDREX_SPEC': 0x6C,
                        'STREX_PASS_SPEC': 0x6D,
                        'STREX_FAIL_SPEC': 0x6E,
                        'LD_SPEC': 0x70,
                        'ST_SPEC': 0x71,
                        'LDST_SPEC': 0x72,
                        'DP_SPEC': 0x73,
                        'ASE_SPEC': 0x74,
                        'VFP_SPEC': 0x75,
                        'PC_WRITE_SPEC': 0x76,
                        'BR_IMMED_SPEC': 0x78,
                        'BR_RETURN_SPEC': 0x79,
                        'BR_INDIRECT_SPEC': 0x7A,
                        'ISB_SPEC': 0x7C,
                        'DSB_SPEC': 0x7D,
                        'DMB_SPEC': 0x7E
                         }


def enable_pmu(ec):
       
    pmcr = long(ec.getRegisterService().getValue("CP15_PMCR"))
    pmcr = pmcr | 0x01
    ec.getRegisterService().setValue("CP15_PMCR", pmcr)
    
def disable_pmu(ec):
       
    pmcr = long(ec.getRegisterService().getValue("CP15_PMCR"))
    pmcr &= ~(0x01)
    ec.getRegisterService().setValue("CP15_PMCR", pmcr)
    
def reset_ccnt(ec):
    
    pmcr = long(ec.getRegisterService().getValue("CP15_PMCR"))
    pmcr = pmcr | 0x04
    ec.getRegisterService().setValue("CP15_PMCR", pmcr)

def enable_ccnt(ec):
    
    pmcntenset = long(0x80000000)
    ec.getRegisterService().setValue("CP15_PMCNTENSET", pmcntenset)
    
def disable_ccnt(ec):
    
    pmcntenclr = long(0x80000000)
    ec.getRegisterService().setValue("CP15_PMCNTENCLR", pmcntenclr)    
    
def read_ccnt(ec):
    
    pmccnt = long(ec.getRegisterService().getValue("CP15_PMCCNTR"))
    return pmccnt

def ccnt_divider_enable(ec):
    
    pmcr = long(ec.getRegisterService().getValue("CP15_PMCR"))
    pmcr = pmcr | 0x08
    ec.getRegisterService().setValue("CP15_PMCR", pmcr)

def ccnt_divider_disable(ec):

    pmcr = long(ec.getRegisterService().getValue("CP15_PMCR"))
    pmcr &= ~(0x08)
    ec.getRegisterService().setValue("CP15_PMCR", pmcr)

def get_pmn(ec):

    pmn = long(ec.getRegisterService().getValue("CP15_PMCR"))
    pmn = ((pmn >> 11) & 0x1F)
    return pmn

def pmn_config(ec, counter, event):
    
    counter = long(counter & 0x1F)
    ec.getRegisterService().setValue("CP15_PMSELR", counter)
    ec.getRegisterService().setValue("CP15_PMXEVTYPER", event)

def enable_pmn(ec, counter):

    bit = 1 << long(counter)
    ec.getRegisterService().setValue("CP15_PMCNTENSET", bit)

def disable_pmn(ec, counter):

    bit = 1 << long(counter)
    ec.getRegisterService().setValue("CP15_PMCNTENCLR", bit)

def read_pmn(ec, counter):

    counter = long(counter & 0x1F)
    ec.getRegisterService().setValue("CP15_PMSELR", counter)
    pmn = long(ec.getRegisterService().getValue("CP15_PMXEVCNTR"))
    return pmn

def read_flag(ec, counter):
    
    temp = long(ec.getRegisterService().getValue("CP15_PMOVSSET"))
    flag = (temp>>counter) & 0x1
    return flag
    
def reset_pmn(ec):
    
    pmcr = long(ec.getRegisterService().getValue("CP15_PMCR"))
    pmcr = pmcr | 0x02
    ec.getRegisterService().setValue("CP15_PMCR", pmcr)
    
def pmu_user_mode_enable(ec):
    
    pmuseren = long(ec.getRegisterService().getValue("CP15_PMUSERENR"))
    pmuseren = pmuseren | 0x01
    ec.getRegisterService().setValue("CP15_PMUSERENR", pmuseren)
    
def pmu_user_mode_disable(ec):
    
    pmuseren = long(ec.getRegisterService().getValue("CP15_PMUSERENR"))
    pmuseren &= ~(0x01)
    ec.getRegisterService().setValue("CP15_PMUSERENR", pmuseren)


def get_cpu(ec):
    '''Check supported CPU'''
    global config
    global Event_List
    
    try:
        cpu = long(ec.getRegisterService().getValue("CP15_ID.Primary_part_number"))
    except:
        try:
            cpu = long(ec.getRegisterService().getValue("CP15_MIDR.Primary_part_number"))
        except:
            try:
                cpu = long(ec.getRegisterService().getValue("CP15_MIDR.Primary"))
            except:
                print "PMU : Error at detecting the CPU"
                cpu = 0
    
    if cpu == 0xc07:
        config['cpu'] = "Cortex-A7"
        print "PMU : CPU not supported (Part Number:%s)" % hex(cpu)
        return 0
    elif cpu == 0xc08:
        config['cpu'] = "Cortex-A8"
        print "PMU : CPU not supported (Part Number:%s)" % hex(cpu)
        return 0
    elif cpu == 0xc09:
        config['cpu'] = "Cortex-A9"
        print "PMU : CPU not supported (Part Number:%s)" % hex(cpu)
        return 0
    elif cpu == 0xc05:
        config['cpu'] = "Cortex-A5"
        print "PMU : CPU not supported (Part Number:%s)" % hex(cpu)
        return 0
    elif cpu == 0xc0f:
        config['cpu'] = "Cortex-A15"
        Event_List = CortexA15_Events
    else:
        print "PMU : CPU not supported (Part Number:%s)" % hex(cpu)
        return 0
    
    return 1

def print_events():
    
    for index in Event_List:
        print index
    
    
def print_help():
    '''Print the user help'''
    
    print "Performance Monitor Unit (PMU) Analyzer v%s" % version
    print "Usage: pmu [options]"
    print "Options:"
    print "-range        Address range e.g. 0x8000000 0x81000000"
    print "-func         Name of function e.g. main (symbols must first be loaded into DS-5 Debugger)"
    print "-c            Enable Cycle Counter (CCNT)"
    print "-e            Events to monitor e.g. CPU_CYCLES,MEM_ACCESS"
    print "-u            Enable User mode access to PMU (must be executed in a privileged mode)"
    print "-d            Enable CCNT divider 1/64"
    print "-l            List available events for current target"
    print "-h            Print this help"
    
def parse_params():
    '''Look for parameters and set internal config'''

    if len(sys.argv) < 2:
        return 0    # no parameters

    global config
    i = 1

    while (i < (len(sys.argv))):

        temp = sys.argv[i]
        if len(temp) < 2:
            return 0

        if temp[:2] == '-l':

            config['command'].append('l')

        elif temp[:2] == '-c':

            config['command'].append('c')

        elif temp[:2] == '-u':

            config['command'].append('u')

        elif temp[:2] == '-d':

            config['command'].append('d')

        elif temp[:2] == '-e':

            config['command'].append('e')

            if (i+1 < (len(sys.argv))):
                config['events'] = str(sys.argv[i+1])
            else:
                return 0

        elif temp[:2] == '-h':

            config['command'].append('h')
            return 0            

        elif temp[:6] == '-range':

            config['command'].append('r')

            if (i+1 < (len(sys.argv))):
                config['start'] = sys.argv[i+1]
            else:
                return 0

            i += 1

            if (i+1 < (len(sys.argv))):
                config['end'] = sys.argv[i+1]
            else:
                return 0

        elif temp[:5]  == '-func':

            config['command'].append('f')

            if (i+1 < (len(sys.argv))):
                config['start'] = sys.argv[i+1]
            else:
                return 0

        i += 1

    return 1 # success

def main():

    # Debugger object for accessing the debugger
    debugger = Debugger()

    # Ensure target is stopped
    ec = debugger.getCurrentExecutionContext()
    ec.getExecutionService().stop()

    # in case the execution context reference is out of date
    ec = debugger.getCurrentExecutionContext()

    if (parse_params() == 0):
        print_help()
        return

    print "Performance Monitor Unit (PMU) Analyzer v%s" % version

    if (get_cpu(ec) == 0):
        print "PMU : Processor not supported... "
        return
    else:
        print "PMU : Current processor: %s" % config['cpu']

    for command in config['command']:

        if command == 'h':
            print_help()
            return
       
        if command == 'l':
            print_events()
            return
        
        if command == 'u':
            print 'PMU : Enabling User mode access to the PMU...'
            pmu_user_mode_enable(ec)
            
        if command == 'r':
            print 'PMU : Running to breakpoint at starting address...'
            ec.getExecutionService().resumeTo(config['start'])
            ec.getExecutionService().waitForStop()

        if command == 'f':             
            try: 
                temp = '&' + config['start']
                config['start'] = long(ec.getVariableService().readValue(temp))
            except:
                print 'PMU : Symbol %s does not exist!' % config['start']
                return
             
            print 'PMU : Running to breakpoint at starting address...'
            ec.getExecutionService().resumeTo(config['start'])
            ec.getExecutionService().waitForStop()
            config['end'] = long(ec.getRegisterService().getValue("LR"))

    for command in config['command']:
        
        if command == 'c':
        
            if config['command'].count('d') != 0:        
                print 'PMU : Enabling CCNT divider...'
                ccnt_divider_enable(ec) 
                        
            print 'PMU : Resetting CCNT...'
            reset_ccnt(ec)
            print 'PMU : Enabling CCNT...'
            enable_ccnt(ec)

        if command == 'e':
            
            events = str(config['events'])
            events = events.split(',')
            counters = long(get_pmn(ec))
  
            if(len(events) > counters):
                
                print 'PMU : You have entered too many events, this target only supports %i counters' % counters
                return
            
            print 'PMU : Resetting PMN:...'
            reset_pmn(ec)  
            
            for index in range(len(events)):
                try:
                    print 'PMU : Configuring PMN Counter %i with event %s...' % (index, events[index])
                    pmn_config(ec, index, long(Event_List[events[index]]))
                    print 'PMU : Enabling PMN Counter %i with event %s...' % (index, events[index])
                    enable_pmn(ec, index)
                except: 
                    print 'PMU : The event %s is not a recognised event...' % (events[index])
                    print 'PMU : Please use one of the following events:...'
                    print_events()
                    return
                         
    print 'PMU : Enabling PMU...'
    enable_pmu(ec) 
    print 'PMU : Running to breakpoint at stopping address...'
    ec.getExecutionService().resumeTo(config['end'])
    ec.getExecutionService().waitForStop()

    for command in config['command']:

        if command  == 'c':  
            
            print 'PMU : Disabling CCNT...'
            disable_ccnt(ec)
            
            if config['command'].count('d') != 0:        
                print 'PMU : Disabling CCNT divider...'
                ccnt_divider_disable(ec) 
                   
            print 'PMU : Reading CCNT...'
            ccnt = long(read_ccnt(ec))
            
            print 'PMU : Checking CCNT overflow flag...'
            flag = read_flag(ec,31) 
            
            if flag == 0x1:
                print 'PMU : CCNT overflowed...'
            else:
                print 'PMU : CCNT did NOT overflow...'
            
        if command == 'e':
            
            pmn = []
                        
            for index in range(len(events)):
                
                print 'PMU : Disabling PMN Counter %i...' % index
                disable_pmn(ec, long(index))
                print 'PMU : Reading PMN Counter %i...' % index
                pmn.append(long(read_pmn(ec, index))) 
                
                print 'PMU : Checking PMN Counter %i overflow flag...' % index
                flag = read_flag(ec, index)
                
                if flag == 0x1:
                    print 'PMU : PMN Counter %i overflowed...' % index
                else:
                    print 'PMU : PMN Counter %i did NOT overflow...' % index

    for command in config['command']:
        
        if command  == 'u': 
        
            print 'PMU : Disabling User Mode access to the PMU...'
            pmu_user_mode_disable(ec)
            
                
    print 'PMU : Disabling PMU...'
    disable_pmu(ec) 
    
    for command in config['command']:
        
        if command  == 'c':
            
            print 'PMU : Number of cycles: %i' % ccnt
            
        if command == 'e':
                
            for index in range(len(events)):
                
                print 'PMU : Number of %s events: %i' % (events[index], pmn[index] )

    print 'PMU : Exiting...'
    
if __name__ == '__main__':
    main() 
