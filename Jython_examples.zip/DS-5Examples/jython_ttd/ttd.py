# Translation Table Decoder
# DS-5 Debugger Jython script example
# Copyright (C) 2012-2013 ARM Limited. All rights reserved.

import sys

from arm_ds.debugger_v1 import Debugger
from arm_ds.debugger_v1 import DebugException

# Script version
version = '5.18'

# Config written by the parameter parser
config = {'command':    0,
          'address':    0,
          'symbol':     0,
          'verbose':    0,
          'details':    0,
          'file':       0,
          'cpu':        0 }

# Default Page Table size
TT_SIZE = 4096

def sdf_display_2nd_level_table(ec, address, index_1mb, sp):
    '''Display 2nd level page table'''
    
    len = 256 # 2nd Level table size, fixed to 256 entries
    for n in range(0, len):

        data = sp + str(hex(address+n*4))
        try:
            tt_ivalue = ec.getMemoryService().readMemory32(data)

            if (tt_ivalue & 0x3) == 0: # Ignore Fault pages
                continue

            if (tt_ivalue & 0x2) == 0: # Large page
                print "        - (Large page: 64 KB - entry:%s) Virtual Addr: %s --> Physical Addr: %s" %(hex(long(tt_ivalue)),hex(long(0x00100000*index_1mb+0x00001000*n)),hex(long(tt_ivalue&(~((1<<16)-1)))))
            else:                    # Small page
                print "        - (Small page:  4 KB - entry:%s) Virtual Addr: %s --> Physical Addr: %s" %(hex(long(tt_ivalue)),hex(long(0x00100000*index_1mb+0x00001000*n)),hex(long(tt_ivalue&(~((1<<12)-1)))))

        except:
            print "Error : Memory at address %s is not readable" % data


def sdf_display_entry(ec, tt_entry, index_1mb, sp):
    '''Display 1st level page table'''
 
    # Ignore FAULT access
    tt_type = tt_entry & 3
    if tt_type == 1:

        second_level_table = tt_entry & (~((1<<10)-1))
        print "      * 2nd Page table (address: %s / size: 1 KB - 256 Entries)" % (hex(second_level_table))

        sdf_display_2nd_level_table(ec, second_level_table, index_1mb, sp)
  
    elif tt_type == 2 or tt_type == 3:

        ss = tt_entry & (1<<18)

        if ss==0:
            print "      * (Section page:        1 MB) Virtual Addr: %s --> Physical Addr: %s" %(hex(long(0x00100000*index_1mb)),hex(long(tt_entry&(~((1<<20)-1)))))
        else:         
            print "      * (Super-section page: 16 MB) Virtual Addr: %s --> Physical Addr: %s" %(hex(long(0x00100000*index_1mb)),hex(long(tt_entry&(~((1<<20)-1)))))

def get_address_page_table(ec, tt_address, offset, len, address, sp):
    '''Look for a specific address and print the Translation Table entry.'''

    index_1mb = address >> 20 # get the top bits (1MB section)
               
    data = sp + str(hex(tt_address+index_1mb*4))

    try:
        tt_entry = ec.getMemoryService().readMemory32(data)

        if (tt_entry & 3) == 0: # Ignore Fault pages
            print "Virtual Address: %s - Fault Entry (%s)" %(hex(long(address)),hex(long(tt_entry)))
            return

        if sp == "SP:":
            secure = "Secure Physical Addr:"
        elif sp == "NP:":
            secure = "Non-Secure Physical Addr:"
        else:
            secure = "Physical Addr:"

        print "  + Page Table Entry (%d) = " % (index_1mb) + secure + hex(tt_entry)
        sdf_display_entry(ec, tt_entry, index_1mb, sp)

    except:
        print "Error : Memory at address %s is not readable" % data


def print_address_page_table(ec, tt_address, offset, len, sp):
    '''Prints the Translation Table'''

    for index_1mb in range(offset, len):
          
        data = sp + str(hex(tt_address+index_1mb*4))

        try:
            tt_ivalue = ec.getMemoryService().readMemory32(data)

            if (tt_ivalue & 3) == 0: # Ignore Fault pages
                continue

            if sp == "SP:":
                secure = "Secure Physical Addr:"
            elif sp == "NP:":
                secure = "Non-Secure Physical Addr:"
            else:
                secure = "Physical Addr:"

            print "  + Page Table Entry (%d) = " % (index_1mb) + secure + hex(long(tt_ivalue))
            sdf_display_entry(ec, tt_ivalue, index_1mb, sp)

        except:
            print "Error : Memory at address %s is not readable" % data


def get_sp_config(ec):
    '''Check secure physical state'''

    # When the processor is in Monitor mode, it is always in Secure state, regardless of the value of the NS bit
    if ec.getRegisterService().getValue("CPSR.M") == "MON":
        print "Processor is in Monitor mode, so is in Secure state"
        sp = "SP:"  # Secure Physical access
        return sp

    # Processor is not in Monitor mode, so check the NS bit
    try:
        if config['cpu'] == 0xc08:   # Cortex-A8
            secure = ~(long(ec.getRegisterService().getValue("CP15_SECURE_CONFIGURATION"))) & 0x1
        else: # assume other CPUs have this register
            secure = ~(long(ec.getRegisterService().getValue("CP15_SCR"))) & 0x1
        if secure == 0: # Secure state is not available, but MMU is enabled
            print "Processor is in Non-Secure state"
            sp = "NP:"  # Non-Secure Physical access
        else:
            print "Processor is in Secure state"
            sp = "SP:"  # Secure Physical access
    except:
        print "Secure state is not available on this target"
        sp = "P:"

    return sp

def get_cpu(ec):
    '''Check supported CPU'''
    global config
    
    try:
        cpu = long(ec.getRegisterService().getValue("CP15_ID.Primary_part_number"))
    except:
        try:
            cpu = long(ec.getRegisterService().getValue("CP15_MIDR.Primary_part_number"))
        except:
            try:
                cpu = long(ec.getRegisterService().getValue("CP15_MIDR.Primary"))
            except:
                print "Error : cannot determine the CPU type"
                cpu = 0
    
    if cpu == 0xc08:
        print "CPU Cortex-A8"
    elif cpu == 0xc09:
        print "CPU Cortex-A9"
    elif cpu == 0xc0f:
        print "CPU Cortex-A15"
    else:
        print "CPU not supported (Part Number:%s)" % hex(cpu)

    config['cpu'] = cpu
    
    return cpu 

def get_mmu_state(ec):
    '''Check MMU state'''
    
    try:
        if config['cpu'] == 0xc08:   # Cortex-A8
            mmu = long(ec.getRegisterService().getValue("CP15_CONTROL")) & 0x1 
        else: # assume other CPUs have this register
            mmu = long(ec.getRegisterService().getValue("CP15_SCTLR")) & 0x1 
    except:
        mmu = 0
    
    if mmu == 0:
        print "MMU disabled!"
    
    return mmu 
    
def get_ttbr0_config(ec):
    '''Check TTBR0 registers'''
    
    ttbr_cr = long(ec.getRegisterService().getValue("CP15_TTBCR")) & 0x7
    
    ttbr0 = long(ec.getRegisterService().getValue("CP15_TTBR0")) & ~((1<<(14-ttbr_cr))-1)
    
    print "TTBR0 page table (address: %s / size: %d KB - 4096 Entries)" % (hex(ttbr0),((TT_SIZE>>ttbr_cr)*4/1000))

    return ttbr0, (TT_SIZE>>ttbr_cr) # address, size

def get_ttbr1_config(ec):
    '''Check TTBR1 registers'''   
    
    ttbr_cr = long(ec.getRegisterService().getValue("CP15_TTBCR")) & 0x7

    if ttbr_cr==0:
        ttbr1 = 0
        print "TTBR1 disabled"
        return 0, 0  # address, offset
    else:
        ttbr1 = long(ec.getRegisterService().getValue("CP15_TTBR1")) & ~((1<<(14-ttbr_cr))-1)
        
        # See ARM ARM vC, page 1321
        # Whenever TTBCR.N is nonzero, the size of the translation table addressed by TTBR1 is 16KB ()
        print "TTBR1 page table (address: %s / size: 16 KB - 4096 Entries - only the top %d bytes are used!)" % (hex(ttbr1),128<<(7-ttbr_cr))

        offset = 32 << (7-ttbr_cr) # 32 MB is the minimum offset for TTBR1 
        
        return ttbr1, offset

def print_help():
    '''Print the user help'''
    
    print "Translation Table Decoder v%s" % version
    print "Usage: ttd [options]"
    print "Options:"
    print "-d          dump translation table given by TTBR0/TTBR1 registers"
    print "-a address  dump translation table given by a (virtual) address"
    print "-s symbol   dump translation table given by a symbol name (symbols must first be loaded into DS-5 Debugger)"
    print "-f file     dump data to a text file"
    print "-h          print this help"

def parse_params():
    '''Look for parameters and set internal config'''
    
    if len(sys.argv) < 2:
        return 0    # no parameters
        
    global config
    i = 1
        
    while (i < (len(sys.argv))):
        
        temp = sys.argv[i]
        if len(temp) < 2:
            return 0
                
        if temp[:2] == '-d':
            
            config['command'] = 'd'
            
        elif temp[:2] == '-a':
            
            config['command'] = 'a'
            
            if (i+1 < (len(sys.argv))):
                config['address'] = int(sys.argv[i+1],16)
            else:
                return 0
            
        elif temp[:2] == '-s':
            
            config['command'] = 's'
            
            if (i+1 < (len(sys.argv))):
                config['symbol'] = sys.argv[i+1]
            else:
                return 0
            
        elif temp[:2] == '-f':
                    
            if (i+1 < (len(sys.argv))):
                config['file'] = sys.argv[i+1]
            else:
                return 0
                        
        elif temp[:2] == '-h':
            
            config['command'] = 'h'
            return 0

        i += 1
    return 1 # success
    
def main():
    
    # Debugger object for accessing the debugger
    debugger = Debugger()

    # Ensure target is stopped
    ec = debugger.getCurrentExecutionContext()
    ec.getExecutionService().stop()

    # in case the execution context reference is out of date
    ec = debugger.getCurrentExecutionContext()

    if (parse_params() == 0):
        print_help()
        return
    
    print "Translation Table Decoder v%s" % version
    
    if get_cpu(ec) == 0:
        return # CPU not supported!
    
    if get_mmu_state(ec) == 0:
        return # MMU disabled!
        
    sp = get_sp_config(ec) # check secure physical access
        
    (ttbr1, ttbr1_offset) = get_ttbr1_config(ec)
    
    (ttbr0, ttbr0_size) = get_ttbr0_config(ec)  
      
    ##############################

    if config['file'] != 0:
        print "Data will be exported to file: %s" %(config['file'])
        old_stdout = sys.stdout
        
        try:
            sys.stdout = open(config['file'], 'w')
        except IOError:
            print "Error : Permission denied when creating file '%s'" % config['file']
            return

    if config['command']   == 'd':  # Dump all the page table
        
        if ttbr1 != 0:  # check if TTBR1 is enabled       
            print_address_page_table(ec, ttbr1, ttbr1_offset, TT_SIZE, sp)
            
        (ttbr0, ttbr0_size) = get_ttbr0_config(ec)            

        print_address_page_table(ec, ttbr0, 0, ttbr0_size, sp)
             
    elif config['command'] == 'a':  # Dump a page table entry for a given address
        
        if ttbr1 != 0:  # check if TTBR1 is enabled       
            get_address_page_table(ec, ttbr1, ttbr1_offset, TT_SIZE, config['address'], sp) 
                     
        get_address_page_table(ec, ttbr0, 0, ttbr0_size, config['address'],sp)
            
    elif config['command'] == 's':   # Dump a page table entry for a given symbol
        
        try:
            temp = '&' + config['symbol']
            add = long(ec.getVariableService().readValue(temp))

            print "*** Symbol: %s - Virtual Addr: %s ***" % (config['symbol'],hex(add))
            
        except:
            print "Symbol '%s' does not exist!" % config['symbol']
            return 0  
            
        else:
            if ttbr1 != 0:  # TTBR1 enabled       
                get_address_page_table(ec, ttbr1, ttbr1_offset, TT_SIZE, add, sp)
          
            get_address_page_table(ec, ttbr0, 0, ttbr0_size, add, sp)

    else:
        print_help()
        return
    
    if config['file'] != 0:
        sys.stdout.close()      # Close device
        sys.stdout = old_stdout # Restore console
        
    print "Done!"

if __name__ == '__main__':
    main() 
