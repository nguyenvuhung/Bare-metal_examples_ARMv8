/* Application Rewind Example #1 for ARM Linux */

/* Copyright (C) ARM Limited, 2013. All rights reserved. */

#include "month.h"
#include <stdio.h>

int counts[32] = { 0 };

const char* const month_name[] = {
	0,
	"January", "February", "March",
	"April", "May", "June",
	"July","August", "September",
	"October", "November", "December"
};


int num_days_in_month(int month, int year) {
	int ndays;
	switch (month) {
	case FEB:
		if ((year % 4) == 0 &&
			 ((year % 100) != 0 ||
			 (year % 400) == 0)) {
			ndays = 29; // leap years
		} else {
			ndays = 28;
		}
		break;
	case JAN: case MAR: case MAY: case JUL:
	case AUG: case OCT:
	    ndays = 31;
		break;
	case APR: case JUN: case SEP: case NOV:
	    ndays = 30;
		break;
	}
	return ndays;
}


int main(void)
{
	printf("Application Rewind Example #1 for ARM Linux.\n");
	printf("This code crashes with SIGSEGV caused by an array index being uninitialized/out-of-range.\n");

    int m;

    for (m = JAN; m <= DEC ; ++m) {
        int y = 2014;
        int n = num_days_in_month(m, y);
        ++counts[n]; // why the crash here?
        printf("%s %d has %d days\n", month_name[m], y, n);
        }

    return 0;
}
