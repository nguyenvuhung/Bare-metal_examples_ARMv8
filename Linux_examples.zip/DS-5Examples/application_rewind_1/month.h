enum {
	JAN = 1, FEB, MAR, APR, MAY, JUN,
	JUL, AUG, SEP, OCT, NOV, DEC
};

int num_days_in_month(int month, int year);

extern const char* const month_name[];
