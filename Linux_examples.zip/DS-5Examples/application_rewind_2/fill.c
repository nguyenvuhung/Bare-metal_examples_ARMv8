/* Application Rewind Example #2 for ARM Linux */

/* Copyright (C) ARM Limited, 2013. All rights reserved. */

#include <assert.h>

#define MAX 3

static const char *buff[MAX];


void fill(int n, const char **v) {
	int i = 0;
	assert(n <= MAX);
	while (i <= n) {
		buff[i] = *v;
		i++;
		v++;
	}
}
