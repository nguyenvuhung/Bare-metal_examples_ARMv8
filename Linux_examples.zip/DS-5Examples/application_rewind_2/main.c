/* Application Rewind Example #2 for ARM Linux */

/* Copyright (C) ARM Limited, 2013. All rights reserved. */

#include <stdio.h>

void send_init(int *);
int send(int);
void fill(int, const char **);


// initialise an array that gets overwritten
const char *src_array[] = {
		"me", "a", "b", 0
};

#define ARRAY_MAX(a) ((sizeof(a)/sizeof(a[0]))-1)


int main(void)
{
	int x, i;

	printf("Application Rewind Example #2 for ARM Linux.\n");
	printf("This code crashes with SIGSEGV caused by a null pointer.\n");

	// overwrite first element of array
	for (i = 0; i < 99; ++i) {
		send_init(&x);
		fill(1, src_array);
	}

	// overwrite all elements of array
	fill(ARRAY_MAX(src_array), src_array);

	// overwrite first two elements of array
	for (i = 0; i < 99; ++i) {
		fill(2, src_array);
	}

	// send some value
	send(42);

	printf("Code execution completed successfully");

	return 0;
}
