/* Application Rewind Example #2 for ARM Linux */

/* Copyright (C) ARM Limited, 2013. All rights reserved. */

#include <stdlib.h>
#include <assert.h>

static int *result_ptr;


void send_init(int *p) {
	assert(p != 0);
	result_ptr = p;
	*p = 0;
}


int set(int i) {
	*result_ptr = i; // why the crash here?
	return 0;
}


int send(int i) {
	return set(i) + 1;
}
