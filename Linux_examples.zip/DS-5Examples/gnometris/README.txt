Copyright ARM Ltd, 2011-2013



The "gnome-games-2.26.2" directory in this folder contains source files and binary executables for the "Gnometris" falling-block game, one of a suite of Gnome games.

For licensing terms, please refer to the "COPYING" file in the "gnome-games-2.26.2" directory.

The original source files can be obtained from http://ftp.acc.umu.se/pub/GNOME/sources/gnome-games/2.26/gnome-games-2.26.2.tar.gz

A small number of simplifying changes have been made by ARM to the Gnometris source code for the purposes of this example. These are all marked with _ARM_ to allow them to be easily found.

The binary executables have been compiled from these sources using the Linaro GCC 2012.05 compiler.
