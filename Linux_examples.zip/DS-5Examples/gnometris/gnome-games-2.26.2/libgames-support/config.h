/* config.h.in.  Generated from configure.in by autoheader.  */

/* AF_UNIX is available */
#undef AF_LOCAL

/* SDL_Mixer support */
#undef AUDIO_SDL

/* Define if card theme installer support is enabled */
#undef ENABLE_CARD_THEMES_INSTALLER

/* Define to enable prerendered card theme format support */
#undef ENABLE_CARD_THEME_FORMAT_FIXED

/* Define to enable KDE card theme format support */
#undef ENABLE_CARD_THEME_FORMAT_KDE

/* Define to enable PySol card theme format support */
#undef ENABLE_CARD_THEME_FORMAT_PYSOL

/* Define to enable pre-2.19 card theme format support */
#undef ENABLE_CARD_THEME_FORMAT_SLICED

/* Define to enable SVG card theme format support */
#undef ENABLE_CARD_THEME_FORMAT_SVG

/* Enable compilation of included GNU Chess as AI chess engine for glChess */
#undef ENABLE_GNUCHESS

/* always defined to indicate that i18n is enabled */
#undef ENABLE_NLS

/* Support for asynchronous hostname lookups */
#undef GAI_A

/* Path where to install the games */
#undef GAMEDIR

/* The default card theme */
#undef GAMES_CARD_THEME_DEFAULT

/* The default card theme format type string */
#undef GAMES_CARD_THEME_DEFAULT_FORMAT_STRING

/* The gettext package name */
#define GETTEXT_PACKAGE "gnome-games"

/* Path where the games should look for their data files */
#undef GGZDATADIR

/* Game server data directory */
#undef GGZDDATADIR

/* Path where the game registry is located */
#undef GGZMODULECONFDIR

/* Client support for GGZ */
#undef GGZ_CLIENT

/* Support for embedded GGZ through libggz-gtk */
#undef GGZ_GTK

/* Check if local sockets are supported */
#undef GGZ_HAVE_PF_LOCAL

/* Check if file descriptors can be sent */
#undef GGZ_HAVE_SENDMSG

/* Check if syslog is present */
#undef GGZ_HAVE_SYSLOG_H

/* Server support for GGZ */
#undef GGZ_SERVER

/* Define if GNUTLS is to be used */
#undef GGZ_TLS_GNUTLS

/* Define if no TLS is to be used */
#undef GGZ_TLS_NONE

/* Define if OpenSSL is to be used */
#undef GGZ_TLS_OPENSSL

/* Enable additional debugging at the expense of performance and size */
#undef GNOME_ENABLE_DEBUG

/* Pixmap directory */
#define GNOME_ICONDIR "/writeable"

/* Define to 1 if you have the `alarm' function. */
#undef HAVE_ALARM

/* Define to 1 if you have the <arpa/inet.h> header file. */
#undef HAVE_ARPA_INET_H

/* Define to 1 if you have the `bind_textdomain_codeset' function. */
#undef HAVE_BIND_TEXTDOMAIN_CODESET

/* Define to 1 if you have the `close' function. */
#undef HAVE_CLOSE

/* Define if CMSG_ALIGN is available */
#undef HAVE_CMSG_ALIGN

/* Define if CMSG_LEN is available */
#undef HAVE_CMSG_LEN

/* Define if CMSG_SPACE is available */
#undef HAVE_CMSG_SPACE

/* Define to 1 if you have the `dcgettext' function. */
#undef HAVE_DCGETTEXT

/* Define to 1 if you have the <dlfcn.h> header file. */
#undef HAVE_DLFCN_H

/* Define to 1 if you don't have `vprintf' but do have `_doprnt.' */
#undef HAVE_DOPRNT

/* Define to 1 if you have the `dup2' function. */
#undef HAVE_DUP2

/* Define to 1 if you have the <fcntl.h> header file. */
#undef HAVE_FCNTL_H

/* Define to 1 if you have the `fork' function. */
#undef HAVE_FORK

/* Define to 1 if you have the `getenv' function. */
#undef HAVE_GETENV

/* Define to 1 if you have the `getpwuid' function. */
#undef HAVE_GETPWUID

/* Define if the GNU gettext() function is already present or preinstalled. */
#undef HAVE_GETTEXT

/* Define if GNOME support is enabled */
#undef HAVE_GNOME

/* Define if GStreamer is available */
#undef HAVE_GSTREAMER

/* Define if guile version is 1.8.0 or above */
#undef HAVE_GUILE_1_8

/* Define if Hildon support is enabled */
#undef HAVE_HILDON

/* Define to 1 if you have the `hstrerror' function. */
#undef HAVE_HSTRERROR

/* Define to 1 if you have the <inttypes.h> header file. */
#undef HAVE_INTTYPES_H

/* Define to 1 if you have the `kill' function. */
#undef HAVE_KILL

/* Define if your <locale.h> file defines LC_MESSAGES. */
#undef HAVE_LC_MESSAGES

/* Define to 1 if you have the <limits.h> header file. */
#undef HAVE_LIMITS_H

/* Define to 1 if you have the <locale.h> header file. */
#undef HAVE_LOCALE_H

/* Define if Maemo support is enabled */
#undef HAVE_MAEMO

/* Define if Maemo 3.x support is enabled */
#undef HAVE_MAEMO_3

/* Define to 1 if you have the `malloc' function. */
#undef HAVE_MALLOC

/* Define to 1 if you have the <memory.h> header file. */
#undef HAVE_MEMORY_H

/* Define if msghdr has a msg_controllen member */
#undef HAVE_MSGHDR_MSG_CONTROL

/* Define to 1 if you have the <netdb.h> header file. */
#undef HAVE_NETDB_H

/* Define to 1 if you have the <netinet/in.h> header file. */
#undef HAVE_NETINET_IN_H

/* Define if you have OpenSSL < 0.9.6 */
#undef HAVE_OLD_SSL_API

/* Define to 1 if your system has a GNU libc compatible `realloc' function,
   and to 0 otherwise. */
#undef HAVE_REALLOC

/* Define if librsvg is available */
#undef HAVE_RSVG

/* Define if librsvg has gnome-vfs support */
#undef HAVE_RSVG_GNOMEVFS

/* Define if SDL_Mixer is available */
#undef HAVE_SDL_MIXER

/* Define to 1 if you have the `select' function. */
#undef HAVE_SELECT

/* Define to 1 if you have the `setenv' function. */
#undef HAVE_SETENV

/* Define to 1 if you have the `socketpair' function. */
#undef HAVE_SOCKETPAIR

/* If we are going to use OpenSSL */
#undef HAVE_SSL

/* Define to 1 if stdbool.h conforms to C99. */
#undef HAVE_STDBOOL_H

/* Define to 1 if you have the <stdint.h> header file. */
#undef HAVE_STDINT_H

/* Define to 1 if you have the <stdlib.h> header file. */
#undef HAVE_STDLIB_H

/* Define to 1 if you have the `strcasecmp' function. */
#undef HAVE_STRCASECMP

/* Define to 1 if you have the `strchr' function. */
#undef HAVE_STRCHR

/* Define to 1 if you have the `strcoll' function and it is properly defined.
   */
#undef HAVE_STRCOLL

/* Define to 1 if you have the `strerror' function. */
#undef HAVE_STRERROR

/* Define to 1 if you have the <strings.h> header file. */
#undef HAVE_STRINGS_H

/* Define to 1 if you have the <string.h> header file. */
#undef HAVE_STRING_H

/* Define if the SUN_LEN macro exists */
#undef HAVE_SUN_LEN

/* Define to 1 if you have the <sys/select.h> header file. */
#undef HAVE_SYS_SELECT_H

/* Define to 1 if you have the <sys/socket.h> header file. */
#undef HAVE_SYS_SOCKET_H

/* Define to 1 if you have the <sys/stat.h> header file. */
#undef HAVE_SYS_STAT_H

/* Define to 1 if you have the <sys/time.h> header file. */
#undef HAVE_SYS_TIME_H

/* Define to 1 if you have the <sys/types.h> header file. */
#undef HAVE_SYS_TYPES_H

/* Define to 1 if you have <sys/wait.h> that is POSIX.1 compatible. */
#undef HAVE_SYS_WAIT_H

/* Define to 1 if you have the <time.h> header file. */
#undef HAVE_TIME_H

/* Define to 1 if you have the <unistd.h> header file. */
#undef HAVE_UNISTD_H

/* Define to 1 if you have the `vfork' function. */
#undef HAVE_VFORK

/* Define to 1 if you have the <vfork.h> header file. */
#undef HAVE_VFORK_H

/* Define to 1 if you have the `vprintf' function. */
#undef HAVE_VPRINTF

/* Define to 1 if you have the <winsock2.h> header file. */
#undef HAVE_WINSOCK2_H

/* Define to 1 if `fork' works. */
#undef HAVE_WORKING_FORK

/* Define to 1 if `vfork' works. */
#undef HAVE_WORKING_VFORK

/* Define to 1 if the system has the type `_Bool'. */
#undef HAVE__BOOL

/* The full distribution description */
#undef LSB_DISTRIBUTION

/* The distributor ID */
#undef LSB_DISTRIBUTOR

/* Define to the sub-directory in which libtool stores uninstalled libraries.
   */
#undef LT_OBJDIR

/* Define to 1 if your C compiler doesn't accept -c and -o together. */
#undef NO_MINUS_C_MINUS_O

/* Define if threading support is disabled */
#undef NO_THREADING

/* Name of package */
#undef PACKAGE

/* Define to the address where bug reports for this package should be sent. */
#undef PACKAGE_BUGREPORT

/* Define to the full name of this package. */
#undef PACKAGE_NAME

/* Path where the source is located */
#undef PACKAGE_SOURCE_DIR

/* Define to the full name and version of this package. */
#undef PACKAGE_STRING

/* Define to the one symbol short name of this package. */
#undef PACKAGE_TARNAME

/* Define to the version of this package. */
#undef PACKAGE_VERSION

/* PF_UNIX is available */
#undef PF_LOCAL

/* Define as the return type of signal handlers (`int' or `void'). */
#undef RETSIGTYPE

/* SDL is used */
#undef SDL

/* Define to the type of arg 1 for `select'. */
#undef SELECT_TYPE_ARG1

/* Define to the type of args 2, 3 and 4 for `select'. */
#undef SELECT_TYPE_ARG234

/* Define to the type of arg 5 for `select'. */
#undef SELECT_TYPE_ARG5

/* Define to 1 if you have the ANSI C header files. */
#undef STDC_HEADERS

/* Define to 1 if you can safely include both <sys/time.h> and <time.h>. */
#undef TIME_WITH_SYS_TIME

/* Define if you have the gcrypt library */
#undef USE_GCRYPT

/* Version number of package */
#define VERSION "2.26.2"

/* Define if smclient is enabled */
#undef WITH_SMCLIENT

/* Define to empty if `const' does not conform to ANSI C. */
#undef const

/* Define to `__inline__' or `__inline' if that's what the C compiler
   calls it, or to nothing if 'inline' is not supported under any name.  */
#ifndef __cplusplus
#undef inline
#endif

/* Define to `int' if <sys/types.h> does not define. */
#undef pid_t

/* Define to rpl_realloc if the replacement function should be used. */
#undef realloc

/* Define to `unsigned int' if <sys/types.h> does not define. */
#undef size_t

/* Define as `fork' if `vfork' does not work. */
#undef vfork

/* Define to empty if the keyword `volatile' does not work. Warning: valid
   code using `volatile' can become incorrect without. Disable with care. */
#undef volatile
