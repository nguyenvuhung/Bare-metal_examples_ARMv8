/*
 * C Application Example for ARM Linux
 * 
 * Copyright (C) ARM Limited, 2007-2015. All rights reserved.
 */

/*
 * hello.c: A simple "helloworld" C program
 */
 
#include <stdio.h>

int main(int argc, char** argv)
{
    printf("Hello Linux\n");

    return 0;
}
