/*
 * A simple Linux user-space application to exercise the modex.ko kernel module
 * and to illustrate simultaneous application and kernel module debug in DS-5
 *
 *  Copyright (C) ARM Limited, 2010. All rights reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 */

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

static int f ;

#define BUFLEN 20
unsigned char a = 99;
unsigned char b[BUFLEN];



int main(void)
{
    if ((f = open("/dev/modex", O_RDWR)) < 0)
    {
        printf ("Failed to open /dev/modex\n");
        return 1;
    }

    printf("Writing a value %d to modex\n", a);
    write(f, &a, 1);

    read(f, &b, BUFLEN);
    printf("String read from modex = %s\n", &b);

    close(f) ;

    return 0 ;
}
