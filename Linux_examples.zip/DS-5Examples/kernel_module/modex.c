/*
 * This is a simple character device driver to illustrate the support for debug of Linux kernel modules
 *
 *  Copyright (C) ARM Limited, 2010. All rights reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 */

#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/init.h>
#include <linux/fs.h>
#include <linux/device.h>
#include <asm/uaccess.h>


#define MODEX_MAJOR 42
#define MODEX_MINOR 0
#define DEVICE_NAME "modex"


static int modex_open(struct inode *inode, struct file *file);
static int modex_release(struct inode *inode, struct file *file);
static ssize_t modex_read (struct file *file, char *buffer, size_t length, loff_t * offset);
static ssize_t modex_write (struct file *file, const char *buffer, size_t length, loff_t * offset);
static int __init modex_init(void);
static void __exit modex_exit(void);

static volatile int test_mode /* = 0 */;  /* can be set from debugger */

struct file_operations modex_fops =
{
    .owner    =  THIS_MODULE,
    .open     =  modex_open,
    .release  =  modex_release,
    .read     =  modex_read,
    .write    =  modex_write,
};

static struct device *modex_cdev;
static struct class *modex_class;


static int modex_open(struct inode *inode, struct file *file)
{
    return 0 ;
}


static int modex_release(struct inode *inode, struct file *file)
{
    return 0;
}


static ssize_t modex_read(struct file *file, char *buffer, size_t length, loff_t *offset)
{
    const char *msg = "Hello from modex\n";
    const int msg_len = strlen(msg);

    if (*offset >= msg_len)
        return 0;   /* EOF */

    if (*offset + length >= msg_len)
        length = msg_len - *offset;

    if ( copy_to_user(buffer, msg + *offset, length) )
        return -EFAULT;
    *offset += length;

    return length;
}


static ssize_t modex_write(struct file *file, const char *buffer, size_t length, loff_t *offset)
{
    char x;

    if ( copy_from_user(&x, buffer, 1) ) // only interested in the first byte passed in
        return -EFAULT;
    printk(KERN_INFO "modex received value: '%c' %d\n", x, x);
    switch (x) {
        case 'A':
            if (test_mode) {
                printk(KERN_INFO "modex test mode about to abort\n");
                /* cause an abort */
                x = *(int*)test_mode;
                printk(KERN_INFO "modex didn't expect to get here! '%c' %d\n", x, x);
            }
            break;
        case 'P':
            if (test_mode) {
                panic("panic from modex test mode");
            }
            break;
        case '+':
            test_mode = 1;
            printk(KERN_INFO "modex test mode enabled\n");
            break;
        case '-':
            test_mode = 0;
            printk(KERN_INFO "modex test mode disabled\n");
            break;
        default:
            break;
    }

    return length;
}


static int __init modex_init(void)
{
    int ret;

    /* Register character device driver */
    ret = register_chrdev(MODEX_MAJOR, DEVICE_NAME, &modex_fops);
    if (ret < 0)
    {
        printk(KERN_ERR "modex could not initialize\n");
        return ret;
    }

    /* Create a class /sys/class/modex/modex, then create a device node /dev/modex */
    modex_class = class_create(THIS_MODULE, DEVICE_NAME);
    modex_cdev = device_create(modex_class, NULL, MKDEV (MODEX_MAJOR, MODEX_MINOR), NULL, DEVICE_NAME);
    printk(KERN_INFO "modex initialized\n");

    return 0;
}


static void __exit modex_exit(void)
{
    device_destroy(modex_class, MKDEV (MODEX_MAJOR, MODEX_MINOR));
    class_destroy(modex_class);
    unregister_chrdev(MODEX_MAJOR, DEVICE_NAME);

    printk(KERN_INFO "modex exited\n");
}


module_init(modex_init);
module_exit(modex_exit);


MODULE_AUTHOR("ARM");
MODULE_VERSION("1.01");
MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("Example module");
