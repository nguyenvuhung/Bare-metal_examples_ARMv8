/* Threads example to illustrate support for debug of multi-threaded ARM Linux applications */
   
/* Copyright (C) ARM Limited, 2010-2014. All rights reserved. */

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

#define NUM_THREADS 5

struct thread_app_data_struct {
    unsigned int thread;
    float result;       
    unsigned int loops;
    float step;
};

struct thread_app_data_struct thread_app_data[NUM_THREADS];

void *thread_work(void *threadarg);
float accumulate(unsigned int thread, float accum, unsigned int loops, float step);


/* Create some threads, give them some work to do, then wait for them to finish */
int main (void)
{
    pthread_t thread[NUM_THREADS];
    pthread_attr_t attr;
    int err;
    unsigned int t;
    //void *join_result;

    printf("\n");
    printf("Threads example\n");
    printf("===============\n");
    printf("\n");    
    printf("This example creates %d threads with pthread_create(),\n", NUM_THREADS);
    printf("gives them some work to do (accumulating a float result in a loop),\n");    
    printf("then waits for them to finish with pthread_join().\n");
    printf("\n");        

    printf("Parent process ID getpid()=%d\n", getpid() );
        
    /* Configure thread attribute as joinable */
    pthread_attr_init(&attr);
    pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_JOINABLE);

    /* Create some threads and give them some work to do */
    for (t=0; t<NUM_THREADS; t++)
    {
        thread_app_data[t].thread = t;
        thread_app_data[t].loops = 1000000 + t*1000;
        thread_app_data[t].result = t*1.0f; // notable starting value
        thread_app_data[t].step = 1.0f;        

        printf("Thread %d being created\n", t);
        err = pthread_create(&thread[t], &attr, thread_work, &thread_app_data[t]); 
        if (err)
        {
            printf("Error %d from pthread_create()\n", err);
            exit(-1);
        }
    }

    pthread_attr_destroy(&attr);    

    printf("All threads now created\n");
    
    /* Wait for each thread to finish, by joining with the parent */
    for (t=0; t<NUM_THREADS; t++)
    {
        printf("Thread %d being joined to parent for finishing\n", t);    
        err = pthread_join(thread[t], NULL);  // could return a &join_result 
        if (err)
        {
            printf("Error %d from pthread_join()\n", err);
            exit(-1);
        }
//        printf("Join to thread %d finished with result %ld\n", t, (long)join_result);
    }

    printf("\nAccumulation results summary\n");
    for (t=0; t<NUM_THREADS; t++)
    {
        printf("Thread %d result = %e\n", t, thread_app_data[t].result);      
    }
 
    printf("Threads example finished\n");

    return 0;
}


/* The threads start their work here */
void *thread_work(void *threadarg)
{
    struct thread_app_data_struct *t = threadarg;
   
    printf("Thread %d running, pthread_self()=%ul\n", t->thread, pthread_self() );

    t->result = accumulate(t->thread, t->result, t->loops, t->step);

    printf("Thread %d exiting\n", t->thread);
    pthread_exit(NULL);

    return((void *)0);
}


/* Accumulate a result, starting from an initial value, with a given step and number of loops */
float accumulate(unsigned int thread, float accum, unsigned int loops, float step)
{
    unsigned int i;

    printf("Thread %d started accumulating\n", thread);
    for (i=0; i<loops; i++)
    {
        accum = accum + step;    
        if (i==loops/2)
        {
            printf("Thread %d half way through accumulation\n", thread);
        }
    }
    printf("Thread %d finished accumulating\n", thread);    
    return accum;
}
