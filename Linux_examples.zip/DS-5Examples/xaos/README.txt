=================================================================================
Xaos Example - Source code licensing, source code changes, and binary executables
=================================================================================

The "xaos-3.5" directory in this folder contains source files and binary executables for the "Xaos" interactive fractal zoomer application.

For licensing terms, please refer to the "COPYING" file in the "xaos-3.5" directory.

The original source files can be obtained from http://sourceforge.net/projects/xaos/files/XaoS/3.5/xaos-3.5.tar.gz/download.

Some small additions and changes have been made by ARM Ltd to the original sources,
to illustrate Streamline annotation support and to add naming of threads:
/xaos/xaos-3.5/src/include/streamline_annotate.h
/xaos/xaos-3.5/src/engine/zoom.c
/xaos/xaos-3.5/src/ui/ui.c
/xaos/xaos-3.5/src/ui/ui-drv/gtk/annotate.c
/xaos/xaos-3.5/src/ui/ui-drv/gtk/streamline_annotate.c
/xaos/xaos-3.5/src/ui/ui-drv/gtk/ui_gtk.c
/xaos/xaos-3.5/src/util/thread.c

Further small additions have been made by ARM Ltd to add annotation of thread functions:
/xaos/xaos-3.5/src/engine/zoom.c      : mkrealloc_table, processqueue, moveoldpoints, calculatenew, filly, dosymetry
/xaos/xaos-3.5/src/engine/zoomd.c     : dosymetry2_*
/xaos/xaos-3.5/src/engine/btraced.c   : queue, bfill
/xaos/xaos-3.5/src/engine/3dd.c       : do_3d
/xaos/xaos-3.5/src/engine/dither.c    : converttbitmap, convertgray, convert, convertfixed, convertbitmap
/xaos/xaos-3.5/src/engine/anti.c      : antigray, anti
/xaos/xaos-3.5/src/engine/edge2d.c    : do_edge
/xaos/xaos-3.5/src/engine/blur.c      : blur
/xaos/xaos-3.5/src/engine/emboss.c    : emboss
/xaos/xaos-3.5/src/engine/itersmall.c : convert
/xaos/xaos-3.5/src/engine/paletted.c  : palette
/xaos/xaos-3.5/src/engine/rotated.c   : do_rotate
/xaos/xaos-3.5/src/engine/stard.c     : do_starfield
/xaos/xaos-3.5/src/engine/sterod.c    : do_stereogram

Changes are marked with "ARM Ltd" to allow them to be easily found.

The binary executables have been compiled from these sources using the Linaro GCC 4.8 compiler.
