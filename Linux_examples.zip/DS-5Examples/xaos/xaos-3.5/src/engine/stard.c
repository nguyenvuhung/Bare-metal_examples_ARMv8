/*
** Modified by ARM Limited, July 2012
** Added annotation of thread functions
** Copyright (C) ARM Limited, 2012.
*/

#include "streamline_annotate.h" /* ARM Ltd added */

#ifndef UNSUPPORTED
static void do_starfield(void *data, struct taskinfo *task, int r1, int r2)
{
    struct filter *f = (struct filter *) data;
    cpixel_t *dest;
    pixel8_t *src, *srcend;
    unsigned int color;
    int y;

    ANNOTATE_COLOR(ANNOTATE_GREEN, "do_starfield");  /* ARM Ltd added */

    cpixeldata_t black = (cpixeldata_t) f->image->palette->pixels[0];
    mysrandom((unsigned int) rand());
    for (y = r1; y < r2; y++) {
	src = f->childimage->currlines[y];
	srcend = f->childimage->currlines[y] + f->childimage->width;
	dest = (cpixel_t *) f->image->currlines[y];
	while (src < srcend) {
	    color = ((unsigned int) myrandom() >> 7) & 15;
	    if (!*src
		|| (unsigned int) *src * (unsigned int) *src *
		(unsigned int) *src >
		(unsigned int) ((unsigned int) myrandom() & (0xffffff))) {
		p_set(dest,
		      (cpixeldata_t) f->image->palette->pixels[color]);
	    } else
		p_set(dest, black);
	    p_inc(dest, 1);
	    src++;
	}
    }
    ANNOTATE_END();  /* ARM Ltd added */
}
#endif
#undef do_starfield
