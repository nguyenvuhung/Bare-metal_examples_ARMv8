#ifndef CONFIG_H
#define CONFIG_H

#undef SFFE_USING
#undef SFFE_CMPLX_ASM
#undef SFFE_CMPLX_GSL

#define INLINE inline
#define CONST const
#define REGISTERS(n)
#undef USE_ALLEGRO
#undef HAVE_UCLOCK

#define CONFIGFILE "xaos.cfg"
#ifndef FPOINT_TYPE /* _ARM_ added */
#define FPOINT_TYPE  long double
				       /*floating point math type on computers
				          with medium speed floating point math should   
				          use float instead */
#endif /* _ARM_ added */
#define USE_LONG		/*for autoconf..undefine if
				   fpoint_type is set to other than
				   long_double */
#undef MITSHM
				       /*undefine this if you system does not
				          support shared memory */
/* You don't need to change these lines unless you now what you are doing */

#include <aconfig.h>
#define USE_STDIO
#include <gccaccel.h>
 
#define STRUECOLOR24
#define STRUECOLOR
#define STRUECOLOR16
#endif				/*CONFIG_H */
