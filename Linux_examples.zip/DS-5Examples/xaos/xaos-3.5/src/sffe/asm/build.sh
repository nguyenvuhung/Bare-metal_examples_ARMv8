#!/bin/bash
nasm -f elf cmplx.asm -ocmplx.o
# Not used anymore because ../Makefile already contains this compilation.
