/*
 *  ARM Streamline Visual Annotation Example for Xaos
 *  
 *  This file provides functions to deliver a splash image 
 *  and Xaos fractal screen data to Streamline for visual annotation
 *
 *  Copyright (C) ARM Limited, 2011-2016. All rights reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include "streamline_annotate.h"


char* readFromDisk(const char* file, unsigned int *size) {
	// Open the file
	FILE* pFile = fopen(file, "rb");
	if (pFile == NULL) {
		return NULL;
	}

	// Obtain file size
	fseek(pFile , 0 , SEEK_END);
	unsigned int lSize = ftell(pFile);
	rewind(pFile);

	// Allocate memory to contain the whole file
	char* buffer = (char*)malloc(lSize);
	if (buffer == NULL) return NULL;

	// Copy the file into the buffer
	if (fread(buffer,1,lSize,pFile) != lSize) return NULL;

	// Terminate
	fclose(pFile);

	if (size)
		*size = lSize;

	return buffer;
}

struct bmp_magic {
  unsigned char ch1;
  unsigned char ch2;
};

struct bmp_header {
  uint32_t filesz;
  uint16_t creator1;
  uint16_t creator2;
  uint32_t bmp_offset;
};

struct dib_header {
  uint32_t header_sz;
  int32_t width;
  int32_t height;
  uint16_t nplanes;
  uint16_t bitspp;
  uint32_t compress_type;
  uint32_t bmp_bytesz;
  int32_t hres;
  int32_t vres;
  uint32_t ncolors;
  uint32_t nimpcolors;
};

#define BMP_HDR_SIZE	(sizeof(struct bmp_magic) + sizeof(struct bmp_header) + sizeof(struct dib_header))
int bmp_width;
int bmp_height;
int bmp_pad_bytes;
int bmp_row_size;
uint32_t bmp_data_size;
uint32_t bmp_file_size;

int addBmpHeader(char* buffer) {
	struct bmp_magic bmpmagic;
	struct bmp_header bmpheader;
	struct dib_header dibheader;

	// BMP magic
	bmpmagic.ch1 = 0x42;
	bmpmagic.ch2 = 0x4D;

	// BMP header
	bmpheader.filesz = bmp_file_size;
	bmpheader.creator1 = 0;
	bmpheader.creator2 = 0;
	bmpheader.bmp_offset = BMP_HDR_SIZE;

	// DIB header
	dibheader.header_sz = sizeof(dibheader);
	dibheader.width = bmp_width;
	dibheader.height = bmp_height;
	dibheader.nplanes = 1;
	dibheader.bitspp = 24;
	dibheader.compress_type = 0;
	dibheader.bmp_bytesz = bmp_data_size;
	dibheader.hres = 2835;
	dibheader.vres = 2835;
	dibheader.ncolors = 0;
	dibheader.nimpcolors = 0;

	// Create the bmp image header by copying the structures into a single buffer
	memcpy(buffer, (char*)&bmpmagic, sizeof(bmpmagic));
	memcpy(&buffer[sizeof(bmpmagic)], (char*)&bmpheader, sizeof(bmpheader));
	memcpy(&buffer[sizeof(bmpmagic) + sizeof(bmpheader)], (char*)&dibheader, sizeof(dibheader));

	return BMP_HDR_SIZE;
}

extern int streamlinevisualannotation;

// Deliver the splash image to Streamline for visual annotation
void VisualAnnotateSplashImage(void) {
	char filename[32];
	char* image;
	unsigned int size;

	if ( streamlinevisualannotation == 0 ) return;

	ANNOTATE_MARKER_COLOR_STR(ANNOTATE_BLUE, "Start visual annotation");

	// Supported formats include gif, png, jpeg, tiff, ico, bmp (+rle)
	strcpy(filename, "splash.bmp");
	image = readFromDisk(filename, &size);
	if (image == NULL) {
		printf("Warning: Could not load image %s\n", filename);
	}
    else {
    	// Add text along with the image annotation
    	ANNOTATE_VISUAL(image, size, filename);
        free(image);
    }
	ANNOTATE_MARKER_COLOR_STR(ANNOTATE_GREEN, "End visual annotation");
}


// Deliver the Xaos fractal screen data to Streamline for visual annotation
void VisualAnnotateImage(char* screen_data, int width, int height) {
	unsigned int offset, screen_row_start;
	int row, col;
	char pad[3] = {0, 0, 0};

	if ( streamlinevisualannotation == 0 ) return;

	ANNOTATE_MARKER_COLOR_STR(ANNOTATE_BLUE, "Start visual annotation");

	bmp_width = width;
	bmp_height = height;
	bmp_pad_bytes = (bmp_width * 3 % 4);
	bmp_row_size  = (bmp_width * 3 + bmp_pad_bytes);
	bmp_data_size = (bmp_row_size * bmp_height);
	bmp_file_size = (BMP_HDR_SIZE + bmp_data_size);

	char* buffer = (char*)malloc(bmp_file_size);
	if (buffer == NULL) return;

	// Create the bmp header and reuse the same buffer
	offset = addBmpHeader(buffer);

	// Copy (and invert) the Xaos fractal screen data in CAIRO_FORMAT_RGB24 (32 bit) format
	// to the visual annotation bmp buffer in 24 bit format
	for (row = bmp_height-1; row >= 0; row--) {
		screen_row_start = row * bmp_width * 4;
		for (col = 0; col < bmp_width; col++) {
			buffer[offset++] = screen_data[screen_row_start++]; // b
			buffer[offset++] = screen_data[screen_row_start++]; // g
			buffer[offset++] = screen_data[screen_row_start++]; // r

			// discard unused upper (A) byte, but set to opaque for the Screen Viewer
			screen_data[screen_row_start++] = 0xFF;
		}
		memcpy(&buffer[offset], pad, bmp_pad_bytes);
		offset += bmp_pad_bytes;
	}

	ANNOTATE_VISUAL(buffer, bmp_file_size, "Xaos");
    free(buffer);
	ANNOTATE_MARKER_COLOR_STR(ANNOTATE_GREEN, "End visual annotation");
}
