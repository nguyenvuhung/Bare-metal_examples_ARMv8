#define IDC_STATIC -1

#define DLG_VERFIRST        400
#define IDC_COMPANY        DLG_VERFIRST
#define IDC_FILEDESC          DLG_VERFIRST+1
#define IDC_PRODVER         DLG_VERFIRST+2
#define IDC_COPYRIGHT       DLG_VERFIRST+3
#define IDC_OSVERSION       DLG_VERFIRST+4
#define IDC_TRADEMARK       DLG_VERFIRST+5
#define DLG_VERLAST         DLG_VERFIRST+5
#define IDC_LICENSE	    DLG_VERFIRST+6

#define IDC_LABEL           IDC_LICENSE+1


#define IDS_APP_TITLE       500
#define IDS_DISPLAYCHANGED  501
#define IDS_VER_INFO_LANG   502
#define IDS_VERSION_ERROR   503
#define IDS_NO_HELP         504
